package com.hanzala.bedwars;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Operator-editable switches in config/bedwars/settings.txt ("key=value", '#' starts a comment).
 * Every key has a default, so a missing file, missing key or typo never breaks the game.
 * Run /bw reload after editing the file.
 */
public final class Settings {
    private Settings() { }

    private record Def(String value, String comment) { }

    private static final Map<String, Def> DEFS = new LinkedHashMap<>();
    private static final Map<String, String> VALUES = new HashMap<>();
    /** Keys from older versions: silently ignored (the new timeline replaced them). */
    private static final java.util.Set<String> LEGACY = java.util.Set.of("bed_gone_minutes", "match_limit_minutes", "emerald_fast_after_minutes");
    private static final Map<String, List<String>> CHOICES = Map.of("match_end_action", List.of("sudden_death", "draw", "most_alive"));

    private static void def(String key, String value, String comment) { DEFS.put(key, new Def(value, comment)); }

    static {
        def("countdown_seconds", "10", "Seconds between /bw start and the first spawn (0 = start instantly).");
        def("respawn_seconds", "5", "Seconds a player waits as a spectator before respawning (bed alive).");
        def("match_duration_seconds", "1320", "Total match length in seconds (1320 = 22:00). Fixed when the match starts.");
        def("match_end_action", "sudden_death", "What happens when the time is up: sudden_death (all beds are destroyed), draw (match ends as a draw) or most_alive (team with most beds/players wins).");
        def("sudden_death_minutes", "3", "Minutes sudden death lasts before the match ends as a draw (0 = until a team wins).");
        def("scoreboard", "true", "Show the BedWars sidebar (lobby panel and live match scoreboard).");
        def("team_colors", "true", "Colour nametags, tab list and chat names by team (uses scoreboard teams named bwm_<team>).");
        def("leather_kit", "true", "Give every player team-coloured leather armour at spawn.");
        def("kill_resource_transfer", "true", "A kill hands the victim's Iron/Gold/Diamond/Emerald straight to the killer.");
        def("clean_death_drops", "true", "On death only resources drop; tools, blocks and armour are removed (the kit is re-issued).");
        def("instant_tnt", "true", "TNT ignites the moment it is placed.");
        def("tnt_fuse_ticks", "40", "Fuse of placed TNT in ticks (20 ticks = 1 second).");
        def("restrict_building", "true", "No building outside the protected arena or next to generators/team spawns.");
        def("no_build_radius", "1", "Blocks around a generator/spawn where building is blocked (0 = off).");
        def("food_refill", "true", "Refill hunger every 10 seconds during a match.");
        def("particles", "true", "Small ambient particles on generators and alive beds.");
        def("victory_fireworks", "true", "Team-coloured fireworks for the winners after a match.");
        def("match_gamerules", "true", "During a match: doTileDrops=false and doImmediateRespawn=true (reverted to vanilla defaults afterwards).");
        def("neutral_diamond_seconds", "30", "Neutral diamond generators: seconds per diamond (starts with the match, no team needed).");
        def("emerald_seconds", "60", "Neutral emerald generators: seconds per emerald at the start of the match.");
        def("emerald_fast_seconds", "40", "Generator Upgrade I (05:00): seconds per emerald.");
        def("emerald_final_seconds", "30", "Generator Upgrade II (10:00): seconds per emerald.");
        def("diamond_fast_seconds", "20", "Generator Upgrade II (10:00): seconds per neutral diamond.");
        def("animated_scoreboard", "true", "Animated sidebar header (turn off for a static header).");
        def("title_animations", "true", "Animated title sequences (fade effects, colour shimmer). Off = plain titles.");
        def("event_sounds", "true", "Sound effects for countdown, kills, beds, eliminations, timeline events and victory.");
        def("action_bar", "true", "Live action bar: team, bed, generator tier and your resources.");
        def("team_particles", "true", "Team-coloured particles for bed destruction, elimination and victory.");
        def("particle_density", "100", "Strength of the event particles in percent (10-300). Lower this on weak servers.");
        def("victory_celebration", "true", "Victory/defeat titles, banner, particles and sounds after a match.");
        def("countdown_titles_from", "5", "Show the big start countdown numbers from this many seconds (5 = 5,4,3,2,1,GO!).");
        // Team generator speeds and item caps (edited in /bw admin -> Generators)
        def("gen_iron_t1", "6", "Team generator Tier I: seconds per Iron.");
        def("gen_iron_t2", "5", "Team generator Tier II: seconds per Iron.");
        def("gen_iron_t3", "4", "Team generator Tier III: seconds per Iron.");
        def("gen_gold_t2", "8", "Team generator Tier II: seconds per Gold.");
        def("gen_gold_t3", "6", "Team generator Tier III: seconds per Gold.");
        def("gen_diamond_t3", "18", "Team generator Tier III: seconds per Diamond.");
        def("gen_cap_iron", "48", "Most Iron that can lie at one generator before it pauses.");
        def("gen_cap_gold", "24", "Most Gold that can lie at one generator before it pauses.");
        def("gen_cap_diamond", "8", "Most Diamonds that can lie at one generator before it pauses.");
        def("gen_cap_emerald", "4", "Most Emeralds that can lie at one generator before it pauses.");
    }

    public static void load() {
        VALUES.clear();
        Path file = BedWarsMod.configDir().resolve("settings.txt");
        try {
            if (!Files.exists(file)) writeDefaults(file);
            for (String raw : Files.readAllLines(file)) {
                String line = raw.split("#", 2)[0].trim();
                int eq = line.indexOf('=');
                if (eq <= 0) continue;
                String key = line.substring(0, eq).trim().toLowerCase(Locale.ROOT);
                String value = line.substring(eq + 1).trim();
                if (DEFS.containsKey(key)) VALUES.put(key, value);
                else if (!LEGACY.contains(key)) BedWarsMod.LOGGER.warn("settings.txt: unknown setting '{}' ignored", key);
            }
        } catch (IOException ex) {
            BedWarsMod.LOGGER.error("Could not read settings.txt (defaults are used)", ex);
        }
    }

    private static void writeDefaults(Path file) throws IOException { write(file); }

    /** Writes every setting with its current value (defaults for anything not set). */
    private static void write(Path file) throws IOException {
        List<String> lines = new ArrayList<>();
        lines.add("# BedWars settings. Edit, then run /bw reload in game (or restart the server).");
        lines.add("# The admin GUI (/bw admin -> Settings) edits this file too.");
        for (Map.Entry<String, Def> e : DEFS.entrySet()) {
            lines.add("");
            lines.add("# " + e.getValue().comment());
            lines.add(e.getKey() + "=" + raw(e.getKey()));
        }
        Files.write(file, lines);
    }

    // ------------------------------------------------------------------ used by the admin GUI

    public static List<String> keys() { return new ArrayList<>(DEFS.keySet()); }

    /** True for on/off switches, false for numbers. */
    public static boolean isChoiceKey(String key) { return CHOICES.containsKey(key); }

    /** Value of a choice setting; anything that is not a listed choice falls back to the default. */
    public static String text(String key) {
        List<String> choices = CHOICES.get(key);
        String v = raw(key).toLowerCase(Locale.ROOT);
        if (choices == null) return v;
        if (choices.contains(v)) return v;
        Def def = DEFS.get(key);
        return def == null ? choices.get(0) : def.value();
    }

    /** Switches a choice setting to the next listed value. */
    public static void cycle(String key) {
        List<String> choices = CHOICES.get(key);
        if (choices == null) return;
        int i = choices.indexOf(text(key));
        set(key, choices.get((i + 1) % choices.size()));
    }

    public static boolean isFlagKey(String key) {
        Def def = DEFS.get(key);
        return def != null && (def.value().equals("true") || def.value().equals("false"));
    }

    public static String comment(String key) {
        Def def = DEFS.get(key);
        return def == null ? "" : def.comment();
    }

    /** Puts one setting back to its built-in default. */
    public static void reset(String key) {
        Def def = DEFS.get(key);
        if (def != null) set(key, def.value());
    }

    public static int defaultInteger(String key) {
        Def def = DEFS.get(key);
        try { return def == null ? 0 : Integer.parseInt(def.value()); }
        catch (NumberFormatException ex) { return 0; }
    }

    public static void setFlag(String key, boolean value) { set(key, Boolean.toString(value)); }

    public static void setInteger(String key, int value) { set(key, Integer.toString(Math.max(0, value))); }

    private static void set(String key, String value) {
        if (!DEFS.containsKey(key)) return;
        VALUES.put(key, value);
        try { write(BedWarsMod.configDir().resolve("settings.txt")); }
        catch (IOException ex) { BedWarsMod.LOGGER.error("Could not save settings.txt", ex); }
    }

    private static String raw(String key) {
        Def def = DEFS.get(key);
        return VALUES.getOrDefault(key, def == null ? "" : def.value());
    }

    /** Non-negative integer setting; bad values fall back to the default. */
    public static int integer(String key) {
        try {
            return Math.max(0, Integer.parseInt(raw(key)));
        } catch (NumberFormatException ex) {
            Def def = DEFS.get(key);
            try { return def == null ? 0 : Math.max(0, Integer.parseInt(def.value())); }
            catch (NumberFormatException ignored) { return 0; }
        }
    }

    public static boolean flag(String key) {
        String v = raw(key).toLowerCase(Locale.ROOT);
        return v.equals("true") || v.equals("on") || v.equals("yes") || v.equals("1");
    }
}
