package com.hanzala.bedwars;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Invulnerable, frozen villagers tagged "bw_shop" that open the BedWars shop when right-clicked. */
public final class ShopNpc {
    private ShopNpc() {}

    public static boolean isShopNpc(Entity entity) { return entity.getTags().contains(BedWarsMod.SHOP_TAG); }

    public static boolean spawn(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        Vec3 pos = source.getPosition();
        Villager villager = EntityType.VILLAGER.create(level, EntitySpawnReason.COMMAND);
        if (villager == null) return false;
        villager.setPos(pos.x, pos.y, pos.z);
        villager.setYRot(source.getRotation().y);
        villager.setNoAi(true);
        villager.setInvulnerable(true);
        villager.setSilent(true);
        villager.setPersistenceRequired();
        villager.setCustomName(Component.literal("§6§lSHOP"));
        villager.setCustomNameVisible(true);
        villager.addTag(BedWarsMod.SHOP_TAG);
        level.addFreshEntity(villager);
        return true;
    }

    /** Removes every shop villager (tagged "bw_shop") in every loaded dimension. Returns how many were removed. */
    public static int removeAll(MinecraftServer server) {
        int count = 0;
        for (ServerLevel level : server.getAllLevels()) {
            for (Villager villager : new ArrayList<>(level.getEntities(EntityTypeTest.forClass(Villager.class), ShopNpc::isShopNpc))) {
                villager.discard();
                count++;
            }
        }
        return count;
    }

    public static boolean removeNearest(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        Vec3 pos = source.getPosition();
        List<Villager> found = level.getEntitiesOfClass(Villager.class, new AABB(pos, pos).inflate(4), ShopNpc::isShopNpc);
        if (found.isEmpty()) return false;
        found.stream().min(Comparator.comparingDouble(v -> v.distanceToSqr(pos))).ifPresent(Entity::discard);
        return true;
    }
}
