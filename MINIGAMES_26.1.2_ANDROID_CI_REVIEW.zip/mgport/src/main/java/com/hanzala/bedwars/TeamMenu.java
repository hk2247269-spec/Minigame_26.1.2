package com.hanzala.bedwars;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Chest GUI where a player picks a team. Opened by /bw menu (and /bw team). No chat messages involved. */
public final class TeamMenu extends ServerGui {
    private static final int[] TEAM_SLOTS = {10, 11, 12, 14, 15, 16};
    private static final int MAX_NAMES = 8;

    public static void open(ServerPlayer player) {
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new TeamMenu(id, inv), Component.literal("Choose Your Team")));
    }

    private TeamMenu(int containerId, Inventory inventory) {
        super(3, containerId, inventory);
        build();
    }

    @Override
    protected void build() {
        reset();
        MinecraftServer server = viewer.serverLevel().getServer();
        if (server == null) return;
        BedWarsGameManager game = BedWarsMod.GAME;
        Map<String, List<String>> roster = game.getTeamRoster(server);
        String mine = game.teamOf(viewer);

        // Header: what is going on right now.
        List<String> status = new ArrayList<>();
        if (game.isRunning()) status.add("§cA match is running - teams are locked.");
        else if (game.isCountingDown()) status.add("§eThe match is about to start!");
        else status.add("§7Waiting in the lobby. Unequal teams are allowed.");
        status.add(mine == null ? "§7You have not picked a team yet." : "§7Your team: " + BedWarsGameManager.label(mine));
        put(4, icon(Items.NETHER_STAR, "§6§lBEDWARS", status));

        for (int i = 0; i < BedWarsGameManager.TEAMS.size() && i < TEAM_SLOTS.length; i++) {
            String team = BedWarsGameManager.TEAMS.get(i);
            List<String> names = roster.getOrDefault(team, List.of());
            List<String> lore = new ArrayList<>();
            lore.add("§7Players: §f" + names.size());
            for (int n = 0; n < names.size() && n < MAX_NAMES; n++) lore.add("§8- §f" + names.get(n));
            if (names.size() > MAX_NAMES) lore.add("§8...and " + (names.size() - MAX_NAMES) + " more");
            lore.add(" ");
            if (team.equals(mine)) lore.add("§a✔ You are on this team");
            else if (game.isRunning()) lore.add("§cLocked during a match");
            else lore.add("§eClick to join");
            if (!game.hasBed(team) || !game.hasSpawn(team)) lore.add("§c! Bed or spawn not set up yet");
            var stack = icon(teamWool(team), BedWarsGameManager.label(team), lore);
            if (team.equals(mine)) glow(stack);
            put(TEAM_SLOTS[i], stack, (p, button, shift) -> {
                if (BedWarsMod.GAME.assignTeam(p, team)) {
                    p.sendSystemMessage(Component.literal("You joined " + BedWarsGameManager.label(team) + "§r. Unequal team sizes are allowed."));
                } else {
                    p.sendOverlayMessage(Component.literal("§cYou cannot change team during a match."));
                }
                refresh();
            });
        }

        put(13, icon(Items.BARRIER, "§7Leave team", "§7Go back to having no team.",
                game.isRunning() ? "§cLocked during a match" : "§eClick to leave"), (p, button, shift) -> {
            if (!BedWarsMod.GAME.leaveTeam(p)) {
                p.sendOverlayMessage(Component.literal("§cYou are not in a team, or a match is running."));
            }
            refresh();
        });
    }
}
