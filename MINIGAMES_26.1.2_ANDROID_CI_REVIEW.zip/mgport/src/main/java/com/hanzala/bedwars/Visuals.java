package com.hanzala.bedwars;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Titles, sounds, action bar and particles. Every effect checks its own setting (see settings.txt), so a server
 * can switch any of them off. Sounds and coloured particles run as vanilla commands (same approach as Fx):
 * the command syntax is stable and a typo can only log a warning, never stop the mod.
 */
public final class Visuals {
    private Visuals() { }

    // ------------------------------------------------------------------ tiny tick scheduler

    private record Task(long due, Runnable run) { }

    private static long now;
    private static final List<Task> TASKS = new ArrayList<>();

    /** Called once per server tick. */
    public static void tick() {
        now++;
        if (TASKS.isEmpty()) return;
        List<Runnable> due = new ArrayList<>();
        for (Iterator<Task> it = TASKS.iterator(); it.hasNext(); ) {
            Task t = it.next();
            if (t.due() <= now) { due.add(t.run()); it.remove(); }
        }
        for (Runnable r : due) {
            try { r.run(); } catch (RuntimeException ex) { BedWarsMod.LOGGER.warn("A visual effect failed", ex); }
        }
    }

    static void later(int ticks, Runnable run) { TASKS.add(new Task(now + Math.max(0, ticks), run)); }

    public static void clear() { TASKS.clear(); resetMatch(); }

    /** Forget notifications and cached action-bar text (new match or match over). */
    public static void resetMatch() { NOTICES.clear(); LAST_BAR.clear(); LAST_BAR_AT.clear(); LOOT.clear(); }

    private static boolean on(String key) { return Settings.flag(key); }

    // ------------------------------------------------------------------ animated text

    private static final String[] HEADER_PALETTE = {"§6", "§6", "§6", "§6", "§e", "§f", "§e", "§6"};
    private static final String[] VICTORY_PALETTE = {"§6", "§e", "§f", "§e", "§6", "§6"};

    /** Colours every letter from a palette that slides along the text, which makes a shine that travels across. */
    static String wave(String text, int frame, String[] palette, String style) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == ' ') { b.append(' '); continue; }
            b.append(palette[Math.floorMod(i - frame, palette.length)]).append(style).append(c);
        }
        return b.toString();
    }

    /** Sidebar header for the given tick (a shine sweeps across the name about every 1.6 seconds). */
    public static String header(long tick) {
        if (!on("animated_scoreboard")) return "§6§lBED WARS";
        return "§e✦ " + wave("BED WARS", (int) ((tick / 4) % HEADER_PALETTE.length), HEADER_PALETTE, "§l") + " §e✦";
    }

    // ------------------------------------------------------------------ titles

    private static void send(ServerPlayer p, String title, String subtitle, int in, int stay, int out) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(in, stay, out));
        p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(subtitle)));
        p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(title)));
    }

    /** Standard title: smooth fade in and out (plain 0.5 s / 3 s / 0.5 s when title_animations is off). */
    public static void title(ServerPlayer p, String title, String subtitle) {
        if (on("title_animations")) send(p, title, subtitle, 10, 50, 20);
        else send(p, title, subtitle, 10, 60, 10);
    }

    /** Short title for quick events (respawn). */
    public static void quick(ServerPlayer p, String title, String subtitle) { send(p, title, subtitle, 0, 20, 10); }

    private static void titleAll(MinecraftServer server, String title, String subtitle) {
        for (ServerPlayer p : Dim.players(server)) title(p, title, subtitle);
    }

    /** Title whose letters shimmer for about 1.5 seconds (a plain title when title_animations is off). */
    private static void shimmer(ServerPlayer p, String text, String subtitle) {
        if (!on("title_animations")) { send(p, "§6§l" + text, subtitle, 10, 60, 10); return; }
        UUID id = p.getUUID();
        MinecraftServer server = p.serverLevel().getServer();
        for (int k = 0; k < 10; k++) {
            final int frame = k;
            later(k * 3, () -> {
                ServerPlayer pl = server == null ? null : server.getPlayerList().getPlayer(id);
                if (pl != null) send(pl, wave(text, frame, VICTORY_PALETTE, "§l"), subtitle, frame == 0 ? 10 : 0, 60, 20);
            });
        }
    }

    // ------------------------------------------------------------------ sounds

    public static void sfx(MinecraftServer server, String sound, float pitch) {
        if (on("event_sounds")) Fx.soundAll(server, "minecraft:" + sound, pitch);
    }

    public static void sfxTo(MinecraftServer server, ServerPlayer p, String sound, float pitch) {
        if (on("event_sounds")) Fx.sound(server, p, "minecraft:" + sound, pitch);
    }

    // ------------------------------------------------------------------ action bar

    private record Notice(String text, long until) { }
    private record Loot(String text, long at) { }

    private static final Map<UUID, Notice> NOTICES = new HashMap<>();
    private static final Map<UUID, String> LAST_BAR = new HashMap<>();
    private static final Map<UUID, Long> LAST_BAR_AT = new HashMap<>();
    private static final Map<UUID, Loot> LOOT = new HashMap<>();

    /** A message that takes over the action bar for a few seconds (kills, beds, loot...). Always shown. */
    public static void notify(ServerPlayer p, String text, int ticks) {
        UUID id = p.getUUID();
        NOTICES.put(id, new Notice(text, now + ticks));
        LAST_BAR.put(id, text);
        LAST_BAR_AT.put(id, now);
        p.sendOverlayMessage(Component.literal(text));
    }

    /** The regular live info line. Skipped while a notification is showing; resent only when it changed or is about to fade. */
    public static void info(ServerPlayer p, String text) {
        if (!on("action_bar")) return;
        UUID id = p.getUUID();
        Notice n = NOTICES.get(id);
        if (n != null) {
            if (now < n.until()) return;
            NOTICES.remove(id);
        }
        if (text.equals(LAST_BAR.get(id)) && now - LAST_BAR_AT.getOrDefault(id, -100L) < 40) return;
        LAST_BAR.put(id, text);
        LAST_BAR_AT.put(id, now);
        p.sendOverlayMessage(Component.literal(text));
    }

    /** Resources handed over by a kill; shown together with the kill notification that follows right after. */
    public static void loot(ServerPlayer killer, String text) { LOOT.put(killer.getUUID(), new Loot(text, now)); }

    // ------------------------------------------------------------------ particles

    private static int density(int base) {
        int d = Math.max(10, Math.min(300, Settings.integer("particle_density")));
        return Math.max(1, base * d / 100);
    }

    /** Cloud of dust in the team's colour. */
    private static void dust(MinecraftServer server, ServerLevel level, double x, double y, double z, String team,
                             double dx, double dy, double dz, int count, double scale) {
        Fx.run(server, String.format(Locale.ROOT, "execute in %s run particle minecraft:dust{color:%d,scale:%.1f} %.2f %.2f %.2f %.2f %.2f %.2f 0 %d force",
                level.dimension().location(), Fx.rgb(team), scale, x, y, z, dx, dy, dz, density(count)));
    }

    public static void bedBurst(MinecraftServer server, ServerLevel level, BlockPos pos, String team) {
        if (!on("team_particles")) return;
        double x = pos.getX() + 0.5, y = pos.getY() + 0.6, z = pos.getZ() + 0.5;
        dust(server, level, x, y, z, team, 1.0, 0.6, 1.0, 90, 1.6);
        level.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
        level.sendParticles(ParticleTypes.FIREWORK, x, y + 0.3, z, density(25), 0.6, 0.4, 0.6, 0.08);
    }

    private static void eliminationBurst(MinecraftServer server, ServerPlayer victim, String team) {
        if (!on("team_particles") || !(victim.level() instanceof ServerLevel level)) return;
        double x = victim.getX(), y = victim.getY(), z = victim.getZ();
        dust(server, level, x, y + 1.0, z, team, 0.5, 1.0, 0.5, 60, 1.4);
        level.sendParticles(ParticleTypes.SOUL, x, y + 1.0, z, density(20), 0.4, 0.8, 0.4, 0.03);
    }

    private static void celebrate(MinecraftServer server, String team, Collection<UUID> winners) {
        if (!on("team_particles")) return;
        Set<UUID> ids = new HashSet<>(winners);
        for (int k = 0; k < 28; k++) {
            final int step = k;
            later(k * 5, () -> {
                for (UUID id : ids) {
                    ServerPlayer p = server.getPlayerList().getPlayer(id);
                    if (p == null || !(p.level() instanceof ServerLevel level)) continue;
                    double a = step * 0.7;
                    dust(server, level, p.getX() + Math.cos(a) * 1.3, p.getY() + (step % 8) * 0.3, p.getZ() + Math.sin(a) * 1.3,
                            team, 0.3, 0.3, 0.3, 14, 1.4);
                    level.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 2.2, p.getZ(), density(4), 0.5, 0.2, 0.5, 0.04);
                    if (step % 6 == 0) level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, p.getX(), p.getY() + 1.0, p.getZ(), density(15), 0.5, 0.8, 0.5, 0.2);
                }
            });
        }
    }

    // ------------------------------------------------------------------ countdown

    /** One step of the start countdown (called once per second with the seconds left, 1 or more). */
    public static void countdown(MinecraftServer server, int seconds, int titlesFrom) {
        boolean big = seconds <= titlesFrom;
        String colour = seconds <= 1 ? "§c" : seconds == 2 ? "§6" : seconds == 3 ? "§e" : "§a";
        for (ServerPlayer p : Dim.players(server)) {
            if (big) send(p, colour + "§l" + seconds, seconds == 1 ? "§7Get ready!" : "§7The match is about to start", 0, 14, 6);
            else p.sendOverlayMessage(Component.literal("§eGame starts in §6§l" + seconds + "§e seconds"));
        }
        if (big) sfx(server, "block.note_block.pling", Math.min(2.0F, 0.7F + (titlesFrom - seconds) * 0.15F));
    }

    /** The GO! at the end of the countdown (also used when the countdown is set to 0). */
    public static void go(MinecraftServer server) {
        for (ServerPlayer p : Dim.players(server)) {
            if (on("title_animations")) send(p, "§a§lGO!", "§7Protect your bed and destroy the others!", 0, 24, 12);
            else send(p, "§a§lGO!", "§7Protect your bed and destroy the others!", 10, 60, 10);
        }
        sfx(server, "entity.player.levelup", 1.2F);
    }

    // ------------------------------------------------------------------ match events

    /** A timeline milestone: chat line, title for everybody and a sound. */
    public static void milestone(MinecraftServer server, String title, String subtitle, String chat, String sound, float pitch) {
        Dim.broadcast(server, Component.literal(chat), false);
        titleAll(server, title, subtitle);
        sfx(server, sound, pitch);
    }

    /** The last ten seconds before the time is up. */
    public static void finalSecond(MinecraftServer server, int left, String what) {
        for (ServerPlayer p : Dim.players(server)) {
            if (left <= 5) send(p, "§c§l" + left, "§7" + what, 0, 14, 6);
            else notify(p, "§c§l" + left + " §7" + what, 25);
        }
        sfx(server, "block.note_block.pling", 1.0F + (10 - left) * 0.08F);
    }

    public static void bedDestroyed(MinecraftServer server, ServerLevel level, BlockPos pos, String team,
                                    ServerPlayer breaker, Collection<ServerPlayer> victims) {
        String label = BedWarsGameManager.label(team);
        for (ServerPlayer p : Dim.players(server)) {
            if (victims.contains(p)) {
                title(p, "§c§lBED DESTROYED", "§7You will no longer respawn!");
                sfxTo(server, p, "entity.ender_dragon.growl", 1.0F);
            } else if (p == breaker) {
                notify(p, "§6§l✦ BED DESTROYED §r" + label, 60);
                sfxTo(server, p, "entity.player.levelup", 0.8F);
            } else {
                notify(p, label + " §cbed was destroyed", 50);
            }
        }
        sfx(server, "entity.wither.break_block", 1.0F);
        bedBurst(server, level, pos, team);
    }

    public static void kill(MinecraftServer server, ServerPlayer killer, String victimName, boolean finalKill) {
        String text = finalKill ? "§c§l✖ FINAL KILL §7" + victimName : "§a§l+1 KILL §7" + victimName;
        Loot loot = LOOT.remove(killer.getUUID());
        if (loot != null && now - loot.at() < 40) text += " §8| " + loot.text();
        notify(killer, text, 50);
        sfxTo(server, killer, finalKill ? "ui.toast.challenge_complete" : "entity.player.levelup", finalKill ? 1.0F : 1.5F);
    }

    public static void eliminated(MinecraftServer server, ServerPlayer victim, String team) {
        title(victim, "§4§lELIMINATED", "§7Your bed is gone: you are now spectating");
        sfxTo(server, victim, "entity.elder_guardian.curse", 1.0F);
        sfx(server, "entity.wither.hurt", 0.7F);
        eliminationBurst(server, victim, team);
    }

    // ------------------------------------------------------------------ end of the match

    /**
     * Victory / defeat for everybody once the match is over. winner may be null (draw); winnerIds are the winning
     * team's players; teams maps every player to the team they played in.
     */
    public static void matchEnd(MinecraftServer server, String winner, Set<UUID> winnerIds, Map<UUID, String> teams) {
        boolean celebrating = on("victory_celebration");
        String winLabel = winner == null ? null : BedWarsGameManager.label(winner);
        for (ServerPlayer p : Dim.players(server)) {
            UUID id = p.getUUID();
            if (winner == null) {
                title(p, "§e§lMATCH ENDED", "§7Nobody won this match");
                sfxTo(server, p, "block.bell.use", 0.8F);
            } else if (!celebrating) {
                title(p, winLabel + " §a§lWINS!", "§7Back to the lobby");
            } else if (winnerIds.contains(id)) {
                shimmer(p, "VICTORY!", "§e" + winLabel + " §7wins the match!");
                sfxTo(server, p, "ui.toast.challenge_complete", 1.0F);
                later(10, () -> sfxTo(server, p, "entity.firework_rocket.launch", 1.0F));
                later(20, () -> sfxTo(server, p, "entity.player.levelup", 1.0F));
            } else if (teams.containsKey(id)) {
                title(p, "§c§lDEFEAT", "§7" + winLabel + " §7won the match");
                sfxTo(server, p, "entity.wither.death", 0.8F);
            } else {
                title(p, winLabel + " §6§lWINS!", "§7The match is over");
                sfxTo(server, p, "ui.toast.challenge_complete", 1.0F);
            }
        }
        if (winner == null || !celebrating) return;
        List<String> names = new ArrayList<>();
        for (UUID id : winnerIds) {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p != null) names.add(p.getGameProfile().getName());
        }
        String bar = "§6§m                                        ";
        Dim.broadcast(server, Component.literal(bar), false);
        Dim.broadcast(server, Component.literal("§6§l            ★ VICTORY ★"), false);
        Dim.broadcast(server, Component.literal("   " + winLabel + " §7team wins the match!"), false);
        if (!names.isEmpty()) Dim.broadcast(server, Component.literal("   §7Winners: §f" + String.join("§7, §f", names)), false);
        Dim.broadcast(server, Component.literal(bar), false);
        celebrate(server, winner, winnerIds);
    }
}
