package com.hanzala.minigames;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Red Light, Green Light.
 *
 * Convention: the admin stands ON the finish line and runs /mg arena finish &lt;id&gt;. The goal axis is the axis (X or Z) along which
 * the finish is farthest from the centre of the spawns; the goal direction points from the spawns towards the finish. A player
 * qualifies as soon as their coordinate on that axis reaches the finish coordinate (inside the arena box). The statue (a
 * non-moving villager tagged mg_rg_statue) stands at the finish and faces the players on RED, turns its back on GREEN.
 * A wool-like concrete block under the statue shows the phase (green / red); it is journaled and restored.
 *
 * Rules: GREEN = run. RED = freeze. On RED, after a grace period (redGrace ticks, default 10), a player whose horizontal speed
 * stays above 0.08 blocks/tick for 2 consecutive ticks is eliminated (vertical movement is ignored). Qualified players are
 * moved to spectator mode and are the winners: the match ends when nobody is left alive (everybody qualified or eliminated), or at
 * the time limit (arena param timeLimit, default = global maxMatchSeconds); winners = ALL players who qualified.
 *
 * Params: greenMin, greenMax (default 3-7 s), redMin, redMax (default 2-5 s), redGrace (ticks, default 10), timeLimit (seconds).
 */
public final class RedGreenSession extends GameSession {
    public static final String TAG = "mg_rg_statue";
    /** Statues owned by a running match; every other tagged entity that loads is a leftover and is removed. */
    private static final Set<UUID> LIVE_STATUES = new HashSet<>();

    private static final double MOVE_LIMIT = 0.08;

    private final BlockJournal journal;
    private final Set<UUID> qualified = new LinkedHashSet<>();
    private final Map<UUID, double[]> last = new HashMap<>();
    private final Map<UUID, Integer> strikes = new HashMap<>();

    private Villager statue;
    private boolean green;
    private int phaseTicksLeft;
    private int redTicks;
    private boolean axisX;
    private int dir;
    private double line;
    private float yawToPlayers;
    private BlockPos indicator;

    public RedGreenSession(MinecraftServer server, Arena arena) {
        super(server, arena, MinigameType.RED_GREEN);
        this.journal = new BlockJournal(arena);
    }

    /** Registers the cleanup of statues left behind by a crash. Call once from MgMod.onInitialize. */
    public static void registerCleanup() {
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity.getTags().contains(TAG) && !LIVE_STATUES.contains(entity.getUUID())) {
                world.getServer().execute(entity::discard);
            }
        });
    }

    /** Removes every leftover statue in loaded chunks (server start). */
    public static void purgeLoaded(MinecraftServer server) {
        for (net.minecraft.server.level.ServerLevel l : server.getAllLevels()) {
            for (Villager v : new ArrayList<>(l.getEntities(net.minecraft.world.level.entity.EntityTypeTest.forClass(Villager.class),
                    e -> e.getTags().contains(TAG) && !LIVE_STATUES.contains(e.getUUID())))) {
                v.discard();
            }
        }
    }

    // ------------------------------------------------------------------ settings

    private int rnd(String minKey, String maxKey, int defMin, int defMax) {
        int a = (int) Math.max(1, arena.param(minKey, defMin));
        int b = (int) Math.max(a, arena.param(maxKey, defMax));
        return (a + ThreadLocalRandom.current().nextInt(b - a + 1)) * 20;
    }

    @Override
    protected int timeLimitSeconds() { return (int) Math.max(10, arena.param("timeLimit", MgSettings.I.maxMatchSeconds)); }

    @Override
    protected List<UUID> timeoutWinners() { return new ArrayList<>(qualified); }

    // ------------------------------------------------------------------ lifecycle hooks

    @Override
    protected void onPrepare() {
        qualified.clear();
        last.clear();
        strikes.clear();
        green = true;
        redTicks = 0;
        Arena.Loc f = arena.finish;
        // goal axis / direction: from the centre of the spawns to the finish
        double cx = 0, cz = 0;
        for (Arena.Loc s : arena.spawns) { cx += s.x; cz += s.z; }
        cx /= arena.spawns.size();
        cz /= arena.spawns.size();
        double dx = f.x - cx, dz = f.z - cz;
        axisX = Math.abs(dx) > Math.abs(dz);
        dir = (axisX ? dx : dz) >= 0 ? 1 : -1;
        line = axisX ? f.x : f.z;
        // the statue faces the players (opposite of the goal direction) on RED
        double fx = axisX ? -dir : 0, fz = axisX ? 0 : -dir;
        yawToPlayers = (float) Math.toDegrees(Math.atan2(-fx, fz));
        spawnStatue();
        indicator = BlockPos.containing(f.x, f.y - 1, f.z);
        if (!journal.capture(level, indicator)) indicator = null;
        journal.flush(); // original block is on disk before it is changed
        setLight(true);
    }

    @Override
    protected void onStart() {
        phaseTicksLeft = rnd("greenMin", "greenMax", 3, 7);
        green = true;
        applyPhaseVisuals();
        announce(true);
        snapshotPositions();
    }

    @Override
    protected void tickActive() {
        if (--phaseTicksLeft <= 0) {
            green = !green;
            redTicks = 0;
            phaseTicksLeft = green ? rnd("greenMin", "greenMax", 3, 7) : rnd("redMin", "redMax", 2, 5);
            applyPhaseVisuals();
            announce(green);
            snapshotPositions();
        }
        if (!green) redTicks++;
        int grace = (int) Math.max(0, arena.param("redGrace", 10));

        for (ServerPlayer p : online(alive)) { // copy: eliminate() / qualify() edit the set
            UUID id = p.getUUID();
            if (!alive.contains(id)) continue;
            double x = p.getX(), z = p.getZ();

            // finish line
            double coord = axisX ? x : z;
            if ((coord - line) * dir >= 0 && arena.containsXZ(x, z)) { qualify(p); continue; }
            if (!arena.contains(x, p.getY(), z) && p.getY() < arena.minY() - 5) { eliminate(p, "fell out of the arena"); continue; }

            // movement check (RED only, after the grace period)
            double[] prev = last.get(id);
            last.put(id, new double[] { x, z });
            if (green || redTicks <= grace || prev == null) { strikes.put(id, 0); continue; }
            double moved = Math.hypot(x - prev[0], z - prev[1]);
            if (moved > 3.0) { strikes.put(id, 0); continue; } // teleport, not walking
            if (moved > MOVE_LIMIT) {
                int s = strikes.merge(id, 1, Integer::sum);
                if (s >= 2) { eliminate(p, "moved on red light"); strikes.remove(id); }
            } else {
                strikes.put(id, 0);
            }
        }
        if (matchTicks % 10 == 0) {
            journal.flush();
            Component bar = Component.literal(green ? "§a§lGREEN LIGHT §7- run!" : "§c§lRED LIGHT §7- freeze!");
            for (ServerPlayer p : online(players)) p.sendOverlayMessage(bar);
        }
    }

    private void snapshotPositions() {
        last.clear();
        strikes.clear();
        for (ServerPlayer p : online(alive)) last.put(p.getUUID(), new double[] { p.getX(), p.getZ() });
    }

    private void announce(boolean isGreen) {
        for (ServerPlayer p : online(players)) {
            if (isGreen) {
                MgUtil.title(p, "§a§lGREEN LIGHT", "§7Run!", 0, 15, 5);
                MgUtil.snd(p, SoundEvents.EXPERIENCE_ORB_PICKUP, 1f, 1.6f);
            } else {
                MgUtil.title(p, "§c§lRED LIGHT", "§7Freeze!", 0, 15, 5);
                MgUtil.snd(p, SoundEvents.ANVIL_LAND, 0.6f, 1.2f);
            }
        }
    }

    private void applyPhaseVisuals() {
        setLight(green);
        if (statue != null && !statue.isRemoved()) {
            float yaw = green ? yawToPlayers + 180f : yawToPlayers; // GREEN: back turned, RED: facing the players
            statue.setYRot(yaw);
            statue.setYHeadRot(yaw);
            statue.setYBodyRot(yaw);
            statue.setCustomName(Component.literal(green ? "§a§lGREEN" : "§c§lRED"));
        }
    }

    private void setLight(boolean isGreen) {
        if (indicator == null) return;
        level.setBlock(indicator, (isGreen ? Blocks.GREEN_CONCRETE : Blocks.RED_CONCRETE).defaultBlockState(), 2);
    }

    private void qualify(ServerPlayer p) {
        UUID id = p.getUUID();
        if (state != State.ACTIVE || !alive.remove(id)) return;
        qualified.add(id);
        spectators.add(id);
        p.setGameMode(GameType.SPECTATOR);
        MgUtil.title(p, "§a§lQUALIFIED!", "§7You reached the finish line", 0, 40, 10);
        p.sendSystemMessage(MgUtil.msg("You are spectating. Type §e/mg leave§7 to go back to the lobby."));
        MgUtil.snd(p, SoundEvents.PLAYER_LEVELUP, 1f, 1f);
        tell("§a" + p.getName().getString() + " §7reached the finish §8(§f" + qualified.size() + " §7qualified, §f" + alive.size() + " §7still running§8)");
        checkWin();
    }

    /** Ends when nobody is left to run; all qualified players win. */
    @Override
    protected void checkWin() {
        if (state != State.ACTIVE) return;
        if (!alive.isEmpty()) return;
        List<UUID> winners = new ArrayList<>();
        for (UUID id : qualified) if (players.contains(id)) winners.add(id);
        end(winners);
    }

    @Override
    protected List<String> activeLines(ServerPlayer p) {
        return List.of(green ? "§aGREEN LIGHT" : "§cRED LIGHT", "§7Qualified: §f" + qualified.size());
    }

    // ------------------------------------------------------------------ statue

    private void spawnStatue() {
        removeStatue();
        Arena.Loc f = arena.finish;
        Villager v = EntityType.VILLAGER.create(level, EntitySpawnReason.COMMAND);
        if (v == null) return;
        v.setPos(f.x, f.y, f.z);
        v.setNoAi(true);
        v.setNoGravity(true);
        v.setInvulnerable(true);
        v.setSilent(true);
        v.setPersistenceRequired();
        v.setCustomName(Component.literal("§a§lGREEN"));
        v.setCustomNameVisible(true);
        v.addTag(TAG);
        LIVE_STATUES.add(v.getUUID()); // before adding: the load event must not treat it as a leftover
        level.addFreshEntity(v);
        statue = v;
    }

    private void removeStatue() {
        if (statue != null) {
            LIVE_STATUES.remove(statue.getUUID());
            statue.discard();
            statue = null;
        }
    }

    @Override
    protected void onMatchOver() {
        removeStatue();
        journal.flush();
    }

    @Override
    protected boolean resetStep() {
        removeStatue();
        return journal.restoreSome(level, MgSettings.I.resetBlocksPerTick);
    }

    @Override
    public void flushToDisk() {
        removeStatue();
        journal.flush();
    }
}
