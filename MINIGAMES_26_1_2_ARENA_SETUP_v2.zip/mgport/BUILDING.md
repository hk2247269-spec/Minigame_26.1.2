# Building MINIGAMES for Minecraft 26.1.2

Target: Minecraft 26.1.2, Fabric Loader 0.19.3, Fabric API 0.155.3+26.1.2, Java 25, Gradle 9.4.1, Fabric Loom 1.16.1.

## Build in GitHub Actions
1. Create a GitHub repository on your phone.
2. Upload this source project or upload the source ZIP into the repository.
3. Ensure `.github/workflows/build.yml` is in the repository. If uploading the ZIP as a single file, the workflow can locate and extract it.
4. Open the repository's **Actions** tab.
5. Select **MINIGAMES 26.1.2 Source Build** and run it (or wait for a push-triggered run).
6. Open the run. If it succeeds, download the artifact named `MINIGAMES-26.1.2-build-outputs` from the run's Artifacts section. Build logs/reports are included where generated.

## Local build
Use Java 25 and Gradle 9.4.1, then run `gradle clean build --no-daemon` from this project folder.

A successful CI compilation is not proof that all minigame features work in-game. Test on a 26.1.2 server before use.
