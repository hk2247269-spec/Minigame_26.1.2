# Changelog

## 1.3.0 (arena setup wizard)
### Added
- `/mg setup` wizard: shared lobby, one default arena per game (`tnt`, `lava`, `rg`) with optional extra arenas, **Check arena** and **Enable**; links to the BedWars panel and `/hs setup`.
- Arena validation, `enabled` flag, per-arena sessions with isolation and reset, dimension stored per arena.
- `arenas.json` schema 2 with automatic migration (`arenas.json.v1.bak`, atomic saves, corrupt-file copy).
- `docs/ARENA_SETUP.md`, per-game test checklist in `docs/MINIGAMES_README.md`, schema 2 example in `config-example/minigames/`.
### Not verified
- Not compiled against 26.1.2 and not played in-game. The loose-item cleanup (`GameSession.clearLooseEntities`) uses `getEntitiesOfClass`, the same call BedWars and Hide & Seek already use; check it first if the build complains.
- The wizard does not create BedWars or Hide & Seek arenas themselves.

## 1.1.1 (debug pass)
### Fixed
- **Floor Is Lava**: lava could flow out of the arena box / below `startY` and was never restored. Lava the session did not place itself is now refused while a lava match is on (`LevelMixin` + `FloorLavaSession.blocksFlow`), and the final restore may put lava back.
- **Floor Is Lava**: a layer could be skipped when filling took longer than `riseSeconds`; rises now use a `nextRiseTick` timer.
- **Reset journal lag**: `BlockJournal` no longer rewrites its whole file every 10 ticks; new entries are appended (one JSON object per line). Old array-format files and half-written last lines are still read after a crash.
- **TNT Run**: the TNT block under a floor block is only removed when it is journaled (inside the arena box).
- A leftover player backup is restored before a new one is made, so an old inventory can never come back over a newer one; the join is refused if it cannot be restored.
- `/mg reload` no longer stops BedWars / Hide & Seek matches (only arena minigames).
- Eliminated / qualified players are told to use `/mg leave` (spectators cannot use the barrier).
- Startup log shows the real mod version; docs: `pos1`/`pos2` use the block your feet are in.
### Still not verified
- **Not compiled**: no JDK compiler / Minecraft jars / network where this was edited. Brackets were re-checked and only APIs already used in the project were added. Build with the GitHub workflow and send any red lines.
- Confirm `fabric_api_version` in `gradle.properties` exists for 1.21.8.

## 1.1.0 (Minigames network)
### Added
- `/mg` command + GUI for five games: BedWars, Hide & Seek, TNT Run, Floor Is Lava, Red Light Green Light (see `docs/MINIGAMES_README.md`).
- Shared `GameSession` lifecycle (waiting, countdown, start, active, ending, reset), `PlayerStateStore` (inventory/mode/health/XP/effects backup, crash recovery), `BlockJournal` (arena reset, crash recovery), one common lobby, admin force commands.
- **Floor Is Lava** (`FloorLavaSession`): rising lava layers inside the arena box, journaled and restored.
- **Red Light, Green Light** (`RedGreenSession`): `/mg arena finish`, statue NPC + green/red block, grace-period movement check, qualified players win.
- `BedWarsAdapter` and `HideSeekAdapter` connect the two existing engines to `/mg`.
### Changed
- **Hide & Seek now runs in the Overworld** (no End teleports). Arenas use Overworld coordinates; the "TO THE END" NPCs became `/hs npc add menu` NPCs that open `/mg`. After a match players return to the common lobby.
- BedWars only treats players who are not in another minigame as BedWars players (`Dim`), clears teams when a match ends, no longer opens the team menu on join, no longer spectates/wipes lobby visitors, and its sidebar only shows to team members.
- BedWars, Hide & Seek and Minigames sidebars carry the `Owner: HANZALA` line.
- Dropped menu compass / leave barrier items are removed and handed back; hunger is held at full in minigames.
- Mod name/description, `mod_version` 1.1.0, jar `minigames-fabric-1.21.8-1.1.0.jar`.
### Not verified
- **Not compiled and not play-tested** (the environment this was written in had no JDK compiler, Gradle, Minecraft jars or network). Brackets of every file were checked and calls between the mod's own classes were cross-read. Build with the GitHub workflow or `gradle build` and fix any compile line first, then run the test checklist in the project notes.

## 1.0.2-beta (travel commands + NPCs)
### Added
- `/hs` outside the End now teleports you to the End (first arena lobby if one is set, otherwise the obsidian platform at 100 48 0). Type `/hs` again inside the End to open the menu.
- `/bw` outside the Overworld (End or Nether) now teleports you to the Overworld (BedWars lobby if set, otherwise world spawn). Leaves a Hide & Seek game first so your inventory is returned. Inside the Overworld `/bw` shows help as before.
- Travel NPCs (frozen, invulnerable villagers): `/hs npc add end` (right-click = go to the End), `/hs npc add overworld` (right-click = go to the Overworld), `/hs npc remove` (nearest within 4 blocks). Op only.
- New class `Hub`; `BedWarsGameManager.teleportToLobbyFrom`.
### Not verified
- Not compiled (no JDK/Minecraft jars here). Build with the GitHub workflow and send any red lines.

## 1.0.1-beta (review pass)
### Fixed
- Hide & Seek no longer keeps a reference to a stopped server (`SERVER_STOPPED` clears it).
- Hide & Seek and BedWars player backups are safe if they are used before their folder exists (no crash, they simply do nothing).
- `spectateTeammate` (BedWars team spectator menu) cannot fail on a missing server.
### Checked (no problem found)
- Syntax of all 54 Java files parses cleanly with the JDK 21 compiler; every call between the mod's own classes (`BedWarsMod.GAME.*`, `Dim.*`, `Settings.*`, `Sidebar.*`, `BedWarsBackup.*`, `TeamPovMenu`, `Backup.*` ...) points at a method that exists.
- Mixin target names, `fabric.mod.json` entrypoints and `bedwars.mixins.json` match the source files.
### Not verified
- **Still not compiled against Minecraft 1.21.8** (the Minecraft/Fabric jars cannot be downloaded in the review environment), so calls into Minecraft/Fabric were only read, not compiled. Build it with the GitHub workflow and send any red lines.

## 1.0.0-beta (BedWars 0.13.1 + End Hide & Seek 1.0.0, merged)
### Added
- **One jar, two games, one Minecraft version (1.21.8).** BedWars runs in the **Overworld**, Hide & Seek runs in **The End**; both register their own commands (`/bw`, `/hs`) and keep their own config folders.
- New `Dim` helper: every BedWars effect that used to reach "all online players" (titles, sounds, chat lines, inventory reset at match end, spectator mode, action bar, countdown, victory celebration, team chat colours) now reaches only players in the Overworld.
### Changed
- **BedWars sidebar is per player**: sent as packets only to Overworld players and removed when a player enters the End (back again when they return). It no longer uses a server-wide scoreboard objective; the `bwm_<team>` colour teams still use the real scoreboard but only for Overworld players. Any old `bwm_side` objective from a crash is removed at start.
- BedWars damage rules, death/respawn handling, join teleport and build restrictions ignore players that are not in the Overworld, so they never affect Hide & Seek (the End has its own rules).
- BedWars "everybody" sounds use `execute ... if dimension minecraft:overworld`.
- Hide & Seek was moved from Minecraft 1.21.9 to 1.21.8 (no code changes were needed in its own classes).
- Hide & Seek refuses `/hs join` for a player who is on a team in a running BedWars match.
- Mod id is now `bedwars_hideseek` (two entrypoints). It replaces the separate `bedwars` and `endhideseek` jars - remove them.
### Known limits
- Game rules set by BedWars during a match (`doTileDrops`, `doImmediateRespawn`) are server-wide in 1.21.8, so they also apply in the End while a BedWars match runs.
- Nether players are ignored by both games.
### Not verified
- **Not compiled and not play-tested** (no JDK compiler, Minecraft or network in the build environment). Brackets and cross-class calls were checked by hand; new code only uses packet classes already used by the Hide & Seek HUD plus `ClientboundResetScorePacket`. Build it with the GitHub workflow and send any red error lines.

## 0.13.1-beta
### Added
- **`/bw setup clear`** (operators): removes the whole arena setup in one go. Run it once to see what will be removed, then `/bw setup clear confirm` to do it. It clears the lobby, all team spawns, all registered beds (the bed blocks stay in the world), all generators and generator tiers, all protected regions and every shop villager. Shop prices, settings and player teams are kept. Refused while a match or countdown is running.
### Not verified
- **Not compiled and not play-tested** (no JDK, Minecraft or network here). The new code only uses APIs and patterns already used elsewhere in the mod, plus `MinecraftServer.getAllLevels()` and `ServerLevel.getEntities(EntityTypeTest, Predicate)`.

## 0.13.0-beta
### Added
- **Admin shop editor** (`/bw admin` -> Shop & Prices): per item, armour tier and generator upgrade: price, currency, amount, on/off, reset; plus +/-10% on all prices and reset-all. Stored in `config/bedwars/shop.txt` (new file; `/bw reload` re-reads it).
- **Admin generator editor** (`/bw admin` -> Generators): team Iron/Gold/Diamond speeds per tier, neutral Diamond/Emerald speeds, item limit per generator, set any team's generator tier. New settings `gen_iron_t1..t3`, `gen_gold_t2/t3`, `gen_diamond_t3`, `gen_cap_iron/gold/diamond/emerald` (defaults equal the old hard-coded values).
- Generator upgrade costs (Tier II, Tier III) are now editable (`upgrade.2`, `upgrade.3a`, `upgrade.3b`).
### Changed
- The shop GUI, `/bw shop list`, `/bw shop buy` and the generator upgrade all read prices from `shop.txt`; the shop tooltip shows the real tier speeds.
- The Settings screen no longer lists the `gen_*` numbers (they live in the Generators screen).
### Not verified
- **Not compiled and not play-tested** (no JDK, Minecraft or network here). Brackets were checked and calls between the mod's own classes were reviewed by hand; calls into Minecraft/Fabric reuse only APIs already used elsewhere in this code.

## 0.12.0-beta
### Added
- **22-minute match timeline** (`match_duration_seconds=1320`): Generator Upgrade I at 05:00, Upgrade II at 10:00, warnings at 15:00, 18:00 and 20:00, a 10-second final countdown, and at 22:00 `match_end_action` (`sudden_death`, `draw` or `most_alive`; `sudden_death_minutes` for the sudden-death length). Events fire once, the timer follows the match state and is only reset by a new match start.
- **Animated scoreboard**: shimmering header, elapsed and remaining time, next event, per-team bed / players / kills / generator tier, current emerald and diamond speeds. Updated once per match second for a synchronized clock.
- **Title animations** (countdown 5-4-3-2-1-GO!, bed destroyed, elimination, team eliminated, timeline events, victory shimmer, defeat) and **event sounds**.
- **Live action bar** with team, bed, generator tier and your own resources; kill/loot/bed notifications temporarily replace it.
- **Team-coloured particles** for bed destruction, elimination and victory; **victory celebration** (banner, titles, sounds, particle spiral, fireworks).
- **Polished shop GUI**: categories, currency colours, owned counts, descriptions, affordability, tier-by-tier generator upgrade information and a match clock tile. The shop refreshes after each click.
- 18 new settings (all visible and editable in `/bw admin` -> Settings, which now has 6 rows and choice settings).
### Changed
- `bed_gone_minutes`, `match_limit_minutes` and `emerald_fast_after_minutes` are gone (old values in an existing `settings.txt` are ignored). The 20-minute bed removal and 30-minute limit were replaced by the new timeline.
- Neutral generator speeds now follow the timeline upgrade level instead of a separate emerald timer.
- Titles at the end of a match are sent after players are back in the lobby.
### Not verified
- **Not compiled and not play-tested**: no Minecraft, Gradle or network was available. Syntax and name-level consistency between the mod's own classes were checked; calls into Minecraft/Fabric were not. Particle and sound effects use vanilla commands (like the existing fireworks); a wrong command can only log a warning.

## 0.11.0-beta
### Added
- **Team GUI for players**: `/bw menu` (or `/bw team`) now opens a chest GUI with one wool block per team (player list, click to join), a Leave button and a status header. The old chat buttons are gone.
- **Admin GUI**: `/bw admin` opens a chest GUI (operators only; permission is re-checked on every click) with:
  - Start match / Stop (shows why a start is refused inside the GUI),
  - Setup checklist and generator summary,
  - **Players & Teams**: click a player, then a team, to move them,
  - **Arena Setup**: set lobby, team spawn, team bed and team generator, add neutral diamond/emerald generators, remove a generator,
  - **Settings**: toggle switches and raise/lower numbers; changes are written to `settings.txt`.
- New settings: `neutral_diamond_seconds` (30), `emerald_seconds` (60), `emerald_fast_after_minutes` (5), `emerald_fast_seconds` (40).
### Changed
- **Generators**: neutral Diamond = 1 per 30 s and neutral Emerald = 1 per 60 s both start with the match (no team needed). Emerald speeds up to 1 per 40 s after 5 minutes, with an announcement.
- A team's generators now only run while that team is playing in the match (a team nobody joined has no generator). Previously a team's generators paused whenever all its members were offline.
- Every team's Iron generator uses the same speed per tier and starts its first cycle at the same moment.
### Not verified
- Not compiled against Minecraft and not play-tested (no Minecraft/Gradle in the environment). Syntax-checked and cross-checked between the mod's own classes only.

## 0.10.0-beta
### Added (ported from or inspired by the v17 BedWars datapack; every one is switchable in `settings.txt`)
- Start countdown with titles and sounds; auto-cancel when fewer than 2 teams remain; `/bw stop` cancels it.
- Sidebar scoreboard (lobby panel and live match board) using only `bwm_*` scoreboard objects.
- Team colours for nametags, tab list and chat via scoreboard teams `bwm_<team>`; `/bw tc <message>` team chat.
- Team-coloured leather armour kit at spawn.
- Kill rewards (resources go to the killer), last-attacker credit for void deaths, clean death drops (kit is re-issued).
- Match timeline: bed destruction (default 20 min, 1-minute warning) and a draw at the time limit (default 30 min).
- Instant TNT (default 2 s fuse, credited to the placer).
- No-build zones: outside the protected arena, and around generators and team spawns.
- Persistent stats (`/bw stats`, `/bw top`) and an end-of-match summary.
- Victory fireworks, generator and bed particles, hunger refill, match-only game rules.
- Crash recovery: a match that was running when the server stopped is reset on the next start.
- `settings.txt` (17 switches) and `/bw reload`.
### Changed
- `/bw start` now runs the countdown first (set `countdown_seconds=0` for the old instant start).
- Respawn time is read from `respawn_seconds` (default still 5).
### Not verified
- Not compiled or play-tested (no Minecraft/Gradle available when this was written). Checked for syntax and for consistency between the mod's own classes only.

## 0.9.0-beta (this release)
### Fixed
- Explosion protection targeted a class/method that no longer exists in 1.21.8 (`Explosion.finalizeExplosion`). Now hooks `ServerExplosion.interactWithBlocks`.
- Registering a bed was off by one block: it looked below the player's feet. Now uses what you look at, then your feet, then the block below.
- `ServerPlayerEvents.JOIN` does not exist; replaced with `ServerPlayConnectionEvents.JOIN`.
- `Level` vs `ServerLevel` type mismatches in commands.
- Teams could break their own bed.
- Teleport used an unstable signature; now uses `connection.teleport`.
- Every block change allocated strings (lag). Protection now uses packed positions and exits early.
- Placed-block file was rewritten on every placement; now saved in batches.
- Generator timing used a global clock so tier changes shifted timers; each generator now has its own timer.
- Config path now uses Fabric's config directory.
### Added
- Win condition and full match reset (beds restored, placed blocks removed, generators/tiers reset, players returned to lobby).
- Final kills, 5-second respawn timer, bed-destroyed titles, friendly-fire block, no damage in lobby.
- Chest-GUI shop (`/bw shop`), villager shop NPCs (`/bw npc add`).
- Real enchantments (Power I bow, Knockback stick, Efficiency tools) and Speed II / Jump V potions.
- Armour tier is kept after death.
- Lobby (`/bw lobby set`), setup checklist (`/bw setup`), in-game region commands, tab-completion, action-bar status.
- Team generators now include Diamond (Tier III) automatically.
- GitHub Actions workflow to build the jar for you.

## Player experience update
- BedWars now saves each participant's pre-match player state to a dedicated persistent backup and restores it after the match or on a later lobby join. This is separate from Hide & Seek backups.
- BedWars lobby team selection opens automatically when a player joins the configured lobby, reducing the need for `/bw menu`.
- Final-kill eliminated players receive an automatic team POV GUI listing only surviving teammates; selecting a teammate switches spectator camera to them.
- Hide & Seek backups now also preserve health, hunger, saturation, and XP/levels in addition to inventory, game mode, and location.

## Unreleased - Minigames network, part 1 of 2
* New package `com.hanzala.minigames`: `/mg` command + GUI, arena manager, shared game lifecycle (`GameSession`), player save/restore, reset journal, per-player sidebar with "Owner: HANZALA", admin force commands, TNT Run.
* BedWars: added `lobbyCoords()` getter; sidebar is not shown to players who are in a minigame.

## 1.2.0 - Minecraft 26.1.2 migration baseline
- Updated Gradle/Fabric Loom configuration to the non-remapping Loom plugin used by Minecraft 26.1+.
- Updated target to Minecraft 26.1.2, Java 25, Fabric Loader 0.19.3+, and Fabric API 0.155.3+26.1.2.
- Updated Fabric metadata and GitHub Actions build toolchain.
- IMPORTANT: source-level Minecraft/Fabric API migration is not yet compiler-verified. Run the CI build and resolve remaining API errors before treating this as a playable 26.1.2 mod.

## 1.3.0 (unreleased, NOT yet compiled or tested in-game)
- `/mg setup` wizard (lobby, per-game arena page, extra arenas), enable/disable/validate/tp/clear/reset commands.
- Arena dimension support, validator with fix hints, schema-2 arenas.json with migration, atomic saves and backups.
- Isolation: per-dimension sessions, scoped lava-flow guard, outsider block protection, loose-entity cleanup, lobby in any dimension.
