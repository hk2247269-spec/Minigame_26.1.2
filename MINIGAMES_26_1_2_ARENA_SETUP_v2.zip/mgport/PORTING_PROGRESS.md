# MINIGAMES 26.1.2 port status

Target: Minecraft Java 26.1.2, Fabric, Java 25.

## Migration work represented in this source tree
- Updated build configuration for Minecraft 26.1.2, Fabric Loader 0.19.3, Fabric API 0.155.3+26.1.2, Loom 1.16.1, and Java 25.
- Updated the GitHub Actions build workflow to Java 25 and Gradle 9.4.1.
- Migrated several source-level API names and method call patterns in an earlier pass.
- Added the workflow at `.github/workflows/build.yml` so repository pushes/manual runs can build the project.

## Outstanding validation
This archive is a migration working copy, not a verified finished port. Compile-time and runtime compatibility for every class and gameplay path has not been confirmed. This environment has Java 21 and no Gradle installation; it cannot run the target Java 25 Gradle build. The CI build and a 26.1.2 test server are necessary to identify and resolve any remaining API issues. Do not describe it as fully compatible until those checks pass.

## 1.2.1 compile-fix pass
- build.gradle: `modImplementation` -> `implementation` (26.1+ is unobfuscated; the no-remap Loom plugin has no `modImplementation`, which broke the build at configuration time).
- `ResourceKey#location()` -> `identifier()` (ProtectionManager, Visuals, Fx).
- `Villager` import moved to `net.minecraft.world.entity.npc.villager.Villager` (Hub, ShopNpc, RedGreenSession).
- `CommandSourceStack#hasPermission(int)` replaced by the permission-set API (`permissions().hasPermission(Permissions.COMMANDS_GAMEMASTER)`).
- `ServerPlayer#serverLevel()` -> `level()` (26 call sites).
- BedWars match game rules renamed to `block_drops` / `immediate_respawn`.
- Mixin `compatibilityLevel` set to JAVA_21; CI pins Gradle 9.4.1.
- STILL UNVERIFIED: no compile was possible in the edit environment. Run the CI build and fix any remaining red lines.

## 1.2.2
- `GameProfile#getName()` -> `name()` (authlib record), `Entity#getTags()` -> `entityTags()`.

## 1.2.3
- ClickType -> ContainerInput, playNotifySound -> ClientboundSoundPacket, getSharedSpawnPos -> getRespawnData().pos()
