# MINIGAMES network (Fabric, Minecraft 26.1.2, Java 25)

Owner: HANZALA

This project combines BedWars, Hide & Seek, TNT Run, Floor Is Lava, and Red Light Green Light under the `/mg` menu and admin force-command system.

## Target platform
- Minecraft Java Edition 26.1.2
- Fabric Loader 0.19.3+
- Fabric API 0.155.3+26.1.2
- Java 25

See `BUILDING.md` for the toolchain and build instructions.

**Porting note:** This is a 26.1.2 migration baseline. The source code originated on 1.21.8 and must pass the 26.1.2 compiler/build before it can be considered a working 26.1.2 mod. Minecraft 26.1 changes mappings, Fabric Loom, APIs, and other internals; changing version numbers alone is not sufficient.

## Quick start
1. Build (see `BUILDING.md`) and put the jar and Fabric API in `mods/`.
2. As an operator run `/mg setup`: set the shared lobby, then set up each game and press **Check arena** and **Enable**.
3. Players use `/mg` to join. Full guide: `docs/ARENA_SETUP.md`. Per-game test steps: `docs/MINIGAMES_README.md`.

## Config examples
`config-example/` holds sample files. `config-example/minigames/README.txt` explains which one is the old (v1) format kept as a migration fixture and which is the current schema 2 format.

## Status
Arena setup wizard, validation, per-arena isolation/reset, dimension-aware arenas and data migration are written (v1.3.0) but have not been compiled against 26.1.2 or played in-game. Treat the first server run as a test run.
