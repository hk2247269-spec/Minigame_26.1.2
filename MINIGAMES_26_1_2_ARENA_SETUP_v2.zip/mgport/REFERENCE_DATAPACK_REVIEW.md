# BedWars v17 datapack reference review

> Note: the "Known gaps" below describe version 0.9. Version 0.10 added the countdown, scoreboard, instant TNT, victory fireworks, particles and no-build zones from this datapack (see CHANGELOG.md).

The uploaded archive identifies itself in `README.txt` as **Bed Wars v16 – Minecraft 26.1.2** (the uploaded ZIP is named `bedwars_v17.zip`). I treated it as a reference only; its datapack functions are not runtime dependencies of this Fabric mod.

## Map and match flow described by the reference
- A lobby island and six team islands.
- The reference datapack uses Red, Blue, Green, Yellow, Pink and Orange. The Fabric mod retains the six colours already agreed in this project: Red, Blue, Green, Yellow, Pink and White.
- Four diamond islands and a central emerald generator.
- Lobby mode uses Adventure mode, no damage and no hunger; matches use Survival.
- Bed destruction controls whether players can respawn; death after bed loss means elimination.
- A victory check ends the match when only one team remains.
- The datapack describes map restoration/protection, shop restocking, TNT handling, rescue/respawn and generator caps.

## Shop catalogue transcribed from `shop/stock.mcfunction` and `shop/buy/*.mcfunction`

| Category | Item | Reference price |
|---|---|---:|
| Blocks | Team-colour wool x16 | 4 Iron |
| Blocks | Oak planks x16 | 8 Gold |
| Blocks | Terracotta x16 | 16 Gold |
| Blocks | End stone x12 | 20 Gold |
| Blocks | Glass x4 | 12 Gold |
| Blocks | Obsidian x4 | 6 Emerald |
| Blocks | Ladder x8 | 4 Gold |
| Blocks | Cobweb x2 | 6 Gold |
| Weapons | Stone sword | 5 Gold |
| Weapons | Iron sword | 12 Gold |
| Weapons | Diamond sword | 6 Emerald |
| Weapons | Knockback stick | 8 Gold |
| Weapons | Bow | 16 Gold |
| Weapons | Power I bow | 36 Gold |
| Weapons | Arrows x8 | 4 Gold |
| Tools | Shears | 20 Gold |
| Tools | Iron pickaxe (Efficiency I) | 8 Gold |
| Tools | Iron axe (Efficiency I) | 8 Gold |
| Tools | Diamond pickaxe (Efficiency II) | 4 Emerald |
| Tools | Diamond axe (Efficiency II) | 4 Emerald |
| Utility | Golden apple | 8 Gold |
| Utility | Ender pearl | 6 Emerald |
| Utility | Water bucket | 6 Gold |
| Utility | Speed II potion (45s) | 2 Emerald |
| Utility | Jump V potion (45s) | 2 Emerald |
| Utility | TNT x4 | 4 Diamond |
| Armour | Chain leggings + boots | 16 Gold |
| Armour | Iron leggings + boots | 28 Gold |
| Armour | Diamond leggings + boots | 8 Emerald |
| Team upgrade | Generator Tier II | 4 Diamond |
| Team upgrade | Generator Tier III | 5 Emerald + 5 Diamond |

## Generator timing described in the reference README
- Tier I: Iron every 6 seconds; no Gold.
- Tier II: Iron every 5 seconds; Gold every 8 seconds.
- Tier III: Iron every 4 seconds; Gold every 6 seconds; Diamond every 18 seconds.
- Diamond islands: Diamond every 30 seconds.
- Centre: Emerald every 60 seconds.
- Nearby dropped-item caps: Iron 48, Gold 24, Diamond 8, Emerald 4.
- The reference datapack README says Gold exists from Tier I, but this Fabric mod intentionally overrides that one rule to follow the user's explicit requirement: no Gold at Tier I.

## Implemented (see README.md and CHANGELOG.md for the current state)
- `/bw shop` displays the reference-derived catalogue categories.
- `/bw shop buy <item>` purchases the implemented basic item/block/tool/utility entries with server-side currency checks.
- `/bw shop armor <chain|iron|diamond>` purchases progressive leggings + boots upgrades using the reference prices.
- `/bw generator add <iron|gold|diamond|emerald> <team|neutral>` registers an Overworld generator at the admin's position.
- `/bw generator upgrade` purchases a team's next generator tier using the reference costs.
- `/bw generator list` and `/bw generator remove` provide admin generator management.
- Generator locations and team tiers are saved in `config/bedwars/`.

## Known gaps (not claimed as implemented)
- This update is source-only and has not been compiled or launched in this environment.
- The reference's clickable chest shop is represented by server commands here, not a native inventory GUI yet.
- Reference item enchantments and custom potion effects are not all reproduced in the command shop yet; the current shop offers the corresponding base items for those entries.
- Generator setup is manual through admin commands; the reference world/map is not automatically imported into a new server.
- The full map-protection/repair, custom TNT fuse/placement behavior, rescue system, lobby panel, scoreboard and complete win/reset flow still require integration and in-game verification.


## User-specific Gold progression correction (source update)
The supplied datapack README says Gold exists from Tier I, but the user explicitly clarified that their intended mod rules are different: **Tier I must not generate Gold**. The Fabric source therefore follows the user's requested rule rather than that one datapack README statement. A team Iron base registration also registers the Gold stream at the same location, but the Gold stream remains inactive until the team reaches Tier II. Gold then generates every 8 seconds at Tier II and every 6 seconds at Tier III.
