# Source feature inventory (static review)

This is an inventory of source files/configuration included in this archive, not a gameplay test report.

## Game modes and integration
- BedWars: `com/hanzala/bedwars/` (game manager, generators, shops, team menus, setup/admin menus, protection/build rules, stats, visuals, backup, mixins)
- Hide & Seek: `net/hanzala/hideseek/` (game, config, commands, disguise, GUI, HUD, hub, stats, backup, utilities)
- Shared minigames system: `com/hanzala/minigames/` (arena, arena manager, sessions, lobby, commands, menus, settings, scoreboard, player state store, block journal, adapters)
- Additional sessions present: TNT Run, Floor Is Lava, Red Light Green Light.

## Included files
- Java sources under `src/main/java/`
- Fabric metadata and BedWars mixin config under `src/main/resources/`
- Example configuration files under `config-example/`
- Documentation under `docs/`, README, changelog, licenses and port notes

## Not confirmed by this static review
- Compilation against Minecraft 26.1.2 / Java 25
- Runtime registration, game start/end paths, GUI click handling and persistence
- All commands and configuration edge cases
- Mixins and server-side behavior in an actual test server
- No feature is claimed to be runtime-verified; compile and gameplay testing are still required.
