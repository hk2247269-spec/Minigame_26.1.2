Example files for config/minigames/

settings.json
  Copy as-is. Timing and reset speed for all arena minigames.

arenas.json
  OLD format (schema 1, no "schemaVersion"). Kept on purpose: tools/selftest uses it to prove that
  old files migrate without losing data. If you copy it to config/minigames/ the mod migrates it
  automatically and keeps the original as arenas.json.v1.bak.

arenas.schema2.example.json
  Current format (schema 2): default ids tnt / lava / rg, a "dimension" per arena, and "enabled".
  All arenas are enabled=false here. The coordinates are placeholders; do not copy this file to a
  real world. Use /mg setup instead, then press Check arena and Enable.
