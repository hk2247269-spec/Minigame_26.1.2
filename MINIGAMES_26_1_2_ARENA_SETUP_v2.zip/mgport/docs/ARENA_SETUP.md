# Arena setup guide (v1.3.0)

## Install
Put the mod jar (and Fabric API) in `mods/`, start the server/world. No dimensions, JSON editing or world downloads needed.

## Quick start (operators only)
1. Run `/mg setup` (or `/mg` -> "Admin setup").
2. **Lobby:** stand where players should return and click the beacon. One lobby is shared by all games (it can be in any dimension).
3. **Each game:** click it, stand at each point and click the buttons: Corner 1, Corner 2 (opposite corner, different height), Add spawn, optional Waiting spot / Spectator spot, Finish line (Red Light Green Light only), and the game numbers.
4. Press **Check arena** - every problem is listed with how to fix it. Then press **Enable**. Only enabled, error-free arenas can be joined.
5. Test: `/mg` -> click the game (use `/mg <tnt|lava|rg> force` to start with everyone online).
BedWars: use the BedWars button (its own setup panel). Hide & Seek: `/hs setup`.

One arena per game is the default (ids `tnt`, `lava`, `rg`). Right-click a game in `/mg setup` to add optional extra arenas.

## Commands
`/mg arena create <game> [id]`, `list`, `info|validate|enable|disable|clear|tp|reset|remove <id>`, `pos1|pos2|spawn add|spawn clear|waiting|spectator|finish <id>`, `name|min|max|set <id> ...`

## Dimensions
Every arena stores its dimension id next to its coordinates; teleports, boundaries, resets and game logic use that dimension's level. Locations of one arena must all be in the same dimension (use *Clear all locations* to move an arena). Overlap/lobby checks only apply inside the same dimension.
Dynamic dimension creation is NOT implemented: it is not reliably supported by Fabric API, so arenas are isolated by boundary box (and optionally by an already-existing dimension, e.g. from a datapack). BedWars and Hide & Seek still run in the Overworld.

## Isolation and reset
One session per arena; players belong to one session. Only blocks inside the arena box are journaled and restored (journal in `config/minigames/journals/`, also recovered after a crash). Dropped items/XP in the box are cleared after a reset. Outsiders (non-ops) cannot break/place/interact inside an arena that is in use. Floor Is Lava only blocks lava flow near running lava arenas.

## Data storage and migration
`config/minigames/arenas.json` (schema 2). Old files are migrated automatically: nothing is dropped, arenas get dimension `minecraft:overworld` and stay enabled; the old file is kept as `arenas.json.v1.bak`. Saves are atomic and keep `arenas.json.bak`. A broken file is copied to `arenas.json.corrupt-<time>` and never silently overwritten.

## Troubleshooting
- "not set up yet - ...": run **Check arena**.
- "disabled": press Enable.
- "dimension not loaded": the dimension doesn't exist on this server; Clear locations and re-set up.
- Interrupted match left holes: `/mg arena reset <id>`.
- Remove an arena: Delete in the wizard or `/mg arena remove <id>` (no world blocks are touched).
