> **Update 1.1.0:** BedWars is joined through `/mg` (auto team, match starts when two teams have players). Teams are cleared when a match ends; the team menu opens with `/bw menu` only. Other minigames' players never receive BedWars messages or rules.

# BedWars Fabric Mod — v0.13.0-beta

Minecraft **26.1.2**, **Java 25**, Fabric Loader 0.19.3+ and Fabric API. Source code — see `BUILDING.md` to build the `.jar`.

> **Honest status:** this source was written and reviewed without access to Minecraft or Gradle, so it has **not been compiled or play-tested**. Version 0.10 was checked for syntax and for consistency between its own classes (no unresolved calls between them), but not against the real Minecraft classes. Build it (BUILDING.md); if the compiler reports anything, send me the lines and I will fix them. Every new gameplay feature has an on/off switch in `settings.txt`, so a feature that misbehaves in game can be turned off without rebuilding.

## Quick setup (operator)
1. `/bw lobby set` where players wait.
2. For every team you use: stand at its spawn and `/bw spawn set <team>`; look at its bed and `/bw bed set <team>`; stand on its generator spot and `/bw generator add iron <team>` (registers Iron, Gold and Diamond streams).
3. Neutral islands: `/bw generator add diamond neutral`, `/bw generator add emerald neutral`.
4. Protect the map: `/bw region add arena <corner1> <corner2>`.
5. Place shops: `/bw npc add` (villager) — or players use `/bw shop`.
6. `/bw setup` shows a checklist. Players pick teams in the GUI (`/bw menu`); `/bw start` begins (it lists anything missing).

**Admin GUI:** `/bw admin` opens a chest GUI for everything above (start/stop, move players between teams, set lobby/spawns/beds/generators at your position, edit settings). Stand where you want the spawn or generator, open the GUI, and click.

## What's new in 0.13 (admin control of the shop and generators)
`/bw admin` (operators only, re-checked on every click) now has two more screens:
- **Shop & Prices**: every shop item, armour tier and generator upgrade. Click one to change its **price**, **currency** (Iron / Gold / Diamond / Emerald), **amount per purchase** (stackable items), switch it **off** (shows as a red barrier and cannot be bought, also by command), or reset it. Buttons also scale **all prices by +/-10%** or reset the whole shop (shift-click to confirm). Saved in `config/bedwars/shop.txt`; `/bw reload` re-reads it.
- **Generators**: seconds per item for team Iron (Tier I/II/III), Gold (II/III) and Diamond (III), for the neutral Diamond and Emerald islands (start / after 05:00 / after 10:00), the **item limit** per generator, and a one-click **tier switch for each team**. The numbers are the `gen_*` keys in `settings.txt`.
Changes apply immediately. A shop screen that a player already has open updates the next time they click or reopen it.

## What's new in 0.12 (visuals and match timeline; every effect has a switch in `settings.txt` and in `/bw admin` -> Settings)
- **Animated scoreboard**: a shine sweeps across the "BED WARS" header; the board shows elapsed time, remaining time (22:00 -> 00:00, colour changes as time runs out, flashes in the last 10 s), the next timeline event, and for every team its bed, players alive, kills and generator tier, plus the current emerald/diamond speeds. It is updated once per whole match second, so every player sees the same clock.
- **Action bar**: your team, bed, generator tier and your own Iron/Gold/Diamond/Emerald counts, refreshed twice a second. Kills, kill loot and bed events briefly take over the bar.
- **Titles**: countdown 5-4-3-2-1-GO!, bed destroyed, final kill/elimination, team eliminated, timeline events, victory (shimmering title) and defeat, all with fade in/out.
- **Sounds** for countdown (rising pitch), GO, bed destruction, kills, final kills, eliminations, timeline events, the last 10 seconds, victory and defeat.
- **Team-coloured particles** for bed destruction, elimination and victory (strength: `particle_density`).
- **Victory celebration**: banner, winners' titles and sounds, a particle spiral around the winners and the existing fireworks.
- **GUIs**: the shop shows category, price in the currency colour, how many you own, a description and whether you can afford it, plus full generator-upgrade information and the match clock.

## Match timeline (22:00 by default)
| Time | Event |
|---|---|
| 00:00 | Match starts (after the countdown). |
| 05:00 | **Generator Upgrade I**: neutral emeralds 60 s -> 40 s. |
| 10:00 | **Generator Upgrade II**: neutral emeralds 40 s -> 30 s, neutral diamonds 30 s -> 20 s. |
| 15:00 | Warning (7:00 left). |
| 18:00 | Final countdown (4:00 left). |
| 20:00 | Final two minutes. |
| 21:50 | Last-10-seconds countdown with a tick sound each second. |
| 22:00 | Time is up: `match_end_action` (`sudden_death` = every bed is destroyed and the match ends as a draw after `sudden_death_minutes` if nobody has won; `draw`; `most_alive` = team with most beds, then players, wins). |

The match length (`match_duration_seconds`) and the end action are fixed when a match starts. The timer only advances while a match is running, is reset only by a new match start, and every event is recorded when it fires, so none can repeat. Milestones that fall at or after the match length are skipped.

## What's new in 0.10 (all switchable in `config/bedwars/settings.txt`, reload with `/bw reload`)
- **Start countdown** (10 s, titles + sounds, cancelled automatically if fewer than 2 teams remain; `/bw stop` cancels it).
- **Sidebar scoreboard**: lobby panel (team player counts, countdown) and a live match board (next event timer, every team's bed/players).
- **Team colours**: coloured nametags, tab list and chat names via scoreboard teams `bwm_<team>`. **Team chat**: `/bw tc <message>`.
- **Leather kit**: team-coloured leather armour at every spawn (bought leggings/boots replace the leather ones).
- **Kill rewards**: a kill hands the victim's Iron/Gold/Diamond/Emerald to the killer; a knock into the void within 10 s still counts for the last attacker. Only resources drop on death; other gear is removed and the kit is re-issued.
- **Match timeline**: a 22-minute match with fixed milestones (see "Match timeline" below).
- **Instant TNT** with a 2 s fuse (credit goes to the player who placed it).
- **No-build zones**: no building outside the protected arena, or within 1 block of generators and team spawns.
- **Stats**: `/bw stats [player]`, `/bw top`, plus a match summary (top killers, most beds) after every game. Stored in `config/bedwars/stats.txt`.
- **Effects**: victory fireworks in the winners' colour, particles on generators and standing beds, hunger refill during matches.
- **Match game rules**: block drops and the death screen are switched off during a match (`doTileDrops=false`, `doImmediateRespawn=true`) and returned to the vanilla defaults afterwards.
- **Crash recovery**: if the server stops mid-match, the arena is reset on the next start.

## Rules
- Six manual teams: red, blue, green, yellow, pink, white. Minimum 2 teams with online players. No auto-balance; unequal sizes allowed.
- Break an enemy bed to stop their respawns. You cannot break your own. Death without a bed = elimination (spectator). Respawn takes 5 seconds.
- Last team standing wins; the match then resets itself. If nobody has won after 22:00, sudden death starts (configurable, see below).
- **Gold is disabled at Tier I.** Tier II (4 Diamond) unlocks Gold (8s) and speeds Iron to 5s. Tier III (5 Emerald + 5 Diamond): Iron 4s, Gold 6s, team Diamond 18s. Neutral generators start with the match and need no team: Diamond 1 per 30 s (20 s after Upgrade II); Emerald 1 per 60 s (40 s after Upgrade I, 30 s after Upgrade II). All numbers are in `settings.txt`. A team's base generator only runs while that team is playing. Item caps: Iron 48, Gold 24, Diamond 8, Emerald 4.
- Map protection is active during matches: original blocks in protected regions can't be broken or exploded; blocks players place can, and all are removed at match end. Operators in creative can edit the map between matches.

## Commands
Player: `/bw menu` (team GUI), `/bw teams`, `/bw tc <msg>`, `/bw stats [player]`, `/bw top`, `/bw status`, `/bw shop`, `/bw shop list`, `/bw shop buy <item>`, `/bw shop armor <chain|iron|diamond>`, `/bw generator upgrade`, `/bw lobby`, `/bw team join|leave`.
Operator: `/bw start`, `/bw stop` (also cancels the countdown), `/bw reload`, `/bw admin` (admin GUI), `/bw setup`, `/bw setup clear` (then `/bw setup clear confirm`: removes the lobby, spawns, beds, generators, regions and shop villagers), `/bw team set <player> <team>`, `/bw lobby set`, `/bw spawn set <team>`, `/bw bed set <team>`, `/bw generator add|list|remove`, `/bw region add|remove|list`, `/bw npc add|remove`.

## Shop (prices from the reference datapack)
Wool x16 4 Iron (team colour) · Planks x16 8 Gold · Terracotta x16 16 Gold (team colour) · End stone x12 20 Gold · Glass x4 12 Gold (team colour) · Obsidian x4 6 Emerald · Ladder x8 4 Gold · Cobweb x2 6 Gold · Stone sword 5 Gold · Iron sword 12 Gold · Diamond sword 6 Emerald · Knockback stick 8 Gold · Bow 16 Gold · Power I bow 36 Gold · Arrows x8 4 Gold · Shears 20 Gold · Iron pickaxe/axe (Eff I) 8 Gold · Diamond pickaxe/axe (Eff II) 4 Emerald · Golden apple 8 Gold · Ender pearl 6 Emerald · Water bucket 6 Gold · TNT x4 4 Diamond · Speed II / Jump V potion (45s) 2 Emerald · Armour: chain 16 Gold, iron 28 Gold, diamond 8 Emerald (kept after death).

## Known limits
- Teleports are same-dimension only (the whole arena should be in the Overworld).
- Generators are Overworld-only.
- Rescue platforms and automatic map import are not implemented. The sidebar is shared by all players (it cannot show personal numbers; those are on the action bar).
- The sidebar uses the server's main scoreboard sidebar slot (`bwm_side`); turn it off with `scoreboard=false` if another plugin needs that slot.
- `match_gamerules` sets two game rules during a match and returns them to the vanilla defaults afterwards; turn it off if your server uses non-default values.
- Bed restore needs beds registered with this version (older `team-beds.txt` lines lack the bed type: just re-run `/bw bed set <team>`).
- With `clean_death_drops=false` and `kill_resource_transfer=false`, items dropped on death follow vanilla rules.
