> **Update 1.1.0:** Hide & Seek now runs in the **Overworld**, not the End. Build the arena in the Overworld and set it up there (`/hs setup ...`); old End arenas must be redone. Join through `/mg` (or `/hs join`); `/hs` opens the Hide & Seek menu. After a match players return to the common lobby. Where this guide says "End", read "Overworld".

# End Hide & Seek  (Fabric, Minecraft Java 1.21.9)

Copyright © 2026 HANZALA — see LICENSE.txt

A Hide & Seek minigame that runs **only in the End dimension**.
It is a server-side mod: **players do not need to install anything**. Only the server needs Fabric + Fabric API + this jar.

## Build the jar (first time, from absolute zero)
1. Install **JDK 25** (JDK 21 also works). Check with `java -version`.
2. Install **Gradle 9.x** (https://gradle.org/install/).
3. Open a terminal in this folder and run:
   ```
   gradle wrapper --gradle-version 9.1.0
   ./gradlew build          (Windows: gradlew.bat build)
   ```
4. Your jar is `build/libs/end-hide-and-seek-1.0.0.jar` (ignore the `-sources` jar).
   If Gradle says a version cannot be found, open `gradle.properties` and change `fabric_version`
   to the newest 1.21.9 build listed at https://modrinth.com/mod/fabric-api/versions

## Install on the server
1. Server running Minecraft 1.21.9 with Fabric Loader 0.17+.
2. Put `fabric-api-*.jar` and `end-hide-and-seek-1.0.0.jar` in `mods/`.
3. Start the server once. Config files appear in `config/hideseek/`.

## Set up your arena (in the End, as an operator)
Upload your custom End world as the server's End dimension (`world/DIM1`).
Go into the End, then:
```
/hs setup create arena1
/hs setup lobby          (stand in the waiting room)
/hs setup hiderspawn     (stand where hiders start)
/hs setup seekerspawn    (stand where seekers start)
/hs setup spectator      (optional)
/hs setup pos1 / pos2    (optional: two opposite corners of the play area)
```
Other setup commands: `list`, `info`, `select <name>`, `delete <name>`, `clearbounds`.

## Playing
| Command | What it does |
|---|---|
| `/hs` | Outside the End: teleports you to the End. Inside the End: main menu |
| `/bw` | Outside the Overworld: teleports you to the Overworld |
| `/hs npc add end` / `overworld` / `remove` (op) | Place or remove a travel NPC |
| `/hs join` / `/hs leave` | Join / leave |
| `/hs stats`, `/hs leaderboard`, `/hs results` | Menus |
| `/hs start` (op) | Force-start (needs `forceStartMinPlayers`) |
| `/hs stop` (op) | Cancel the match, no rewards |
| `/hs reload` (op) | Reload all config files |

Flow: 4+ players join → 15 s countdown → seekers picked at random → 30 s hiding (seekers frozen and blind)
→ 5 min seeking → results. Hiders win if time runs out; seekers win when every hider is found.
Hit a hider once to eliminate them. Abilities are right-click items (hold the item, then click).

## Config files (`config/hideseek/`)
`game.json` (players, timers, disguise block list), `abilities.json`, `rewards.json`, `arenas.json`,
`stats.json` (auto-written). Inventory backups go to `backups/` and are deleted after use.

## Dimension safety
Every command, menu, scoreboard, title, effect and event handler checks that the player is a participant
(participants are always in the End). Players who leave the End are removed from the game. Nothing is ever
sent to or changed for players in the Overworld or Nether.

## Known limits
* Hiders must hold the ability item to use it, so the held item is briefly visible.
* Disguises are vanilla block_display entities: block entities (chests, beds, signs) cannot be disguises.
* Decoy blocks are real blocks and are removed when the match ends.
