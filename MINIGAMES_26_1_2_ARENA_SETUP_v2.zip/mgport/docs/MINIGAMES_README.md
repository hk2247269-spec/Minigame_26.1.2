# MINIGAMES

Target: Minecraft Java Edition 26.1.2, Fabric, Java 25.

Games: BedWars, Hide & Seek, TNT Run, Floor Is Lava, and Red Light Green Light.

The `/mg` command opens the shared minigames interface. Admin force commands select a game for players, while the network uses one common lobby.

Build and compatibility status: see the root `BUILDING.md`. This is a source migration baseline and is not certified until the 26.1.2 GitHub Actions build passes and gameplay is tested on a 26.1.2 Fabric server.

## Test checklist (run once per game on a test world)
Set the lobby and the game's arena with `/mg setup`, press **Check arena** (no errors) and **Enable**. Use two accounts or `/mg <game> force`.

**TNT Run** (`/mg tnt force`)
1. Everyone is teleported to the spawns after the countdown.
2. Blocks under a running player disappear after the configured delay; players who fall are eliminated and become spectators.
3. Last player wins; everyone returns to the lobby; the floor is fully restored; inventories are back.

**Floor Is Lava** (`/mg lava force`)
1. Lava rises one layer per `riseSeconds` after the warm-up and stays inside the arena box.
2. Players who burn or die are eliminated; last one wins.
3. After the match all lava is gone and the original blocks are back (`/mg arena reset lava` if anything is left).

**Red Light Green Light** (`/mg rg force`)
1. Green: you can move. Red: moving after the grace time eliminates you.
2. Reaching the finish line qualifies you; the match ends when everyone is qualified or out, or at the time limit.

**Every arena game**
- `/mg leave` mid-match returns you to the lobby with your own inventory, health and XP.
- Start two different games at the same time in different arenas: they must not affect each other.
- Break or place a block inside a running arena as a non-op: it must be refused.
- Drop an item inside the arena during a match: it is gone after the reset.
- Stop the server during a match, start it again: blocks and your inventory are restored.
- Restart with an old `arenas.json`: arenas are kept, `arenas.json.v1.bak` appears.

**BedWars** and **Hide & Seek** keep their own setup (`/bw` panel from `/mg setup`, and `/hs setup`). Check that joining from `/mg` works and that you end up in the common lobby afterwards.
