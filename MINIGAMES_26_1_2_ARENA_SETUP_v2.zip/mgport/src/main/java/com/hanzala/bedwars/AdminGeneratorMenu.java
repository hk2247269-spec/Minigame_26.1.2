package com.hanzala.bedwars;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/**
 * Admin GUI for generators: seconds per item for team and neutral generators, how many items may pile up at a
 * generator, and a direct tier switch for every team. Left click +1, right click -1, shift = 5 at a time.
 */
public final class AdminGeneratorMenu extends ServerGui {
    private static final String[] NUMBER_KEYS = {
            "gen_iron_t1", "gen_iron_t2", "gen_iron_t3", "gen_gold_t2", "gen_gold_t3", "gen_diamond_t3",
            "neutral_diamond_seconds", "diamond_fast_seconds", "emerald_seconds", "emerald_fast_seconds", "emerald_final_seconds",
            "gen_cap_iron", "gen_cap_gold", "gen_cap_diamond", "gen_cap_emerald"};

    public static void open(ServerPlayer player) {
        if (!isAdmin(player)) { bar(player, "§cOperators only."); return; }
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new AdminGeneratorMenu(id, inv), Component.literal("Generators")));
    }

    private AdminGeneratorMenu(int containerId, Inventory inventory) {
        super(6, containerId, inventory);
        build();
    }

    /** A number tile: left click +1, right click -1, shift = 5. The value never goes below 1. */
    private void number(int slot, Item item, String name, String key, String description, String unit) {
        List<String> lore = new ArrayList<>(wrap(description, 38));
        lore.add(" ");
        lore.add("§7Now: §f" + Settings.integer(key) + unit + "   §8(default " + Settings.defaultInteger(key) + unit + ")");
        lore.add("§aLeft click: +1   §cRight click: -1");
        lore.add("§7Hold shift for 5 at a time.");
        putAdmin(slot, icon(item, "§e" + name + ": §f" + Settings.integer(key) + unit, lore), (p, button, shift) -> {
            int step = shift ? 5 : 1;
            Settings.setInteger(key, Math.max(1, Settings.integer(key) + (button == 0 ? step : -step)));
            refresh();
        });
    }

    @Override
    protected void build() {
        reset();

        // Row 1: set the tier of each team's generator right now
        for (int i = 0; i < BedWarsGameManager.TEAMS.size() && i < 6; i++) {
            String t = BedWarsGameManager.TEAMS.get(i);
            int tier = BedWarsGeneratorManager.tierOf(t);
            putAdmin(i, icon(teamWool(t), BedWarsGameManager.label(t) + " §7generator: §fTier " + tier,
                    "§7Tier I iron, II adds gold, III adds diamond.", "§eClick to switch to the next tier"),
                    (p, button, shift) -> {
                        BedWarsGeneratorManager.setTier(t, BedWarsGeneratorManager.tierOf(t) % 3 + 1);
                        refresh();
                    });
        }
        put(8, icon(Items.BEACON, "§b§lGenerators", BedWarsGeneratorManager.summaryLines()));

        // Row 2: team base speeds (seconds per item)
        number(9, Items.IRON_INGOT, "Team Iron, Tier I", "gen_iron_t1", "Seconds per Iron at a team base on Tier I.", "s");
        number(10, Items.IRON_INGOT, "Team Iron, Tier II", "gen_iron_t2", "Seconds per Iron at Tier II.", "s");
        number(11, Items.IRON_INGOT, "Team Iron, Tier III", "gen_iron_t3", "Seconds per Iron at Tier III.", "s");
        number(12, Items.GOLD_INGOT, "Team Gold, Tier II", "gen_gold_t2", "Seconds per Gold at Tier II (Gold starts at Tier II).", "s");
        number(13, Items.GOLD_INGOT, "Team Gold, Tier III", "gen_gold_t3", "Seconds per Gold at Tier III.", "s");
        number(14, Items.DIAMOND, "Team Diamond, Tier III", "gen_diamond_t3", "Seconds per Diamond at Tier III (Diamond starts at Tier III).", "s");

        // Row 3: neutral (island) generators
        number(18, Items.DIAMOND, "Neutral Diamond", "neutral_diamond_seconds", "Seconds per Diamond on the neutral islands at the start of the match.", "s");
        number(19, Items.DIAMOND, "Neutral Diamond, after 10:00", "diamond_fast_seconds", "Seconds per Diamond after Generator Upgrade II.", "s");
        number(20, Items.EMERALD, "Neutral Emerald", "emerald_seconds", "Seconds per Emerald at the start of the match.", "s");
        number(21, Items.EMERALD, "Neutral Emerald, after 05:00", "emerald_fast_seconds", "Seconds per Emerald after Generator Upgrade I.", "s");
        number(22, Items.EMERALD, "Neutral Emerald, after 10:00", "emerald_final_seconds", "Seconds per Emerald after Generator Upgrade II.", "s");

        // Row 4: item limits per generator
        number(27, Items.HOPPER, "Iron limit", "gen_cap_iron", "A generator pauses while this many Iron lie near it.", "");
        number(28, Items.HOPPER, "Gold limit", "gen_cap_gold", "A generator pauses while this many Gold lie near it.", "");
        number(29, Items.HOPPER, "Diamond limit", "gen_cap_diamond", "A generator pauses while this many Diamonds lie near it.", "");
        number(30, Items.HOPPER, "Emerald limit", "gen_cap_emerald", "A generator pauses while this many Emeralds lie near it.", "");

        putAdmin(45, icon(Items.TNT, "§c§lReset generator values", "§7Back to the default speeds and limits.", "§cShift + click to confirm"), (p, button, shift) -> {
            if (!shift) { bar(p, "§cHold shift and click to confirm the reset."); return; }
            for (String key : NUMBER_KEYS) Settings.reset(key);
            bar(p, "§aGenerator values reset.");
            refresh();
        });
        putAdmin(47, icon(Items.COMPASS, "§eAdd / remove generators", "§7Placing generators happens in Arena Setup.", "§eClick to open"),
                (p, button, shift) -> AdminSetupMenu.open(p));
        put(49, icon(Items.ARROW, "§7« Back"), (p, button, shift) -> AdminMenu.open(p));
    }
}
