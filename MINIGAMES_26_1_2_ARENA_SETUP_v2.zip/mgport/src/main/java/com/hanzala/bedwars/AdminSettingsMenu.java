package com.hanzala.bedwars;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/** Admin GUI for settings.txt: click a switch to toggle it, left/right click a number to raise/lower it. */
public final class AdminSettingsMenu extends ServerGui {
    private static final int MAX_ENTRIES = 45;

    public static void open(ServerPlayer player) {
        if (!isAdmin(player)) { bar(player, "§cOperators only."); return; }
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new AdminSettingsMenu(id, inv), Component.literal("BedWars Settings")));
    }

    private AdminSettingsMenu(int containerId, Inventory inventory) {
        super(6, containerId, inventory);
        build();
    }

    private static String pretty(String key) { return capitalised(key.replace('_', ' ')); }

    @Override
    protected void build() {
        reset();
        List<String> keys = Settings.keys();
        keys.removeIf(k -> k.startsWith("gen_")); // generator numbers have their own screen (Generators)
        for (int i = 0; i < keys.size() && i < MAX_ENTRIES; i++) {
            String key = keys.get(i);
            List<String> lore = new ArrayList<>(wrap(Settings.comment(key), 38));
            lore.add(" ");
            if (Settings.isChoiceKey(key)) {
                lore.add("§7Now: §f" + Settings.text(key));
                lore.add("§eClick to switch to the next option");
                putAdmin(i, icon(Items.COMPARATOR, "§e" + pretty(key) + ": §f" + Settings.text(key), lore),
                        (p, button, shift) -> { Settings.cycle(key); refresh(); });
            } else if (Settings.isFlagKey(key)) {
                boolean on = Settings.flag(key);
                lore.add("§eClick to turn " + (on ? "off" : "on"));
                putAdmin(i, icon(on ? Items.LIME_DYE : Items.GRAY_DYE, "§e" + pretty(key) + ": " + (on ? "§aON" : "§cOFF"), lore),
                        (p, button, shift) -> { Settings.setFlag(key, !Settings.flag(key)); refresh(); });
            } else {
                lore.add("§aLeft click: +1   §cRight click: -1");
                lore.add("§7Hold shift for 5 at a time.");
                putAdmin(i, icon(Items.REPEATER, "§e" + pretty(key) + ": §f" + Settings.integer(key), lore), (p, button, shift) -> {
                    int step = shift ? 5 : 1;
                    Settings.setInteger(key, Settings.integer(key) + (button == 0 ? step : -step));
                    refresh();
                });
            }
        }
        put(49, icon(Items.ARROW, "§7« Back"), (p, button, shift) -> AdminMenu.open(p));
    }
}
