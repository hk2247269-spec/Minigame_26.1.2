package com.hanzala.bedwars;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Items;

/**
 * Admin GUI for arena setup. Everything uses the position (and, for beds, the direction) the admin is in when
 * clicking: stand where you want the spawn / generator, then open this screen and click.
 */
public final class AdminSetupMenu extends ServerGui {
    private static final int[] TEAM_SLOTS = {1, 2, 3, 4, 5, 6};

    private String team = "red";

    public static void open(ServerPlayer player) {
        if (!isAdmin(player)) { bar(player, "§cOperators only."); return; }
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new AdminSetupMenu(id, inv), Component.literal("Arena Setup")));
    }

    private AdminSetupMenu(int containerId, Inventory inventory) {
        super(5, containerId, inventory);
        build();
    }

    private static String tick(boolean ok) { return ok ? "§a✔ set" : "§c✘ not set"; }

    @Override
    protected void build() {
        reset();
        BedWarsGameManager game = BedWarsMod.GAME;

        // Team selector (row 1)
        for (int i = 0; i < BedWarsGameManager.TEAMS.size() && i < TEAM_SLOTS.length; i++) {
            String t = BedWarsGameManager.TEAMS.get(i);
            var stack = icon(teamWool(t), BedWarsGameManager.label(t),
                    "§7spawn " + tick(game.hasSpawn(t)), "§7bed " + tick(game.hasBed(t)),
                    "§7generator " + tick(BedWarsGeneratorManager.hasTeamBase(t)),
                    t.equals(team) ? "§aSelected" : "§eClick to select");
            if (t.equals(team)) glow(stack);
            putAdmin(TEAM_SLOTS[i], stack, (p, button, shift) -> { team = t; refresh(); });
        }

        String label = BedWarsGameManager.label(team);

        // Selected team (row 2)
        putAdmin(19, icon(Items.ENDER_PEARL, "§eSet " + label + " §espawn", "§7Spawn and respawn point at your position.",
                "§7Now: " + tick(game.hasSpawn(team)), "§eClick to set"), (p, button, shift) -> {
            BedWarsMod.GAME.setSpawn(p, team);
            bar(p, "§aSet the " + team + " team spawn.");
            refresh();
        });
        putAdmin(21, icon(Items.RED_BED, "§eSet " + label + " §ebed", "§7Look at the bed (or stand on it), then click.",
                "§7Now: " + tick(game.hasBed(team)), "§eClick to set"), (p, button, shift) -> {
            if (BedWarsCommands.trySetBed(p, team)) bar(p, "§aRegistered the " + team + " team bed.");
            else bar(p, "§cLook at (or stand on) a bed block and click again.");
            refresh();
        });
        putAdmin(23, icon(Items.IRON_INGOT, "§eAdd " + label + " §egenerator", "§7Iron, Gold and Diamond generator", "§7at your position.",
                "§7Now: " + tick(BedWarsGeneratorManager.hasTeamBase(team)), "§eClick to add"), (p, button, shift) -> {
            if (BedWarsGeneratorManager.add((ServerLevel) p.level(), p.blockPosition(), "iron", team)) bar(p, "§aAdded the " + team + " generator.");
            else bar(p, "§cGenerators only work in the Overworld.");
            refresh();
        });

        // Whole arena (row 3)
        putAdmin(29, icon(Items.COMPASS, "§eSet lobby", "§7Lobby spawn at your position.", "§7Now: " + tick(game.hasLobby()), "§eClick to set"),
                (p, button, shift) -> {
                    BedWarsMod.GAME.setLobby(p);
                    bar(p, "§aLobby set.");
                    refresh();
                });
        putAdmin(31, icon(Items.DIAMOND, "§bAdd neutral diamond generator", "§7At your position.", "§7Current: " + BedWarsGeneratorManager.summaryLines().get(1), "§eClick to add"),
                (p, button, shift) -> addNeutral(p, "diamond"));
        putAdmin(33, icon(Items.EMERALD, "§aAdd neutral emerald generator", "§7At your position.", "§7Current: " + BedWarsGeneratorManager.summaryLines().get(2), "§eClick to add"),
                (p, button, shift) -> addNeutral(p, "emerald"));

        // Row 4
        put(36, icon(Items.ARROW, "§7« Back"), (p, button, shift) -> AdminMenu.open(p));
        putAdmin(40, icon(Items.TNT, "§cRemove generator here", "§7Removes every generator registered", "§7exactly at your block position."),
                (p, button, shift) -> {
                    if (BedWarsGeneratorManager.remove(p.blockPosition())) bar(p, "§aGenerator removed.");
                    else bar(p, "§cNo generator at your position.");
                    refresh();
                });
    }

    private void addNeutral(ServerPlayer p, String type) {
        if (BedWarsGeneratorManager.add((ServerLevel) p.level(), p.blockPosition(), type, "neutral")) bar(p, "§aAdded a neutral " + type + " generator.");
        else bar(p, "§cGenerators only work in the Overworld.");
        refresh();
    }
}
