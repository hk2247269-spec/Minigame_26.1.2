package com.hanzala.bedwars;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/** Admin GUI for one shop line: price, currency, amount, on/off and reset. */
public final class AdminShopItemMenu extends ServerGui {
    private final String key;

    public static void open(ServerPlayer player, String key) {
        if (!isAdmin(player)) { bar(player, "§cOperators only."); return; }
        ShopConfig.Entry entry = ShopConfig.entry(key);
        if (entry == null) return;
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new AdminShopItemMenu(id, inv, key), Component.literal("Edit: " + entry.name())));
    }

    private AdminShopItemMenu(int containerId, Inventory inventory, String key) {
        super(4, containerId, inventory);
        this.key = key;
        build();
    }

    private void priceButton(int slot, int delta) {
        boolean plus = delta > 0;
        putAdmin(slot, icon(plus ? Items.LIME_STAINED_GLASS_PANE : Items.RED_STAINED_GLASS_PANE,
                (plus ? "§a+" : "§c") + delta, "§7Price"), (p, button, shift) -> {
            ShopConfig.setPrice(key, ShopConfig.price(key) + delta);
            refresh();
        });
    }

    private void amountButton(int slot, int delta) {
        boolean plus = delta > 0;
        putAdmin(slot, icon(plus ? Items.LIME_STAINED_GLASS_PANE : Items.RED_STAINED_GLASS_PANE,
                (plus ? "§a+" : "§c") + delta, "§7Amount per purchase"), (p, button, shift) -> {
            ShopConfig.setAmount(key, ShopConfig.amount(key) + delta);
            refresh();
        });
    }

    @Override
    protected void build() {
        reset();
        ShopConfig.Entry e = ShopConfig.entry(key);
        String cur = ShopConfig.currencyId(key);
        boolean on = ShopConfig.enabled(key);

        List<String> head = new ArrayList<>();
        head.add("§7Price: " + ShopConfig.colour(cur) + ShopConfig.price(key) + " " + ShopConfig.label(cur));
        if (e.amountEditable()) head.add("§7You get: §fx" + ShopConfig.amount(key));
        head.add(on ? "§aOn sale" : "§cSwitched off");
        put(4, icon(e.icon(), e.amountEditable() ? ShopConfig.amount(key) : 1, "§e§l" + e.name(), head));

        // Price row
        priceButton(10, -5);
        priceButton(11, -1);
        put(12, icon(ShopConfig.item(cur), "§ePrice: " + ShopConfig.colour(cur) + ShopConfig.price(key),
                "§7Default: §f" + ShopConfig.defaultPrice(key), "§7Range 0 - " + ShopConfig.MAX_PRICE + " (0 = free)"));
        priceButton(13, 1);
        priceButton(14, 5);

        // Currency
        putAdmin(16, icon(ShopConfig.item(cur), "§eCurrency: " + ShopConfig.colour(cur) + ShopConfig.label(cur),
                "§7Default: §f" + ShopConfig.label(ShopConfig.defaultCurrencyId(key)), "§eClick for the next currency"),
                (p, button, shift) -> { ShopConfig.cycleCurrency(key); refresh(); });

        // Amount row
        if (e.amountEditable()) {
            amountButton(19, -4);
            amountButton(20, -1);
            put(21, icon(e.icon(), ShopConfig.amount(key), "§eAmount: §f" + ShopConfig.amount(key),
                    List.of("§7Default: §f" + ShopConfig.defaultAmount(key), "§7Range 1 - 64")));
            amountButton(22, 1);
            amountButton(23, 4);
        } else {
            put(21, icon(Items.GRAY_DYE, "§7Amount is fixed", "§7This entry always gives 1."));
        }

        // On / off (generator upgrade costs cannot be switched off: set the price to 0 instead)
        if (key.startsWith("upgrade.")) {
            put(28, icon(Items.GRAY_DYE, "§7Cannot be switched off", "§7Set the price to 0 to make it free."));
        } else {
            putAdmin(28, icon(on ? Items.LIME_DYE : Items.GRAY_DYE, "§eOn sale: " + (on ? "§aYES" : "§cNO"),
                    "§eClick to turn " + (on ? "off" : "on")),
                    (p, button, shift) -> { ShopConfig.setEnabled(key, !on); refresh(); });
        }

        putAdmin(30, icon(Items.REPEATER, "§7Reset this entry", "§7Back to the default price,", "§7currency and amount."),
                (p, button, shift) -> { ShopConfig.reset(key); refresh(); });
        put(34, icon(Items.ARROW, "§7« Back"), (p, button, shift) -> AdminShopMenu.open(p));
    }
}
