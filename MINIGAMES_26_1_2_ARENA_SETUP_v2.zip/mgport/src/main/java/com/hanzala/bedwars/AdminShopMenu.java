package com.hanzala.bedwars;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/** Admin GUI listing every shop item, armour tier and generator upgrade with its price. Click one to edit it. */
public final class AdminShopMenu extends ServerGui {
    private static final int MAX_ENTRIES = 45;

    public static void open(ServerPlayer player) {
        if (!isAdmin(player)) { bar(player, "§cOperators only."); return; }
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new AdminShopMenu(id, inv), Component.literal("Shop & Prices")));
    }

    private AdminShopMenu(int containerId, Inventory inventory) {
        super(6, containerId, inventory);
        build();
    }

    @Override
    protected void build() {
        reset();
        List<ShopConfig.Entry> entries = ShopConfig.entries();
        for (int i = 0; i < entries.size() && i < MAX_ENTRIES; i++) {
            ShopConfig.Entry e = entries.get(i);
            String key = e.key();
            boolean on = ShopConfig.enabled(key);
            String cur = ShopConfig.currencyId(key);
            List<String> lore = new ArrayList<>();
            lore.add("§7Price: " + ShopConfig.colour(cur) + ShopConfig.price(key) + " " + ShopConfig.label(cur)
                    + (ShopConfig.price(key) != ShopConfig.defaultPrice(key) || !cur.equals(ShopConfig.defaultCurrencyId(key)) ? " §8(default " + ShopConfig.defaultPrice(key) + " " + ShopConfig.label(ShopConfig.defaultCurrencyId(key)) + ")" : ""));
            if (e.amountEditable()) lore.add("§7You get: §fx" + ShopConfig.amount(key));
            lore.add(on ? "§aOn sale" : "§cSwitched off");
            lore.add(" ");
            lore.add("§eClick to edit");
            putAdmin(i, icon(e.icon(), e.amountEditable() ? ShopConfig.amount(key) : 1, (on ? "§e" : "§c") + e.name(), lore),
                    (p, button, shift) -> AdminShopItemMenu.open(p, key));
        }

        putAdmin(45, icon(Items.TNT, "§c§lReset everything", "§7Restores every price, currency, amount", "§7and on/off switch to the defaults.", "§cShift + click to confirm"),
                (p, button, shift) -> {
                    if (!shift) { bar(p, "§cHold shift and click to confirm the reset."); return; }
                    ShopConfig.resetAll();
                    bar(p, "§aShop reset to defaults.");
                    refresh();
                });
        putAdmin(47, icon(Items.EXPERIENCE_BOTTLE, "§6§lAll prices", "§7Changes every price at once.", "§aLeft click: +10%", "§cRight click: -10%"),
                (p, button, shift) -> {
                    ShopConfig.scaleAll(button == 0 ? 10 : -10);
                    refresh();
                });
        put(49, icon(Items.ARROW, "§7« Back"), (p, button, shift) -> AdminMenu.open(p));
    }
}
