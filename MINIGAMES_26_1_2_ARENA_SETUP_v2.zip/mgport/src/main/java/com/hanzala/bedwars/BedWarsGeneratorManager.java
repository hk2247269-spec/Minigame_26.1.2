package com.hanzala.bedwars;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Resource generators.
 *  - Team base: Iron (same speed and same upgrades for every team) plus Gold (Tier II) and team Diamond (Tier III).
 *    A team base only runs while its team is actually playing in the current match.
 *  - Neutral Diamond: one per neutral_diamond_seconds (default 30), one per diamond_fast_seconds (20) after
 *    Generator Upgrade II. Neutral Emerald: one per emerald_seconds (60), emerald_fast_seconds (40) after
 *    Generator Upgrade I and emerald_final_seconds (30) after Upgrade II. The upgrade events are fired by the
 *    match timeline in BedWarsGameManager (05:00 and 10:00); this class only reads the current level.
 *    Neutral generators start with the match; no team is needed.
 * Item caps stop piles from growing forever.
 */
public final class BedWarsGeneratorManager {
    private static final List<Generator> GENERATORS = new ArrayList<>();
    private static final Map<String, Integer> TEAM_TIERS = new HashMap<>();
    private static int secondTick;
    private BedWarsGeneratorManager() {}

    private static final class Generator {
        final BlockPos pos; final String type; final String team; int elapsed;
        Generator(BlockPos pos, String type, String team) { this.pos = pos; this.type = type; this.team = team; }
    }

    public static void registerEvents() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!BedWarsMod.GAME.isRunning()) return;
            if (++secondTick % 20 != 0) return;
            for (Generator gen : GENERATORS) tickGenerator(server, gen);
        });
    }

    // ------------------------------------------------------------------ persistence

    public static void load(MinecraftServer server) {
        Path folder = BedWarsMod.configDir();
        try {
            Path g = folder.resolve("generators.txt");
            Path t = folder.resolve("generator-tiers.txt");
            if (!Files.exists(g)) Files.writeString(g, "# x y z type team (overworld)\n");
            if (!Files.exists(t)) Files.writeString(t, "# team tier\n");
            GENERATORS.clear(); TEAM_TIERS.clear();
            for (String line : Files.readAllLines(g)) {
                String[] p = line.split("#", 2)[0].trim().split("\\s+");
                if (p.length != 5) continue;
                try {
                    GENERATORS.add(new Generator(new BlockPos(Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2])),
                            p[3].toLowerCase(Locale.ROOT), p[4].toLowerCase(Locale.ROOT)));
                } catch (RuntimeException ignored) { }
            }
            // Migration: every team Iron base also needs its Gold and Diamond streams.
            for (Generator iron : new ArrayList<>(GENERATORS)) {
                if (!iron.type.equals("iron") || iron.team.equals("neutral")) continue;
                for (String extra : List.of("gold", "diamond")) {
                    boolean has = GENERATORS.stream().anyMatch(x -> x.pos.equals(iron.pos) && x.type.equals(extra) && x.team.equals(iron.team));
                    if (!has) GENERATORS.add(new Generator(iron.pos, extra, iron.team));
                }
            }
            saveGenerators();
            for (String line : Files.readAllLines(t)) {
                String[] p = line.split("#", 2)[0].trim().split("\\s+");
                if (p.length != 2) continue;
                try { TEAM_TIERS.put(p[0], Math.max(1, Math.min(3, Integer.parseInt(p[1])))); } catch (RuntimeException ignored) { }
            }
        } catch (IOException ex) { BedWarsMod.LOGGER.error("Could not load BedWars generators", ex); }
    }

    private static void saveGenerators() {
        List<String> lines = new ArrayList<>(List.of("# x y z type team (overworld)"));
        for (Generator g : GENERATORS) lines.add(g.pos.getX() + " " + g.pos.getY() + " " + g.pos.getZ() + " " + g.type + " " + g.team);
        try { Files.write(BedWarsMod.configDir().resolve("generators.txt"), lines); }
        catch (IOException ex) { BedWarsMod.LOGGER.error("Could not save generators", ex); }
    }

    private static void saveTiers() {
        List<String> lines = new ArrayList<>(List.of("# team tier"));
        TEAM_TIERS.forEach((team, tier) -> lines.add(team + " " + tier));
        try { Files.write(BedWarsMod.configDir().resolve("generator-tiers.txt"), lines); }
        catch (IOException ex) { BedWarsMod.LOGGER.error("Could not save generator tiers", ex); }
    }

    // ------------------------------------------------------------------ admin

    public static boolean add(ServerLevel level, BlockPos pos, String type, String team) {
        if (!level.dimension().equals(Level.OVERWORLD)) return false;
        String t = type.toLowerCase(Locale.ROOT);
        if (!List.of("iron", "gold", "diamond", "emerald").contains(t)) return false;
        String tm = team.toLowerCase(Locale.ROOT);
        if (!tm.equals("neutral") && BedWarsGameManager.normalizeTeam(tm) == null) return false;
        BlockPos p = pos.immutable();
        if (t.equals("iron") && !tm.equals("neutral")) {
            GENERATORS.removeIf(g -> g.pos.equals(p) && g.team.equals(tm));
            GENERATORS.add(new Generator(p, "iron", tm));
            GENERATORS.add(new Generator(p, "gold", tm));
            GENERATORS.add(new Generator(p, "diamond", tm));
        } else {
            GENERATORS.removeIf(g -> g.pos.equals(p) && g.team.equals(tm) && g.type.equals(t));
            GENERATORS.add(new Generator(p, t, tm));
        }
        saveGenerators();
        return true;
    }

    /** Removes every registered generator (team bases and neutral) and resets all team tiers. Returns how many generators were removed. */
    public static int clearAll() {
        int count = GENERATORS.size();
        GENERATORS.clear();
        TEAM_TIERS.clear();
        saveGenerators();
        saveTiers();
        return count;
    }

    public static boolean remove(BlockPos pos) {
        boolean changed = GENERATORS.removeIf(g -> g.pos.equals(pos));
        if (changed) saveGenerators();
        return changed;
    }

    public static List<String> listLines() {
        List<String> out = new ArrayList<>();
        for (Generator g : GENERATORS) out.add(g.type + " (" + g.team + ") at " + g.pos.getX() + " " + g.pos.getY() + " " + g.pos.getZ());
        if (out.isEmpty()) out.add("No generators registered.");
        out.add("Team tiers: " + TEAM_TIERS);
        return out;
    }

    public static boolean hasTeamBase(String team) {
        return GENERATORS.stream().anyMatch(g -> g.team.equals(team) && g.type.equals("iron"));
    }

    public static long neutralCount() { return GENERATORS.stream().filter(g -> g.team.equals("neutral")).count(); }

    /** Short description of the registered generators and their current speeds (shown in the admin GUI). */
    public static List<String> summaryLines() {
        long bases = GENERATORS.stream().filter(g -> !g.team.equals("neutral") && g.type.equals("iron")).count();
        long diamonds = GENERATORS.stream().filter(g -> g.team.equals("neutral") && g.type.equals("diamond")).count();
        long emeralds = GENERATORS.stream().filter(g -> g.team.equals("neutral") && g.type.equals("emerald")).count();
        List<String> out = new ArrayList<>();
        out.add("§7Team bases: §f" + bases + " §7(Iron, Gold, Diamond)");
        out.add("§7Neutral diamond: §f" + diamonds + " §7- 1 per §f" + diamondSeconds() + "s");
        out.add("§7Neutral emerald: §f" + emeralds + " §7- 1 per §f" + emeraldSeconds() + "s");
        out.add("§8Upgrade I 05:00 and II 10:00 speed these up.");
        return out;
    }

    // ------------------------------------------------------------------ build zones / effects

    /** True when target is within r blocks (horizontally) of a generator and at most 2 blocks above it. */
    public static boolean isNearGenerator(ServerLevel level, BlockPos target, int r) {
        if (!level.dimension().equals(Level.OVERWORLD)) return false;
        for (Generator g : GENERATORS) {
            if (Math.abs(target.getX() - g.pos.getX()) <= r && Math.abs(target.getZ() - g.pos.getZ()) <= r
                    && target.getY() >= g.pos.getY() && target.getY() <= g.pos.getY() + 2) return true;
        }
        return false;
    }

    /** Small ambient particles: soul fire on diamond islands, green sparks on emerald, crits on team bases. */
    public static void ambientParticles(MinecraftServer server) {
        ServerLevel level = server.overworld();
        for (Generator g : GENERATORS) {
            if (!level.hasChunkAt(g.pos)) continue;
            double x = g.pos.getX() + 0.5, y = g.pos.getY() + 0.7, z = g.pos.getZ() + 0.5;
            boolean neutral = g.team.equals("neutral");
            if (neutral && g.type.equals("diamond")) {
                level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, x, y, z, 2, 0.2, 0.1, 0.2, 0.01);
            } else if (neutral && g.type.equals("emerald")) {
                level.sendParticles(ParticleTypes.HAPPY_VILLAGER, x, y, z, 2, 0.25, 0.25, 0.25, 0.0);
            } else if (!neutral && g.type.equals("iron")) { // one marker per team base (iron/gold/diamond share a spot)
                level.sendParticles(ParticleTypes.CRIT, x, y, z, 2, 0.2, 0.2, 0.2, 0.02);
            }
        }
    }

    // ------------------------------------------------------------------ tiers

    public static int tierOf(String team) { return TEAM_TIERS.getOrDefault(team, 1); }

    /** Admin control: set a team's generator tier (1-3) directly. */
    public static void setTier(String team, int tier) {
        TEAM_TIERS.put(team, Math.max(1, Math.min(3, tier)));
        saveTiers();
    }

    public static void resetTiers() { TEAM_TIERS.clear(); saveTiers(); }

    public static void resetForMatch(MinecraftServer server) {
        resetTiers();
        for (Generator g : GENERATORS) g.elapsed = 0; // every generator starts its first cycle together
        secondTick = 0;
        clearDrops(server);
    }

    /** Removes loose resource items near generators (end/start of a match). */
    public static void clearDrops(MinecraftServer server) {
        ServerLevel level = server.overworld();
        for (Generator g : GENERATORS) {
            if (!level.hasChunkAt(g.pos)) continue;
            for (ItemEntity e : level.getEntitiesOfClass(ItemEntity.class, new AABB(g.pos).inflate(6))) e.discard();
        }
    }

    public static boolean upgrade(ServerPlayer player) {
        String team = BedWarsMod.GAME.teamOf(player);
        if (team == null) { msg(player, "§cJoin a team first."); return false; }
        int tier = tierOf(team);
        if (tier >= 3) { msg(player, "§cYour generator is already Tier III."); return false; }
        if (tier == 1) {
            if (!BedWarsShop.canAfford(player, "upgrade.2")) { msg(player, "§cTier II costs " + BedWarsShop.costText("upgrade.2") + "."); return false; }
            BedWarsShop.charge(player, "upgrade.2");
        } else {
            if (!BedWarsShop.canAfford(player, "upgrade.3a", "upgrade.3b")) {
                msg(player, "§cTier III costs " + BedWarsShop.costText("upgrade.3a") + " + " + BedWarsShop.costText("upgrade.3b") + "."); return false;
            }
            BedWarsShop.charge(player, "upgrade.3a", "upgrade.3b");
        }
        TEAM_TIERS.put(team, tier + 1);
        saveTiers();
        Dim.broadcast(player.level().getServer(), Component.literal(
                BedWarsGameManager.label(team) + " §bgenerator upgraded to Tier " + (tier + 1) + "!"));
        return true;
    }

    private static void msg(ServerPlayer p, String s) { p.sendSystemMessage(Component.literal(s)); }

    // ------------------------------------------------------------------ ticking (once per second)

    /** Current neutral diamond interval (the timeline's upgrade level decides which setting applies). */
    public static int diamondSeconds() {
        int level = BedWarsMod.GAME.upgradeLevel();
        return Math.max(1, Settings.integer(level >= 2 ? "diamond_fast_seconds" : "neutral_diamond_seconds"));
    }

    /** Current neutral emerald interval. */
    public static int emeraldSeconds() {
        int level = BedWarsMod.GAME.upgradeLevel();
        return Math.max(1, Settings.integer(level >= 2 ? "emerald_final_seconds" : level == 1 ? "emerald_fast_seconds" : "emerald_seconds"));
    }

    private static void tickGenerator(MinecraftServer server, Generator gen) {
        boolean neutral = gen.team.equals("neutral");
        int tier = neutral ? 1 : tierOf(gen.team);
        // Neutral generators run for the whole match. A team base only runs for a team that is playing.
        if (!neutral && !BedWarsMod.GAME.isTeamInPlay(gen.team)) return;
        Item item; int seconds; int cap;
        switch (gen.type) {
            case "iron" -> { item = Items.IRON_INGOT; seconds = Settings.integer(tier == 1 ? "gen_iron_t1" : tier == 2 ? "gen_iron_t2" : "gen_iron_t3"); cap = Settings.integer("gen_cap_iron"); }
            case "gold" -> {
                if (!neutral && tier < 2) return; // Gold is locked at Tier I
                item = Items.GOLD_INGOT; seconds = Settings.integer(tier >= 3 ? "gen_gold_t3" : "gen_gold_t2"); cap = Settings.integer("gen_cap_gold");
            }
            case "diamond" -> {
                if (!neutral && tier < 3) return;
                item = Items.DIAMOND; seconds = neutral ? diamondSeconds() : Settings.integer("gen_diamond_t3"); cap = Settings.integer("gen_cap_diamond");
            }
            default -> { item = Items.EMERALD; seconds = emeraldSeconds(); cap = Settings.integer("gen_cap_emerald"); }
        }
        seconds = Math.max(1, seconds);
        cap = Math.max(1, cap);
        if (++gen.elapsed < seconds) return;
        gen.elapsed = 0;
        ServerLevel level = server.overworld();
        if (!level.hasChunkAt(gen.pos)) return;
        int nearby = 0;
        for (ItemEntity e : level.getEntitiesOfClass(ItemEntity.class, new AABB(gen.pos).inflate(4))) {
            if (e.getItem().is(item)) nearby += e.getItem().getCount();
        }
        if (nearby >= cap) return;
        ItemEntity drop = new ItemEntity(level, gen.pos.getX() + 0.5, gen.pos.getY() + 0.5, gen.pos.getZ() + 0.5, new ItemStack(item));
        drop.setDeltaMovement(0, 0.1, 0);
        level.addFreshEntity(drop);
    }
}
