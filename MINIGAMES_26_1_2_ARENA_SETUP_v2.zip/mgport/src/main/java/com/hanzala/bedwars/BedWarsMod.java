package com.hanzala.bedwars;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class BedWarsMod implements ModInitializer {
    public static final String MOD_ID = "bedwars";
    public static final String SHOP_TAG = "bw_shop";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final ProtectionManager PROTECTION = new ProtectionManager();
    public static final BedWarsGameManager GAME = new BedWarsGameManager();

    public static Path configDir() {
        Path dir = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID);
        try { Files.createDirectories(dir); } catch (IOException ex) { LOGGER.error("Could not create " + dir, ex); }
        return dir;
    }

    @Override
    public void onInitialize() {
        LOGGER.info("Starting BedWars 0.13 for Minecraft 1.21.8 (Fabric / Java 21) - active in the Overworld only");

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            BedWarsBackup.init();
            Settings.load();
            ShopConfig.load();
            PROTECTION.load(server);
            GAME.load(server);
            BedWarsGeneratorManager.load(server);
            StatsManager.load();
            Sidebar.hide(server); // drop a sidebar left behind by a crash
            GAME.recoverAfterRestart(server);
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            PROTECTION.unload();
            StatsManager.save();
            Sidebar.hide(server);
            Visuals.clear();
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            GAME.tick(server);
            Visuals.tick();
            PROTECTION.tick();
            BuildRules.tick();
            StatsManager.tick();
        });

        PlayerBlockBreakEvents.BEFORE.register(BedWarsMod::beforeBlockBreak);
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!(world instanceof ServerLevel level)) return;
            PROTECTION.markBroken(level, pos);
            if (GAME.isRunning() && GAME.isRegisteredBed(level, pos)) {
                GAME.destroyBed(level, pos, player instanceof ServerPlayer sp ? sp : null);
            }
        });

        // Nobody may sleep in / set their spawn on a team bed.
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world instanceof ServerLevel level && GAME.isRegisteredBed(level, hit.getBlockPos())) return InteractionResult.FAIL;
            return BuildRules.onUseBlock(player, world, hand, hit); // build zones + instant TNT
        });
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!world.isClientSide() && ShopNpc.isShopNpc(entity) && player instanceof ServerPlayer sp) {
                BedWarsShop.open(sp);
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        });

        // No damage in the lobby (the void still kills) and no friendly fire during a match.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (!(entity instanceof ServerPlayer victim)) return true;
            if (!Dim.inBw(victim)) return true; // End / Nether: BedWars has no say (Hide & Seek has its own rules)
            if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return true;
            if (!GAME.isRunning()) return false;
            if (source.getEntity() instanceof ServerPlayer attacker && attacker != victim) {
                String a = GAME.teamOf(attacker);
                if (a != null && a.equals(GAME.teamOf(victim))) return false;
                GAME.noteDamage(victim, attacker); // so a knock into the void still counts as a kill
            }
            return true;
        });
        // Just before death: resources go to the killer / gear is cleared so nothing piles up on the ground.
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayer player) GAME.beforeDeath(player, source);
            return true;
        });
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayer player) GAME.afterActualDeath(player, source);
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> GAME.onRespawn(newPlayer));
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer player = handler.getPlayer();
            GAME.onJoin(player); // the team menu is opened from /mg (or /bw menu), never automatically
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            Sidebar.forget(handler.getPlayer().getUUID());
            GAME.onDisconnect();
        });

        BedWarsGeneratorManager.registerEvents();
        BedWarsCommands.register();
    }

    private static boolean isBuilder(Player player) {
        return player instanceof ServerPlayer sp && player.isCreative() && sp.createCommandSourceStack().permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_GAMEMASTER);
    }

    private static boolean beforeBlockBreak(Level world, Player player, BlockPos pos, BlockState state, BlockEntity blockEntity) {
        if (!(world instanceof ServerLevel level)) return true;
        String bedOwner = GAME.bedTeamAt(level, pos);
        if (bedOwner != null) {
            if (!GAME.isRunning()) return isBuilder(player);
            String mine = player instanceof ServerPlayer sp ? GAME.teamOf(sp) : null;
            if (mine == null) { player.sendOverlayMessage(Component.literal("§cOnly players on a team can break beds.")); return false; }
            if (mine.equals(bedOwner)) { player.sendOverlayMessage(Component.literal("§cYou cannot break your own bed!")); return false; }
            return true;
        }
        if (isBuilder(player) && !GAME.isRunning()) return true; // admins may edit the map between matches
        // Original map blocks are protected; blocks placed during the match remain breakable.
        return !PROTECTION.isProtected(level, pos) || PROTECTION.isPlayerPlaced(level, pos);
    }
}
