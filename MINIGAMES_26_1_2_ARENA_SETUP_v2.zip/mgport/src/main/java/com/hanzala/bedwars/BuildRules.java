package com.hanzala.bedwars;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/** Where players may place blocks during a match, and TNT that ignites the moment it is placed. */
public final class BuildRules {
    private BuildRules() { }

    private static final class PendingTnt {
        final ServerLevel level; final BlockPos pos; final UUID owner; int age;
        PendingTnt(ServerLevel level, BlockPos pos, UUID owner) { this.level = level; this.pos = pos; this.owner = owner; }
    }

    private static final List<PendingTnt> PENDING = new ArrayList<>();

    /** Called from the UseBlockCallback before vanilla places the block. */
    public static InteractionResult onUseBlock(Player player, Level world, InteractionHand hand, BlockHitResult hit) {
        if (!(world instanceof ServerLevel level) || !(player instanceof ServerPlayer sp)) return InteractionResult.PASS;
        if (!Dim.inBw(sp)) return InteractionResult.PASS; // End (Hide & Seek) and Nether are not part of BedWars
        if (!BedWarsMod.GAME.isRunning() || sp.isCreative() || sp.isSpectator()) return InteractionResult.PASS;
        ItemStack held = sp.getItemInHand(hand);
        if (!(held.getItem() instanceof BlockItem)) return InteractionResult.PASS;

        BlockPos target = new BlockPlaceContext(sp, hand, held, hit).getClickedPos();

        if (Settings.flag("restrict_building")) {
            if (!BedWarsMod.PROTECTION.regions().isEmpty() && !BedWarsMod.PROTECTION.isProtected(level, target)) {
                return deny(sp, "You cannot build outside the arena.");
            }
            int r = Settings.integer("no_build_radius");
            if (r > 0 && (BedWarsGeneratorManager.isNearGenerator(level, target, r) || BedWarsMod.GAME.isNearSpawn(level, target, r))) {
                return deny(sp, "You cannot build next to a generator or a spawn.");
            }
        }
        if (held.is(Items.TNT) && Settings.flag("instant_tnt")) {
            PENDING.add(new PendingTnt(level, target.immutable(), sp.getUUID()));
        }
        return InteractionResult.PASS;
    }

    private static InteractionResult deny(ServerPlayer player, String message) {
        player.sendOverlayMessage(Component.literal("§c" + message));
        return InteractionResult.FAIL;
    }

    /** Runs every server tick: lights the TNT that was placed this tick. */
    public static void tick() {
        if (PENDING.isEmpty()) return;
        Iterator<PendingTnt> it = PENDING.iterator();
        while (it.hasNext()) {
            PendingTnt p = it.next();
            if (p.level.getBlockState(p.pos).is(Blocks.TNT)) {
                ignite(p);
                it.remove();
            } else if (++p.age > 3) {
                it.remove(); // the placement failed (obstructed, cancelled...)
            }
        }
    }

    public static void clear() { PENDING.clear(); }

    private static void ignite(PendingTnt p) {
        ServerLevel level = p.level;
        MinecraftServer server = level.getServer();
        level.setBlock(p.pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
        ServerPlayer owner = server.getPlayerList().getPlayer(p.owner);
        PrimedTnt tnt = new PrimedTnt(level, p.pos.getX() + 0.5, p.pos.getY(), p.pos.getZ() + 0.5, owner);
        tnt.setDeltaMovement(0.0, 0.0, 0.0);
        tnt.setFuse(Math.max(10, Settings.integer("tnt_fuse_ticks")));
        level.addFreshEntity(tnt);
        Fx.soundAt(server, level, p.pos.getX() + 0.5, p.pos.getY() + 0.5, p.pos.getZ() + 0.5, "minecraft:entity.tnt.primed");
    }
}
