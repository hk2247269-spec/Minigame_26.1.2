package com.hanzala.bedwars;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;

/**
 * Scope rules of the combined mod: every minigame lives in the OVERWORLD. BedWars only "sees" Overworld players who are not
 * inside another minigame (TNT Run, Floor Is Lava, Red Light Green Light, Hide &amp; Seek).
 * Everything BedWars does to "all players" (titles, sounds, chat, inventory reset, sidebar...) goes through
 * this class, so players of other minigames are never touched by a BedWars match.
 */
public final class Dim {
    private Dim() { }

    /** True when the entity is in the Overworld and not inside another minigame, i.e. inside BedWars territory. */
    public static boolean inBw(Entity e) {
        return e != null && e.level().dimension() == Level.OVERWORLD && !com.hanzala.minigames.Mg.inNonBedWarsGame(e);
    }

    /** Online players that are currently in the Overworld. */
    public static List<ServerPlayer> players(MinecraftServer server) {
        List<ServerPlayer> out = new ArrayList<>();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (inBw(p)) out.add(p);
        }
        return out;
    }

    /** Chat message for Overworld players only (also written to the server log, like a normal broadcast). */
    public static void broadcast(MinecraftServer server, Component message) {
        for (ServerPlayer p : players(server)) p.sendSystemMessage(message);
        BedWarsMod.LOGGER.info("[BedWars] {}", message.getString());
    }

    /** Same as {@link #broadcast(MinecraftServer, Component)}; the flag is ignored (kept so old call sites compile). */
    public static void broadcast(MinecraftServer server, Component message, boolean ignored) {
        broadcast(server, message);
    }
}
