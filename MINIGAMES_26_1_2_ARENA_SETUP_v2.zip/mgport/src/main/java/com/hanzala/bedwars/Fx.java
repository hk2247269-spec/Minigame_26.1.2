package com.hanzala.bedwars;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.util.Map;

/**
 * Sounds, fireworks and game rules. These deliberately run as vanilla commands: the command syntax is
 * stable and (unlike internal classes) a typo can only log a warning, never stop the mod from loading.
 */
public final class Fx {
    private Fx() { }

    /** Team colours as RGB integers (same values as the v17 datapack; white = vanilla white dye). */
    private static final Map<String, Integer> TEAM_RGB = Map.of(
            "red", 11546150, "blue", 3949738, "green", 6192150,
            "yellow", 16701501, "pink", 15961002, "white", 16383998);

    public static int rgb(String team) { return TEAM_RGB.getOrDefault(team, 16383998); }

    public static void run(MinecraftServer server, String command) {
        try {
            server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(), command);
        } catch (RuntimeException ex) {
            BedWarsMod.LOGGER.warn("Command failed: {} ({})", command, ex.toString());
        }
    }

    public static void sound(MinecraftServer server, ServerPlayer player, String soundId, float pitch) {
        run(server, "execute as " + player.getUUID() + " at @s run playsound " + soundId + " player @s ~ ~ ~ 1 " + pitch);
    }

    public static void soundAll(MinecraftServer server, String soundId, float pitch) {
        run(server, "execute as @a at @s if dimension minecraft:overworld run playsound " + soundId + " player @s ~ ~ ~ 1 " + pitch);
    }

    public static void soundAt(MinecraftServer server, ServerLevel level, double x, double y, double z, String soundId) {
        run(server, "execute in " + level.dimension().identifier() + " run playsound " + soundId + " block @a " + x + " " + y + " " + z + " 1 1");
    }

    /** Two team-coloured rockets beside the player (same shapes as the v17 datapack). */
    public static void fireworks(MinecraftServer server, ServerPlayer player, String team) {
        int c = rgb(team);
        String who = "execute as " + player.getUUID() + " at @s run summon minecraft:firework_rocket ";
        run(server, who + "~2 ~ ~ {LifeTime:24,FireworksItem:{id:\"minecraft:firework_rocket\",count:1,components:{\"minecraft:fireworks\":"
                + "{flight_duration:1,explosions:[{shape:\"large_ball\",colors:[I;" + c + "],fade_colors:[I;16777215],has_trail:true,has_twinkle:true}]}}}}");
        run(server, who + "~-2 ~ ~ {LifeTime:30,FireworksItem:{id:\"minecraft:firework_rocket\",count:1,components:{\"minecraft:fireworks\":"
                + "{flight_duration:2,explosions:[{shape:\"star\",colors:[I;" + c + ",16777215],has_twinkle:true}]}}}}");
    }

    /** Match-only game rules. Outside a match they are returned to the vanilla defaults. */
    public static void matchRules(MinecraftServer server, boolean inMatch) {
        if (!Settings.flag("match_gamerules")) return;
        run(server, "gamerule block_drops " + !inMatch);
        run(server, "gamerule immediate_respawn " + inMatch);
    }
}
