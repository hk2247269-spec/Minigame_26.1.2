package com.hanzala.bedwars;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Map protection. Blocks that existed in the original map (inside a protected region) can never be
 * removed or replaced during a match. Blocks that appear during a match (placed by players, water,
 * fire...) are tracked, may be broken, and are all removed again when the match ends.
 */
public final class ProtectionManager {
    public record Region(String name, ResourceKey<Level> dimension, int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
        boolean contains(BlockPos p) {
            return p.getX() >= minX && p.getX() <= maxX && p.getY() >= minY && p.getY() <= maxY
                    && p.getZ() >= minZ && p.getZ() <= maxZ;
        }
        public String describe() {
            return name + " " + dimension.identifier() + " " + minX + " " + minY + " " + minZ + " -> " + maxX + " " + maxY + " " + maxZ;
        }
    }

    private final Map<String, Region> regions = new LinkedHashMap<>();
    private final Map<ResourceKey<Level>, Set<Long>> placed = new HashMap<>();
    private Path regionFile;
    private Path placedFile;
    private boolean dirty;
    private int tickCounter;

    public void load(MinecraftServer server) {
        regions.clear();
        placed.clear();
        Path dir = BedWarsMod.configDir();
        regionFile = dir.resolve("protected-regions.txt");
        placedFile = dir.resolve("player-placed-blocks.txt");
        try {
            if (!Files.exists(regionFile)) Files.writeString(regionFile,
                    "# name dimension minX minY minZ maxX maxY maxZ\n# Easier: use /bw region add <name> <from> <to> in game.\n");
            if (!Files.exists(placedFile)) Files.createFile(placedFile);
            int lineNo = 0;
            for (String raw : Files.readAllLines(regionFile)) {
                lineNo++;
                String line = raw.split("#", 2)[0].trim();
                if (line.isEmpty()) continue;
                String[] p = line.split("\\s+");
                if (p.length != 8) { BedWarsMod.LOGGER.warn("Invalid protected region on line {}", lineNo); continue; }
                try {
                    addRegionInternal(p[0], ResourceKey.create(Registries.DIMENSION, Identifier.parse(p[1])),
                            Integer.parseInt(p[2]), Integer.parseInt(p[3]), Integer.parseInt(p[4]),
                            Integer.parseInt(p[5]), Integer.parseInt(p[6]), Integer.parseInt(p[7]));
                } catch (RuntimeException ex) { BedWarsMod.LOGGER.warn("Invalid protected region on line {}", lineNo); }
            }
            for (String raw : Files.readAllLines(placedFile)) {
                String[] p = raw.trim().split("\\s+");
                if (p.length != 4) continue;
                try {
                    ResourceKey<Level> dim = ResourceKey.create(Registries.DIMENSION, Identifier.parse(p[0]));
                    placed.computeIfAbsent(dim, k -> new HashSet<>())
                            .add(new BlockPos(Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3])).asLong());
                } catch (RuntimeException ignored) { }
            }
            BedWarsMod.LOGGER.info("Loaded {} protected regions", regions.size());
        } catch (IOException ex) { BedWarsMod.LOGGER.error("Could not load BedWars protection data", ex); }
    }

    private void addRegionInternal(String name, ResourceKey<Level> dim, int x1, int y1, int z1, int x2, int y2, int z2) {
        regions.put(name.toLowerCase(Locale.ROOT), new Region(name, dim, Math.min(x1, x2), Math.min(y1, y2), Math.min(z1, z2),
                Math.max(x1, x2), Math.max(y1, y2), Math.max(z1, z2)));
    }

    public void addRegion(String name, ResourceKey<Level> dim, BlockPos a, BlockPos b) {
        addRegionInternal(name, dim, a.getX(), a.getY(), a.getZ(), b.getX(), b.getY(), b.getZ());
        saveRegions();
    }

    public boolean removeRegion(String name) {
        boolean removed = regions.remove(name.toLowerCase(Locale.ROOT)) != null;
        if (removed) saveRegions();
        return removed;
    }

    /** Removes every protected region. Returns how many were removed. */
    public int clearRegions() {
        int count = regions.size();
        regions.clear();
        saveRegions();
        return count;
    }

    public Collection<Region> regions() { return regions.values(); }

    public boolean isProtected(ServerLevel level, BlockPos pos) {
        if (regions.isEmpty()) return false;
        ResourceKey<Level> dim = level.dimension();
        for (Region r : regions.values()) if (r.dimension.equals(dim) && r.contains(pos)) return true;
        return false;
    }

    public boolean isPlayerPlaced(ServerLevel level, BlockPos pos) {
        Set<Long> set = placed.get(level.dimension());
        return set != null && set.contains(pos.asLong());
    }

    public void markPlaced(ServerLevel level, BlockPos pos) {
        if (placed.computeIfAbsent(level.dimension(), k -> new HashSet<>()).add(pos.asLong())) dirty = true;
    }

    public void markBroken(ServerLevel level, BlockPos pos) {
        Set<Long> set = placed.get(level.dimension());
        if (set != null && set.remove(pos.asLong())) dirty = true;
    }

    /** True means this position must be removed from an explosion's block list. */
    public boolean shouldShieldFromExplosion(ServerLevel level, BlockPos pos) {
        return isProtected(level, pos) && !isPlayerPlaced(level, pos);
    }

    /** Removes every block that appeared during a match. Call only while the match is NOT running. */
    public void clearPlaced(MinecraftServer server) {
        for (int pass = 0; pass < 2; pass++) {
            for (Map.Entry<ResourceKey<Level>, Set<Long>> entry : new ArrayList<>(placed.entrySet())) {
                ServerLevel level = server.getLevel(entry.getKey());
                if (level == null) continue;
                for (long packed : new ArrayList<>(entry.getValue())) {
                    BlockPos pos = BlockPos.of(packed);
                    if (!level.getBlockState(pos).isAir()) level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                }
            }
        }
        placed.clear();
        dirty = true;
        savePlaced();
    }

    public void tick() {
        if (dirty && ++tickCounter % 100 == 0) savePlaced();
    }

    private void saveRegions() {
        if (regionFile == null) return;
        List<String> lines = new ArrayList<>();
        lines.add("# name dimension minX minY minZ maxX maxY maxZ");
        for (Region r : regions.values()) lines.add(r.name + " " + r.dimension.identifier() + " " + r.minX + " " + r.minY + " " + r.minZ
                + " " + r.maxX + " " + r.maxY + " " + r.maxZ);
        try { Files.write(regionFile, lines); }
        catch (IOException ex) { BedWarsMod.LOGGER.error("Could not save protected regions", ex); }
    }

    private void savePlaced() {
        if (placedFile == null) return;
        List<String> lines = new ArrayList<>();
        for (Map.Entry<ResourceKey<Level>, Set<Long>> e : placed.entrySet()) {
            for (long packed : e.getValue()) {
                BlockPos p = BlockPos.of(packed);
                lines.add(e.getKey().identifier() + " " + p.getX() + " " + p.getY() + " " + p.getZ());
            }
        }
        Collections.sort(lines);
        try { Files.write(placedFile, lines); dirty = false; }
        catch (IOException ex) { BedWarsMod.LOGGER.error("Could not save player-placed block tracking", ex); }
    }

    public void unload() { savePlaced(); regions.clear(); placed.clear(); placedFile = null; regionFile = null; }
}
