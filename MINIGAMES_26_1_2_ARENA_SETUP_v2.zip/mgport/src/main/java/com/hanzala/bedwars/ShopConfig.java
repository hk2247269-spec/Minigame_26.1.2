package com.hanzala.bedwars;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Operator-editable shop: price, currency, amount and on/off switch of every shop item, armour tier and
 * generator upgrade. Stored in config/bedwars/shop.txt ("key.field=value"). Every key has a default,
 * so a missing file or a typo never breaks the shop. The admin GUI (/bw admin -> Shop & Prices) edits it.
 *
 * Keys: the shop item id (wool, tnt, ...), armor.chain / armor.iron / armor.diamond,
 * upgrade.2 (Tier II cost), upgrade.3a and upgrade.3b (Tier III costs, both are charged).
 */
public final class ShopConfig {
    private ShopConfig() { }

    public static final int MAX_PRICE = 999;
    public static final List<String> CURRENCIES = List.of("iron", "gold", "diamond", "emerald");

    /** What the admin GUI shows for one editable line. */
    public record Entry(String key, String name, Item icon, boolean amountEditable) { }

    private record Def(int price, String currency, int amount) { }

    private static final Map<String, Entry> ENTRIES = new LinkedHashMap<>();
    private static final Map<String, Def> DEFS = new HashMap<>();
    private static final Map<String, Integer> PRICE = new HashMap<>();
    private static final Map<String, Integer> AMOUNT = new HashMap<>();
    private static final Map<String, String> CURRENCY = new HashMap<>();
    private static final Set<String> DISABLED = new HashSet<>();

    static {
        register("armor.chain", "Chain Armour", Items.CHAINMAIL_LEGGINGS, 16, "gold", 1, false);
        register("armor.iron", "Iron Armour", Items.IRON_LEGGINGS, 28, "gold", 1, false);
        register("armor.diamond", "Diamond Armour", Items.DIAMOND_LEGGINGS, 8, "emerald", 1, false);
        register("upgrade.2", "Generator Tier II", Items.BEACON, 4, "diamond", 1, false);
        register("upgrade.3a", "Generator Tier III (cost 1)", Items.BEACON, 5, "emerald", 1, false);
        register("upgrade.3b", "Generator Tier III (cost 2)", Items.BEACON, 5, "diamond", 1, false);
    }

    /** Called once per line when the class is set up (shop items are registered from BedWarsShop). */
    static void register(String key, String name, Item icon, int price, String currency, int amount, boolean amountEditable) {
        ENTRIES.put(key, new Entry(key, name, icon, amountEditable));
        DEFS.put(key, new Def(price, currency, amount));
    }

    // ------------------------------------------------------------------ reading

    /** Shop items first (in shop order), then armour and generator upgrades. */
    public static List<Entry> entries() {
        List<Entry> out = new ArrayList<>();
        for (Entry e : ENTRIES.values()) if (!e.key().contains(".")) out.add(e);
        for (Entry e : ENTRIES.values()) if (e.key().contains(".")) out.add(e);
        return out;
    }

    public static Entry entry(String key) { return ENTRIES.get(key); }

    public static int price(String key) {
        Def def = DEFS.get(key);
        return PRICE.getOrDefault(key, def == null ? 0 : def.price());
    }

    public static int defaultPrice(String key) { Def def = DEFS.get(key); return def == null ? 0 : def.price(); }

    public static int amount(String key) {
        Def def = DEFS.get(key);
        return AMOUNT.getOrDefault(key, def == null ? 1 : def.amount());
    }

    public static int defaultAmount(String key) { Def def = DEFS.get(key); return def == null ? 1 : def.amount(); }

    /** Currency as "iron", "gold", "diamond" or "emerald". */
    public static String currencyId(String key) {
        Def def = DEFS.get(key);
        return CURRENCY.getOrDefault(key, def == null ? "emerald" : def.currency());
    }

    public static String defaultCurrencyId(String key) { Def def = DEFS.get(key); return def == null ? "emerald" : def.currency(); }

    public static Item currency(String key) { return item(currencyId(key)); }

    public static boolean enabled(String key) { return !DISABLED.contains(key); }

    // ------------------------------------------------------------------ currency helpers

    public static Item item(String currency) {
        return switch (currency) {
            case "iron" -> Items.IRON_INGOT;
            case "gold" -> Items.GOLD_INGOT;
            case "diamond" -> Items.DIAMOND;
            default -> Items.EMERALD;
        };
    }

    public static String id(Item item) {
        if (item == Items.IRON_INGOT) return "iron";
        if (item == Items.GOLD_INGOT) return "gold";
        if (item == Items.DIAMOND) return "diamond";
        return "emerald";
    }

    public static String label(String currency) {
        return switch (currency) {
            case "iron" -> "Iron";
            case "gold" -> "Gold";
            case "diamond" -> "Diamond";
            default -> "Emerald";
        };
    }

    public static String colour(String currency) {
        return switch (currency) {
            case "iron" -> "§f";
            case "gold" -> "§6";
            case "diamond" -> "§b";
            default -> "§a";
        };
    }

    // ------------------------------------------------------------------ editing (each change is saved at once)

    public static void setPrice(String key, int value) {
        if (!DEFS.containsKey(key)) return;
        PRICE.put(key, Math.max(0, Math.min(MAX_PRICE, value)));
        save();
    }

    public static void setAmount(String key, int value) {
        Entry e = ENTRIES.get(key);
        if (e == null || !e.amountEditable()) return;
        AMOUNT.put(key, Math.max(1, Math.min(64, value)));
        save();
    }

    public static void cycleCurrency(String key) {
        if (!DEFS.containsKey(key)) return;
        int i = CURRENCIES.indexOf(currencyId(key));
        CURRENCY.put(key, CURRENCIES.get((i + 1) % CURRENCIES.size()));
        save();
    }

    public static void setEnabled(String key, boolean on) {
        if (!DEFS.containsKey(key)) return;
        if (on) DISABLED.remove(key); else DISABLED.add(key);
        save();
    }

    public static void reset(String key) {
        PRICE.remove(key); AMOUNT.remove(key); CURRENCY.remove(key); DISABLED.remove(key);
        save();
    }

    public static void resetAll() {
        PRICE.clear(); AMOUNT.clear(); CURRENCY.clear(); DISABLED.clear();
        save();
    }

    /** Raises or lowers every price by a percentage (rounded; a price never drops to 0 by scaling). */
    public static void scaleAll(int percent) {
        for (String key : DEFS.keySet()) {
            int p = price(key);
            if (p <= 0) continue;
            int n = Math.round(p * (100 + percent) / 100f);
            if (percent > 0 && n <= p) n = p + 1;
            if (percent < 0 && n >= p) n = p - 1;
            PRICE.put(key, Math.max(1, Math.min(MAX_PRICE, n)));
        }
        save();
    }

    // ------------------------------------------------------------------ file

    public static void load() {
        BedWarsShop.offerIds(); // makes sure every shop item is registered before the file is read
        PRICE.clear(); AMOUNT.clear(); CURRENCY.clear(); DISABLED.clear();
        Path file = BedWarsMod.configDir().resolve("shop.txt");
        try {
            if (!Files.exists(file)) { save(); return; }
            for (String raw : Files.readAllLines(file)) {
                String line = raw.split("#", 2)[0].trim();
                int eq = line.indexOf('=');
                if (eq <= 0) continue;
                String left = line.substring(0, eq).trim().toLowerCase(Locale.ROOT);
                String value = line.substring(eq + 1).trim().toLowerCase(Locale.ROOT);
                int dot = left.lastIndexOf('.');
                if (dot <= 0) continue;
                String key = left.substring(0, dot);
                String field = left.substring(dot + 1);
                if (!DEFS.containsKey(key)) {
                    BedWarsMod.LOGGER.warn("shop.txt: unknown item '{}' ignored", key);
                    continue;
                }
                try {
                    switch (field) {
                        case "price" -> PRICE.put(key, Math.max(0, Math.min(MAX_PRICE, Integer.parseInt(value))));
                        case "amount" -> { if (ENTRIES.get(key).amountEditable()) AMOUNT.put(key, Math.max(1, Math.min(64, Integer.parseInt(value)))); }
                        case "currency" -> { if (CURRENCIES.contains(value)) CURRENCY.put(key, value); }
                        case "enabled" -> { if (value.equals("false") || value.equals("off") || value.equals("no") || value.equals("0")) DISABLED.add(key); }
                        default -> { }
                    }
                } catch (NumberFormatException ex) {
                    BedWarsMod.LOGGER.warn("shop.txt: bad number for '{}' ignored", left);
                }
            }
        } catch (IOException ex) {
            BedWarsMod.LOGGER.error("Could not read shop.txt (defaults are used)", ex);
        }
    }

    private static void save() {
        List<String> lines = new ArrayList<>();
        lines.add("# BedWars shop. Edit, then run /bw reload in game (or restart the server).");
        lines.add("# The admin GUI (/bw admin -> Shop & Prices) edits this file too.");
        lines.add("# currency: iron, gold, diamond or emerald. enabled: true or false. amount: 1-64 (only for stackable items).");
        lines.add("# upgrade.2 = generator Tier II cost. upgrade.3a and upgrade.3b = Tier III costs (both are charged; price 0 = not charged).");
        for (Entry e : entries()) {
            String k = e.key();
            lines.add("");
            lines.add("# " + e.name());
            lines.add(k + ".price=" + price(k));
            lines.add(k + ".currency=" + currencyId(k));
            if (e.amountEditable()) lines.add(k + ".amount=" + amount(k));
            lines.add(k + ".enabled=" + enabled(k));
        }
        try { Files.write(BedWarsMod.configDir().resolve("shop.txt"), lines); }
        catch (IOException ex) { BedWarsMod.LOGGER.error("Could not save shop.txt", ex); }
    }
}
