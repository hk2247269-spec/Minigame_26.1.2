package com.hanzala.bedwars;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The shop chest GUI. Server driven (no client mod): clicking an icon buys the item. Every icon shows its
 * category, price in the currency's colour, how much you own, a short description and whether you can afford it.
 * The screen refreshes after every click so the numbers stay correct.
 */
public final class ShopMenu extends ServerGui {
    private static final int[] SLOTS = {0, 1, 2, 3, 4, 5, 6, 7, 9, 10, 11, 12, 13, 14, 15, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28};
    private static final String[] IDS = {"wool", "planks", "terracotta", "end_stone", "glass", "obsidian", "ladder", "cobweb",
            "stone_sword", "iron_sword", "diamond_sword", "knockback_stick", "bow", "power_bow", "arrows",
            "shears", "iron_pickaxe", "iron_axe", "diamond_pickaxe", "diamond_axe", "golden_apple", "ender_pearl",
            "water_bucket", "tnt", "speed", "jump"};

    private static final Map<String, String> DESCRIPTION = Map.ofEntries(
            Map.entry("wool", "Quick bridging. Takes your team colour."),
            Map.entry("planks", "Sturdy blocks for bridges and walls."),
            Map.entry("terracotta", "Tougher than wool. Team colour."),
            Map.entry("end_stone", "Very blast resistant: great against TNT."),
            Map.entry("glass", "Blast proof and see-through. Team colour."),
            Map.entry("obsidian", "Almost unbreakable bed protection."),
            Map.entry("ladder", "Climb walls and towers quickly."),
            Map.entry("cobweb", "Slows down enemies that touch it."),
            Map.entry("stone_sword", "A solid early upgrade over the wooden sword."),
            Map.entry("iron_sword", "Strong mid-game sword."),
            Map.entry("diamond_sword", "The strongest sword in the shop."),
            Map.entry("knockback_stick", "Knockback I: push enemies off the island."),
            Map.entry("bow", "Ranged damage. Needs arrows."),
            Map.entry("power_bow", "Bow with Power I."),
            Map.entry("arrows", "Ammunition for your bow."),
            Map.entry("shears", "Cuts through wool much faster."),
            Map.entry("iron_pickaxe", "Efficiency I. Breaks blocks faster."),
            Map.entry("iron_axe", "Efficiency I. Breaks wood faster."),
            Map.entry("diamond_pickaxe", "Efficiency II. Breaks blocks very fast."),
            Map.entry("diamond_axe", "Efficiency II. Breaks wood very fast."),
            Map.entry("golden_apple", "Heals you and gives absorption."),
            Map.entry("ender_pearl", "Teleports you to where it lands."),
            Map.entry("water_bucket", "Cancels falls and puts out fire."),
            Map.entry("tnt", "Ignites the moment you place it."),
            Map.entry("speed", "Speed II for 45 seconds."),
            Map.entry("jump", "Jump Boost V for 45 seconds."));

    public ShopMenu(int containerId, Inventory inventory) {
        super(4, containerId, inventory);
        build();
    }

    // ------------------------------------------------------------------ helpers

    private static String currencyColour(Item currency) {
        if (currency == Items.IRON_INGOT) return "§f";
        if (currency == Items.GOLD_INGOT) return "§6";
        if (currency == Items.DIAMOND) return "§b";
        return "§a";
    }

    private static String category(String id) {
        return switch (id) {
            case "wool", "planks", "terracotta", "end_stone", "glass", "obsidian", "ladder", "cobweb" -> "§aBlocks";
            case "stone_sword", "iron_sword", "diamond_sword", "knockback_stick", "bow", "power_bow", "arrows" -> "§cCombat";
            case "shears", "iron_pickaxe", "iron_axe", "diamond_pickaxe", "diamond_axe" -> "§eTools";
            default -> "§dUtility";
        };
    }

    private static String price(Item currency, int amount) { return currencyColour(currency) + amount + " " + BedWarsShop.currencyName(currency); }

    /** The "can I afford it" line and the owned count. */
    private static void costLines(List<String> lore, ServerPlayer p, Item currency, int amount) {
        int have = BedWarsShop.count(p, currency);
        lore.add("§7Cost: " + price(currency, amount));
        lore.add("§7You have: " + (have >= amount ? "§a" : "§c") + have);
        lore.add(" ");
        lore.add(have >= amount ? "§a▶ Click to buy" : "§c✘ Need " + (amount - have) + " more " + BedWarsShop.currencyName(currency));
    }

    @Override
    protected void build() {
        reset();
        for (int i = 0; i < IDS.length; i++) {
            BedWarsShop.Offer o = BedWarsShop.offer(IDS[i]);
            if (o == null) continue;
            String id = IDS[i];
            if (!o.enabled()) {
                put(SLOTS[i], icon(Items.BARRIER, "§c" + o.name(), "§7Not for sale right now."));
                continue;
            }
            List<String> lore = new ArrayList<>();
            lore.add(category(id) + (o.amount() > 1 ? " §8x" + o.amount() : ""));
            lore.add(" ");
            lore.addAll(wrap(DESCRIPTION.getOrDefault(id, ""), 36));
            lore.add(" ");
            costLines(lore, viewer, o.currency(), o.price());
            put(SLOTS[i], icon(o.icon(), o.amount(), "§e" + o.name(), lore), (p, button, shift) -> {
                boolean ok = BedWarsShop.buy(p, id);
                MinecraftServer server = p.level().getServer();
                if (server != null) Visuals.sfxTo(server, p, ok ? "entity.experience_orb.pickup" : "entity.villager.no", ok ? 1.2F : 1.0F);
                refresh();
            });
        }

        armour(30, Items.CHAINMAIL_LEGGINGS, "chain", "Chain Armour", 1);
        armour(31, Items.IRON_LEGGINGS, "iron", "Iron Armour", 2);
        armour(32, Items.DIAMOND_LEGGINGS, "diamond", "Diamond Armour", 3);

        // Your resources
        put(29, icon(Items.CHEST, "§e§lYour resources",
                "§fIron §7" + BedWarsShop.count(viewer, Items.IRON_INGOT),
                "§6Gold §7" + BedWarsShop.count(viewer, Items.GOLD_INGOT),
                "§bDiamond §7" + BedWarsShop.count(viewer, Items.DIAMOND),
                "§aEmerald §7" + BedWarsShop.count(viewer, Items.EMERALD)));

        // Generator upgrade with full information
        put(34, upgradeIcon(), (p, button, shift) -> {
            boolean ok = BedWarsGeneratorManager.upgrade(p);
            MinecraftServer server = p.level().getServer();
            if (server != null) Visuals.sfxTo(server, p, ok ? "block.beacon.activate" : "entity.villager.no", 1.0F);
            refresh();
        });

        // Match clock and neutral generator speeds
        List<String> clock = new ArrayList<>(BedWarsMod.GAME.timelineSummary());
        clock.add(" ");
        clock.add("§7Neutral diamond: every §b" + BedWarsGeneratorManager.diamondSeconds() + "s");
        clock.add("§7Neutral emerald: every §a" + BedWarsGeneratorManager.emeraldSeconds() + "s");
        put(35, icon(Items.CLOCK, "§6§lMatch clock", clock));
    }

    private void armour(int slot, Item iconItem, String tier, String name, int level) {
        String key = "armor." + tier;
        if (!ShopConfig.enabled(key)) {
            put(slot, icon(Items.BARRIER, "§c" + name, "§7Not for sale right now."));
            return;
        }
        Item currency = ShopConfig.currency(key);
        int amount = ShopConfig.price(key);
        int owned = BedWarsShop.armorTier(viewer);
        List<String> lore = new ArrayList<>();
        lore.add("§dArmour §8leggings + boots");
        lore.add(" ");
        lore.addAll(wrap("Kept after death. Replaces your leather leggings and boots.", 36));
        lore.add(" ");
        if (owned >= level) {
            lore.add("§a✔ You own this tier or better");
        } else {
            costLines(lore, viewer, currency, amount);
        }
        var stack = icon(iconItem, "§e" + name, lore);
        if (owned >= level) glow(stack);
        put(slot, stack, (p, button, shift) -> {
            boolean ok = BedWarsShop.buyArmor(p, tier);
            MinecraftServer server = p.level().getServer();
            if (server != null) Visuals.sfxTo(server, p, ok ? "item.armor.equip_iron" : "entity.villager.no", 1.0F);
            refresh();
        });
    }

    /** Beacon tile: current tier, what each tier gives and the price of the next one. */
    private net.minecraft.world.item.ItemStack upgradeIcon() {
        BedWarsGameManager game = BedWarsMod.GAME;
        String team = game.teamOf(viewer);
        int tier = team == null ? 1 : BedWarsGeneratorManager.tierOf(team);
        List<String> lore = new ArrayList<>();
        lore.add("§7Your team generator");
        lore.add(" ");
        lore.add(tierLine(1, tier, "Iron every " + Settings.integer("gen_iron_t1") + "s"));
        lore.add(tierLine(2, tier, "Iron " + Settings.integer("gen_iron_t2") + "s + Gold every " + Settings.integer("gen_gold_t2") + "s"));
        lore.add(tierLine(3, tier, "Iron " + Settings.integer("gen_iron_t3") + "s, Gold " + Settings.integer("gen_gold_t3") + "s + Diamond " + Settings.integer("gen_diamond_t3") + "s"));
        lore.add(" ");
        if (team == null) {
            lore.add("§cJoin a team first");
        } else if (tier >= 3) {
            lore.add("§a✔ Maximum tier reached");
        } else if (tier == 1) {
            boolean can = BedWarsShop.canAfford(viewer, "upgrade.2");
            Item c2 = ShopConfig.currency("upgrade.2");
            lore.add("§7Next: Tier II for " + price(c2, ShopConfig.price("upgrade.2")));
            lore.add("§7You have: " + (can ? "§a" : "§c") + BedWarsShop.count(viewer, c2));
            lore.add(can ? "§a▶ Click to upgrade" : "§c✘ Not enough " + BedWarsShop.currencyName(c2));
        } else {
            boolean can = BedWarsShop.canAfford(viewer, "upgrade.3a", "upgrade.3b");
            Item ca = ShopConfig.currency("upgrade.3a");
            Item cb = ShopConfig.currency("upgrade.3b");
            lore.add("§7Next: Tier III for " + price(ca, ShopConfig.price("upgrade.3a")) + " §7+ " + price(cb, ShopConfig.price("upgrade.3b")));
            lore.add("§7You have: " + (can ? "§a" : "§c") + BedWarsShop.count(viewer, ca) + " " + BedWarsShop.currencyName(ca)
                    + " §7/ " + (can ? "§a" : "§c") + BedWarsShop.count(viewer, cb) + " " + BedWarsShop.currencyName(cb));
            lore.add(can ? "§a▶ Click to upgrade" : "§c✘ Not enough resources");
        }
        return icon(Items.BEACON, "§b§lUpgrade Generator §7(Tier " + roman(tier) + ")", lore);
    }

    private static String tierLine(int tier, int current, String text) {
        String mark = tier < current ? "§a✔ " : tier == current ? "§b▶ " : "§8  ";
        String colour = tier <= current ? "§f" : "§7";
        return mark + colour + "Tier " + roman(tier) + "§8: " + colour + text;
    }

    private static String roman(int n) { return n == 1 ? "I" : n == 2 ? "II" : "III"; }
}
