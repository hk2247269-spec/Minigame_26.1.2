package com.hanzala.bedwars;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.numbers.BlankFormat;
import net.minecraft.network.chat.numbers.NumberFormat;
import net.minecraft.network.protocol.game.ClientboundResetScorePacket;
import net.minecraft.network.protocol.game.ClientboundSetDisplayObjectivePacket;
import net.minecraft.network.protocol.game.ClientboundSetObjectivePacket;
import net.minecraft.network.protocol.game.ClientboundSetScorePacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.criteria.ObjectiveCriteria;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * The BedWars sidebar and the team colours.
 *
 * The sidebar is now PER PLAYER (raw packets from a private scoreboard, like the Hide &amp; Seek sidebar) and is only
 * sent to players who are in the Overworld. A player who walks into the End gets it removed; a player who comes back
 * gets it again. So the scoreboard follows the dimension: BedWars board in the Overworld, Hide &amp; Seek board in the End.
 * The real server scoreboard is only used for the bwm_* team colours.
 */
public final class Sidebar {
    private Sidebar() { }

    private static final String OBJECTIVE = "bwm_side";
    private static final String HOLDER = "bwm_l";
    private static final String TEAM_PREFIX = "bwm_";
    private static final int MAX_LINES = 15;

    private static final Scoreboard PACKET_SB = new Scoreboard();
    private static final Objective OBJ = new Objective(PACKET_SB, OBJECTIVE, ObjectiveCriteria.DUMMY,
            Component.literal("BEDWARS"), ObjectiveCriteria.RenderType.INTEGER, false, BlankFormat.INSTANCE);

    /** Players whose client currently has the BedWars sidebar. */
    private static final Set<UUID> SHOWN = new HashSet<>();
    private static List<String> lastLines = List.of();
    private static String lastTitle = "";

    // ------------------------------------------------------------------ sidebar

    private static void sendFull(ServerPlayer p, List<String> lines) {
        p.connection.send(new ClientboundSetObjectivePacket(OBJ, 0));
        p.connection.send(new ClientboundSetDisplayObjectivePacket(DisplaySlot.SIDEBAR, OBJ));
        int n = lines.size();
        for (int i = 0; i < n; i++) {
            p.connection.send(new ClientboundSetScorePacket(HOLDER + i, OBJECTIVE, n - i,
                    Optional.of(Component.literal(lines.get(i))), Optional.<NumberFormat>of(BlankFormat.INSTANCE)));
        }
    }

    private static void sendRemove(ServerPlayer p) {
        p.connection.send(new ClientboundSetObjectivePacket(OBJ, 1));
    }

    /** Shows (or updates) the sidebar for every Overworld player. Lines are top to bottom; legacy colour codes are allowed. */
    public static void show(MinecraftServer server, String title, List<String> lines) {
        List<String> wanted = new java.util.ArrayList<>(lines.size() > MAX_LINES - 1 ? lines.subList(0, MAX_LINES - 1) : lines);
        wanted.add("§8Owner: HANZALA");
        OBJ.setDisplayName(Component.literal(title));
        boolean titleChanged = !title.equals(lastTitle);
        int n = wanted.size();
        int oldN = lastLines.size();
        boolean sameShape = n == oldN;

        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            UUID id = p.getUUID();
            boolean want = Dim.inBw(p) && BedWarsMod.GAME.teamOf(p) != null && !com.hanzala.minigames.Mg.hasOwnSidebar(p); // only BedWars participants; other minigames have their own sidebar
            boolean has = SHOWN.contains(id);
            if (want && !has) {
                OBJ.setDisplayName(Component.literal(title));
                sendFull(p, wanted);
                SHOWN.add(id);
            } else if (!want && has) {
                sendRemove(p);
                SHOWN.remove(id);
            } else if (want) {
                if (titleChanged) p.connection.send(new ClientboundSetObjectivePacket(OBJ, 2));
                // scores are keyed by position and ranked by (n - i): if the number of lines changed every rank moves
                for (int i = 0; i < n; i++) {
                    if (sameShape && wanted.get(i).equals(lastLines.get(i))) continue;
                    p.connection.send(new ClientboundSetScorePacket(HOLDER + i, OBJECTIVE, n - i,
                            Optional.of(Component.literal(wanted.get(i))), Optional.<NumberFormat>of(BlankFormat.INSTANCE)));
                }
                for (int i = n; i < oldN; i++) {
                    p.connection.send(new ClientboundResetScorePacket(HOLDER + i, OBJECTIVE));
                }
            }
        }
        SHOWN.removeIf(id -> server.getPlayerList().getPlayer(id) == null);
        lastLines = List.copyOf(wanted);
        lastTitle = title;
    }

    /** Changes only the header of the sidebar (one tiny packet per Overworld player, only when the text changed). */
    public static void title(MinecraftServer server, String title) {
        if (title.equals(lastTitle)) return;
        OBJ.setDisplayName(Component.literal(title));
        lastTitle = title;
        ClientboundSetObjectivePacket pk = new ClientboundSetObjectivePacket(OBJ, 2);
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (!SHOWN.contains(p.getUUID())) continue;
            if (Dim.inBw(p)) p.connection.send(pk);
            else { sendRemove(p); SHOWN.remove(p.getUUID()); } // left the Overworld
        }
    }

    /** Removes the sidebar from everybody (also cleans up a leftover server-side objective from older versions / crashes). */
    public static void hide(MinecraftServer server) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (SHOWN.contains(p.getUUID())) sendRemove(p);
        }
        SHOWN.clear();
        Scoreboard sb = server.getScoreboard();
        Objective old = sb.getObjective(OBJECTIVE);
        if (old != null) sb.removeObjective(old);
        lastLines = List.of();
        lastTitle = "";
    }

    /** A disconnected player's client is gone: forget it so a reconnect gets the full sidebar again. */
    public static void forget(UUID id) { SHOWN.remove(id); }

    // ------------------------------------------------------------------ team colours

    private static ChatFormatting formatting(String team) {
        return switch (team) {
            case "red" -> ChatFormatting.RED;
            case "blue" -> ChatFormatting.BLUE;
            case "green" -> ChatFormatting.GREEN;
            case "yellow" -> ChatFormatting.YELLOW;
            case "pink" -> ChatFormatting.LIGHT_PURPLE;
            default -> ChatFormatting.WHITE;
        };
    }

    private static PlayerTeam ensureTeam(Scoreboard sb, String team) {
        String id = TEAM_PREFIX + team;
        PlayerTeam t = sb.getPlayerTeam(id);
        if (t == null) t = sb.addPlayerTeam(id);
        ChatFormatting fmt = formatting(team);
        t.setColor(fmt);
        t.setPlayerPrefix(Component.literal("[" + team.substring(0, 1).toUpperCase(Locale.ROOT) + "] ").withStyle(fmt));
        return t;
    }

    /** Puts every Overworld player into the scoreboard team that matches their BedWars team (or removes them). */
    public static void syncTeams(MinecraftServer server) {
        Scoreboard sb = server.getScoreboard();
        boolean enabled = Settings.flag("team_colors");
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            String name = p.getScoreboardName();
            PlayerTeam current = sb.getPlayersTeam(name);
            String want = enabled && Dim.inBw(p) ? BedWarsMod.GAME.teamOf(p) : null;
            if (current != null) {
                if (!current.getName().startsWith(TEAM_PREFIX)) continue; // belongs to someone else (e.g. Hide & Seek): never touch it
                if (want != null && current.getName().equals(TEAM_PREFIX + want)) continue; // already correct
                sb.removePlayerFromTeam(name, current);
            }
            if (want != null) sb.addPlayerToTeam(name, ensureTeam(sb, want));
        }
    }
}
