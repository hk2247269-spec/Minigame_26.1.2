package com.hanzala.bedwars;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Items;

import java.util.List;

/** Spectator GUI limited to living members of the eliminated player's own team. */
public final class TeamPovMenu extends ServerGui {
    private static final int[] SLOTS = {10,11,12,13,14,15,16};
    public static void open(ServerPlayer p) { p.openMenu(new SimpleMenuProvider((id, inv, player) -> new TeamPovMenu(id, inv), Component.literal("Team Spectator"))); }
    private TeamPovMenu(int id, Inventory inv) { super(3,id,inv); build(); }
    @Override protected void build() {
        reset();
        List<ServerPlayer> mates = BedWarsMod.GAME.survivingTeammates(viewer);
        put(4, icon(Items.COMPASS,"§b§lTEAM POV", "§7Choose a surviving teammate to watch.", "§8Only your own team is shown."));
        if (mates.isEmpty()) put(13, icon(Items.BARRIER,"§cNo teammates alive","§7You can spectate normally."));
        for(int i=0;i<mates.size() && i<SLOTS.length;i++) {
            ServerPlayer target=mates.get(i);
            put(SLOTS[i],icon(Items.PLAYER_HEAD,target.getName().getString(),"§aClick to spectate", "§7Team: "+BedWarsGameManager.label(BedWarsMod.GAME.teamOf(viewer))), (p,b,shift)->{
                if(!BedWarsMod.GAME.spectateTeammate(p,target.getUUID())) bar(p,"§cThat teammate is no longer available.");
                else { bar(p,"§aNow spectating "+target.getName().getString()); p.closeContainer(); }
            });
        }
        put(22,icon(Items.ENDER_EYE,"§eRefresh players","§7Update the teammate list."),(p,b,s)->refresh());
    }
}
