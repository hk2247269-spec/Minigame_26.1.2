package com.hanzala.bedwars.mixin;

import com.hanzala.bedwars.BedWarsMod;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ServerExplosion;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Iterator;
import java.util.List;

/**
 * Since Minecraft 1.21.2 explosions are computed by ServerExplosion. Just before blocks are destroyed we
 * strip protected original-map blocks from the list; team beds are the one exception (a destroyed bed
 * is an objective, but only while a match is running).
 */
@Mixin(ServerExplosion.class)
public abstract class ExplosionMixin {
    @Shadow @Final private ServerLevel level;

    @Inject(method = "interactWithBlocks", at = @At("HEAD"))
    private void bedwars$filterProtectedBlocks(List<BlockPos> blocks, CallbackInfo ci) {
        Iterator<BlockPos> it = blocks.iterator();
        while (it.hasNext()) {
            BlockPos pos = it.next();
            if (BedWarsMod.GAME.isRegisteredBed(level, pos)) {
                if (!BedWarsMod.GAME.isRunning()) it.remove();
                else BedWarsMod.GAME.destroyBed(level, pos, null);
                continue;
            }
            if (BedWarsMod.PROTECTION.shouldShieldFromExplosion(level, pos)) it.remove();
        }
    }
}
