package com.hanzala.bedwars.mixin;

import com.hanzala.bedwars.BedWarsMod;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Last-line guard for every block change (players, fire, fluids, pistons, falling blocks...) inside a
 * protected region while a match is running. It also records every block that appears during the match
 * so it can be removed again afterwards.
 */
@Mixin(Level.class)
public abstract class LevelMixin {
    @Shadow public abstract BlockState getBlockState(BlockPos pos);

    @Inject(method = "setBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;II)Z", at = @At("HEAD"), cancellable = true)
    private void bedwars$guardMapBlocks(BlockPos pos, BlockState newState, int flags, int recursionLeft, CallbackInfoReturnable<Boolean> cir) {
        // Floor Is Lava: lava that spreads by itself would leave the arena box and could never be restored (only near running lava arenas).
        if (newState.getFluidState().is(FluidTags.LAVA) && (Object) this instanceof ServerLevel lavaLevel
                && com.hanzala.minigames.FloorLavaSession.blocksFlow(lavaLevel, pos)) {
            cir.setReturnValue(false);
            return;
        }
        if (!BedWarsMod.GAME.isRunning()) return;
        if (!((Object) this instanceof ServerLevel level)) return;
        if (!BedWarsMod.PROTECTION.isProtected(level, pos)) return;
        if (BedWarsMod.GAME.isRegisteredBed(level, pos)) return;

        BlockState oldState = getBlockState(pos);
        if (oldState.isAir()) {
            if (!newState.isAir()) BedWarsMod.PROTECTION.markPlaced(level, pos.immutable());
            return;
        }
        if (BedWarsMod.PROTECTION.isPlayerPlaced(level, pos)) {
            if (newState.isAir()) BedWarsMod.PROTECTION.markBroken(level, pos);
            return;
        }
        // Original map block: allow state changes of the same block (doors, fluid levels), deny removal/replacement.
        if (newState.isAir() || oldState.getBlock() != newState.getBlock()) cir.setReturnValue(false);
    }
}
