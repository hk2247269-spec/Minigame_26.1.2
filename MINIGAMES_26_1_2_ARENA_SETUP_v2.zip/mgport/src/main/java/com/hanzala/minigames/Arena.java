package com.hanzala.minigames;

import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * One arena of one minigame (stored in config/minigames/arenas.json). An arena stores the identifier of the dimension it lives
 * in ({@link #dimension}) next to its boundary box, spawns, player limits and type-specific numbers ({@link #params}).
 * The boundary box is also the ONLY area a reset is ever allowed to touch, and it only ever applies to that dimension.
 *
 * All coordinates (box corners, spawns, waiting / spectator / finish spots) belong to {@link #dimension}. The wizard and the
 * commands refuse to mix dimensions inside one arena ({@link #bindDimension}).
 */
public final class Arena {
    public static final String OVERWORLD = "minecraft:overworld";

    public static final class Loc {
        public double x, y, z;
        public float yaw, pitch;

        public Loc() { }

        public static Loc of(ServerPlayer p) {
            Loc l = new Loc();
            l.x = p.getX(); l.y = p.getY(); l.z = p.getZ(); l.yaw = p.getYRot(); l.pitch = p.getXRot();
            return l;
        }
    }

    public String id;
    /** {@link MinigameType#id} */
    public String type;
    public String name;
    /**
     * Dimension identifier (e.g. minecraft:overworld, minecraft:the_nether or a datapack dimension). Arenas written by older
     * versions have no such field and are migrated to the Overworld, where they always lived.
     */
    public String dimension = OVERWORLD;
    /** Only enabled arenas can be joined. Old arenas (no field in the file) stay enabled; new ones start disabled until validated. */
    public boolean enabled = true;
    public boolean hasBox;
    public int x1, y1, z1, x2, y2, z2;
    public boolean hasPos1, hasPos2;
    /** Where players wait before the match (falls back to the first spawn). */
    public Loc waiting;
    public Loc spectator;
    /** Red Light Green Light only: the finish line (also where the statue stands). See RedGreenSession for the convention. */
    public Loc finish;
    public List<Loc> spawns = new ArrayList<>();
    public int minPlayers = 2;
    public int maxPlayers = 16;
    /** Type-specific numbers, e.g. tnt: delay (ticks); lava: startY, riseSeconds; rg: see the handoff document. */
    public Map<String, Double> params = new LinkedHashMap<>();

    public MinigameType type() { return MinigameType.byId(type); }

    public String displayName() { return name != null && !name.isBlank() ? name : id; }

    /** The dimension id, never null / blank. */
    public String dim() { return dimension == null || dimension.isBlank() ? OVERWORLD : dimension; }

    public double param(String key, double def) {
        Double v = params.get(key);
        return v == null ? def : v;
    }

    public int minX() { return Math.min(x1, x2); }
    public int maxX() { return Math.max(x1, x2); }
    public int minY() { return Math.min(y1, y2); }
    public int maxY() { return Math.max(y1, y2); }
    public int minZ() { return Math.min(z1, z2); }
    public int maxZ() { return Math.max(z1, z2); }

    /** Both corners are known. */
    public void updateBox() { hasBox = hasPos1 && hasPos2; }

    public boolean contains(double x, double y, double z) {
        return hasBox && x >= minX() && x < maxX() + 1 && y >= minY() && y < maxY() + 1 && z >= minZ() && z < maxZ() + 1;
    }

    public boolean containsXZ(double x, double z) {
        return hasBox && x >= minX() && x < maxX() + 1 && z >= minZ() && z < maxZ() + 1;
    }

    /** True when both arenas are in the same dimension and their boxes intersect. Boxes in different dimensions never overlap. */
    public boolean overlaps(Arena o) {
        if (!hasBox || !o.hasBox) return false;
        if (!dim().equals(o.dim())) return false;
        return minX() <= o.maxX() && maxX() >= o.minX()
                && minY() <= o.maxY() && maxY() >= o.minY()
                && minZ() <= o.maxZ() && maxZ() >= o.minZ();
    }

    public Loc waitingSpot() { return waiting != null ? waiting : (spawns.isEmpty() ? null : spawns.get(0)); }

    public Loc spectatorSpot() {
        if (spectator != null) return spectator;
        Loc l = new Loc();
        l.x = (minX() + maxX() + 1) / 2.0;
        l.z = (minZ() + maxZ() + 1) / 2.0;
        l.y = maxY() + 3;
        return l;
    }

    /** True once any box corner or spot has been stored (then the arena is pinned to its dimension). */
    public boolean hasAnyLocation() {
        return hasPos1 || hasPos2 || waiting != null || spectator != null || finish != null || !spawns.isEmpty();
    }

    /**
     * Called before a location is stored: pins an empty arena to the dimension the admin is standing in, and refuses to mix
     * dimensions otherwise. Returns an error text or null.
     */
    public String bindDimension(String playerDimension) {
        if (playerDimension == null) return null;
        if (playerDimension.equals(dim())) return null;
        if (!hasAnyLocation()) { dimension = playerDimension; return null; }
        return "This arena is in " + dim() + " but you are in " + playerDimension + ". Go to " + dim()
                + ", or clear the arena's locations first to move it to another dimension.";
    }

    /** Forgets the box and every spot (settings, name and players limits stay). The arena becomes disabled. */
    public void clearLocations() {
        hasPos1 = hasPos2 = hasBox = false;
        x1 = y1 = z1 = x2 = y2 = z2 = 0;
        waiting = null;
        spectator = null;
        finish = null;
        spawns.clear();
        enabled = false;
    }

    /** What is still missing for this arena to be playable (errors of {@link ArenaValidator} only), or null when it is ready. */
    public String missing() {
        List<String> m = new ArrayList<>();
        for (ArenaValidator.Issue i : ArenaValidator.checkArena(this)) if (i.isError()) m.add(i.message());
        return m.isEmpty() ? null : String.join(", ", m);
    }
}
