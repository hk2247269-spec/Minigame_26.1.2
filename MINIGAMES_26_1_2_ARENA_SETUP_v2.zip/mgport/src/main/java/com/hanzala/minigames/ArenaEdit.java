package com.hanzala.minigames;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;

/**
 * Every edit an administrator can make to an arena, in ONE place. The setup wizard (GUI) and the /mg arena commands both call
 * these methods, so both obey the same rules: no edits while a game uses the arena, one dimension per arena, values stay in
 * a sane range, and everything is saved right away. Each method returns an error text or null on success.
 */
public final class ArenaEdit {
    private ArenaEdit() { }

    /** A number a game can be tuned with. {@code def} is used when the arena has not set it; null means "bottom of the box". */
    public record Param(String key, String label, String help, Double def, double step, double min, double max) {
        public double defaultFor(Arena a) { return def != null ? def : a.minY(); }
        public double current(Arena a) { return a.param(key, defaultFor(a)); }
    }

    private static final List<Param> TNT = List.of(
            new Param("delay", "Block vanish delay", "Ticks until a block you stood on disappears (20 ticks = 1 s).", 12.0, 1, 11, 40));
    private static final List<Param> LAVA = List.of(
            new Param("startY", "Lava start height", "Y level of the first lava layer. Default: bottom of the box.", null, 1, -64, 320),
            new Param("riseSeconds", "Seconds per lava layer", "How long the lava waits before rising one more layer.", 8.0, 1, 1, 60),
            new Param("warmup", "Warm-up seconds", "Time before the lava starts to rise.", 20.0, 5, 0, 300));
    private static final List<Param> RG = List.of(
            new Param("greenMin", "Green light, shortest", "Shortest green phase in seconds.", 3.0, 1, 1, 30),
            new Param("greenMax", "Green light, longest", "Longest green phase in seconds.", 7.0, 1, 1, 30),
            new Param("redMin", "Red light, shortest", "Shortest red phase in seconds.", 2.0, 1, 1, 30),
            new Param("redMax", "Red light, longest", "Longest red phase in seconds.", 5.0, 1, 1, 30),
            new Param("redGrace", "Red light grace", "Ticks after red starts before moving is punished (20 ticks = 1 s).", 10.0, 5, 0, 60),
            new Param("timeLimit", "Match time limit", "Seconds until the match ends.", 900.0, 60, 60, 3600));

    /** The game-specific numbers of a game (empty for games without any). */
    public static List<Param> paramsOf(MinigameType t) {
        if (t == null) return List.of();
        return switch (t) {
            case TNT_RUN -> TNT;
            case FLOOR_LAVA -> LAVA;
            case RED_GREEN -> RG;
            default -> List.of();
        };
    }

    // ------------------------------------------------------------------ guards

    private static String busy(Arena a) {
        return Mg.canEdit(a) ? null : "A game is using this arena right now. Stop it first (/mg stop).";
    }

    /** Busy check + "one dimension per arena" check for everything that stores a position. */
    private static String beforeLocation(Arena a, ServerPlayer p) {
        String b = busy(a);
        if (b != null) return b;
        return a.bindDimension(MgUtil.dimId(p));
    }

    /** An arena with a leftover reset journal (crash while its dimension was missing) is restored first, so no block stays changed. */
    private static String unfinishedReset(Arena a) {
        if (!BlockJournal.existsOnDisk(a)) return null;
        String r = Mg.restoreLeftovers(a);
        return r == null ? null : "This arena still has an unfinished reset (" + r + ") Fix that first; /mg arena reset " + a.id + " retries it.";
    }

    // ------------------------------------------------------------------ locations

    public static String corner(Arena a, ServerPlayer p, boolean first) {
        String e = beforeLocation(a, p);
        if (e != null) return e;
        BlockPos b = p.blockPosition();
        if (first) { a.x1 = b.getX(); a.y1 = b.getY(); a.z1 = b.getZ(); a.hasPos1 = true; }
        else { a.x2 = b.getX(); a.y2 = b.getY(); a.z2 = b.getZ(); a.hasPos2 = true; }
        a.updateBox();
        ArenaManager.save();
        return null;
    }

    public static String addSpawn(Arena a, ServerPlayer p) {
        String e = beforeLocation(a, p);
        if (e != null) return e;
        if (a.spawns.size() >= 64) return "An arena can have at most 64 spawns.";
        a.spawns.add(Arena.Loc.of(p));
        ArenaManager.save();
        return null;
    }

    public static String clearSpawns(Arena a) {
        String e = busy(a);
        if (e != null) return e;
        a.spawns.clear();
        ArenaManager.save();
        return null;
    }

    public static String setWaiting(Arena a, ServerPlayer p) {
        String e = beforeLocation(a, p);
        if (e != null) return e;
        a.waiting = Arena.Loc.of(p);
        ArenaManager.save();
        return null;
    }

    public static String setSpectator(Arena a, ServerPlayer p) {
        String e = beforeLocation(a, p);
        if (e != null) return e;
        a.spectator = Arena.Loc.of(p);
        ArenaManager.save();
        return null;
    }

    public static String setFinish(Arena a, ServerPlayer p) {
        String e = beforeLocation(a, p);
        if (e != null) return e;
        a.finish = Arena.Loc.of(p);
        ArenaManager.save();
        return null;
    }

    /** Forgets the box and all spots so the arena can be rebuilt anywhere (also in another dimension). Disables the arena. */
    public static String clearLocations(Arena a) {
        String e = busy(a);
        if (e != null) return e;
        e = unfinishedReset(a);
        if (e != null) return e;
        a.clearLocations();
        ArenaManager.save();
        return null;
    }

    // ------------------------------------------------------------------ numbers

    public static String setMin(Arena a, int n) {
        String e = busy(a);
        if (e != null) return e;
        a.minPlayers = Math.max(2, Math.min(100, n));
        if (a.maxPlayers < a.minPlayers) a.maxPlayers = a.minPlayers;
        ArenaManager.save();
        return null;
    }

    public static String setMax(Arena a, int n) {
        String e = busy(a);
        if (e != null) return e;
        a.maxPlayers = Math.max(2, Math.min(100, n));
        if (a.minPlayers > a.maxPlayers) a.minPlayers = a.maxPlayers;
        ArenaManager.save();
        return null;
    }

    /** Sets a game number, clamped to the range of its {@link Param}. Unknown keys are accepted as-is (old behaviour of /mg arena set). */
    public static String setParam(Arena a, String key, double value) {
        String e = busy(a);
        if (e != null) return e;
        double v = value;
        for (Param p : paramsOf(a.type())) if (p.key().equals(key)) v = Math.max(p.min(), Math.min(p.max(), value));
        a.params.put(key, v);
        ArenaManager.save();
        return null;
    }

    /** Wizard buttons: +step / -step. */
    public static String nudge(Arena a, Param p, int direction) {
        return setParam(a, p.key(), p.current(a) + direction * p.step());
    }

    public static String rename(Arena a, String text) {
        String e = busy(a);
        if (e != null) return e;
        String t = text == null ? "" : text.trim();
        if (t.isEmpty() || t.length() > 40) return "The name must be 1-40 characters.";
        a.name = t;
        ArenaManager.save();
        return null;
    }

    // ------------------------------------------------------------------ enable / disable / delete

    /** Validates and enables. Refuses (with the list of errors) when the arena is not valid. */
    public static String enable(Arena a) {
        String e = busy(a);
        if (e != null) return e;
        String problem = ArenaManager.enableProblem(a);
        if (problem != null) return "Cannot enable yet: " + problem + ". Use 'Check arena' to see how to fix each problem.";
        a.enabled = true;
        ArenaManager.save();
        return null;
    }

    public static String disable(Arena a) {
        String e = busy(a);
        if (e != null) return e;
        a.enabled = false;
        ArenaManager.save();
        return null;
    }

    /** Removes the arena from arenas.json. No block in the world is touched. */
    public static String delete(Arena a) {
        String e = busy(a);
        if (e != null) return e;
        e = unfinishedReset(a);
        if (e != null) return e;
        Mg.forgetSession(a);
        ArenaManager.remove(a.id);
        return null;
    }

    // ------------------------------------------------------------------ reports

    /** Sends the full validation report of an arena to a player / console as chat lines. */
    public static void report(net.minecraft.commands.CommandSourceStack src, Arena a) {
        List<ArenaValidator.Issue> issues = ArenaManager.validate(a);
        send(src, "§6§l" + a.displayName() + " §7(" + a.id + ", " + a.dim() + ") - " + (a.enabled ? "§aenabled" : "§cdisabled"));
        if (issues.isEmpty()) send(src, "§a✔ Everything is set up.");
        for (ArenaValidator.Issue i : issues) send(src, i.line());
        if (!ArenaValidator.hasErrors(issues))
            send(src, a.enabled ? "§aThis arena is ready to play." : "§aNo errors - you can enable this arena now.");
    }

    private static void send(net.minecraft.commands.CommandSourceStack src, String text) {
        src.sendSuccess(() -> net.minecraft.network.chat.Component.literal(text), false);
    }
}
