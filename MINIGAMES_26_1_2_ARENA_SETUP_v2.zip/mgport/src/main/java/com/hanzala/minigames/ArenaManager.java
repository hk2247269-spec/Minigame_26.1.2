package com.hanzala.minigames;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Keeps the arenas in memory and answers "which arenas exist for this game". Arena ids are unique across all games.
 * Persistence and migration live in {@link ArenaStorage}, the rules in {@link ArenaValidator}.
 *
 * "One arena per game" is the default: the setup wizard creates the arena of a game with the game's own id (tnt, lava, rg) and
 * calls it e.g. "TNT Run Arena". More arenas of the same game are optional ({@link #createExtra}).
 */
public final class ArenaManager {
    private ArenaManager() { }

    private static final Map<String, Arena> ARENAS = new LinkedHashMap<>();

    private static Path file() { return MgSettings.dir().resolve("arenas.json"); }

    public static void load() {
        ARENAS.clear();
        ArenaStorage.LoadResult r = ArenaStorage.load(file(), MgMod.LOG::warn);
        for (Arena a : r.arenas()) ARENAS.put(a.id.toLowerCase(), a);
        if (r.failed()) MgMod.LOG.error("arenas.json could not be read. A copy was kept next to it (arenas.json.corrupt-*). No arena was loaded.");
        if (r.migrated() || !java.nio.file.Files.exists(file())) save();
    }

    public static void save() { ArenaStorage.save(file(), new ArrayList<>(ARENAS.values()), MgMod.LOG::error); }

    public static Arena get(String id) { return id == null ? null : ARENAS.get(id.toLowerCase()); }

    public static List<Arena> all() { return new ArrayList<>(ARENAS.values()); }

    public static List<Arena> of(MinigameType t) {
        List<Arena> out = new ArrayList<>();
        for (Arena a : ARENAS.values()) if (t.id.equals(a.type)) out.add(a);
        out.sort(Comparator.comparing(a -> a.id));
        return out;
    }

    /** The arena the wizard edits by default: the first arena of that game, or null when the game has none yet. */
    public static Arena defaultFor(MinigameType t) {
        List<Arena> l = of(t);
        return l.isEmpty() ? null : l.get(0);
    }

    /** Returns an error text or null. New arenas start DISABLED until they pass validation and are enabled. */
    public static String create(MinigameType t, String id) {
        if (t.external) return t.display + " has its own arena setup (see its own commands).";
        if (!id.matches("[A-Za-z0-9_\\-]{1,24}")) return "Arena id: 1-24 letters, digits, _ or -.";
        if (ARENAS.containsKey(id.toLowerCase())) return "An arena with that id already exists.";
        Arena a = new Arena();
        a.id = id;
        a.type = t.id;
        a.name = id;
        a.enabled = false;
        ARENAS.put(id.toLowerCase(), a);
        save();
        return null;
    }

    /** Wizard: the one default arena of a game (id = game id, name "<Game> Arena"). Returns the existing arena when there is one. */
    public static Arena createDefault(MinigameType t) {
        Arena existing = defaultFor(t);
        if (existing != null) return existing;
        String id = t.id;
        if (create(t, id) != null) return null;
        Arena a = get(id);
        a.name = t.display + " Arena";
        save();
        return a;
    }

    /** Optional extra arena of a game: ids tnt2, tnt3, ... Returns null when the game cannot have arenas. */
    public static Arena createExtra(MinigameType t) {
        if (t.external) return null;
        int n = 2;
        while (ARENAS.containsKey((t.id + n).toLowerCase())) n++;
        String id = t.id + n;
        if (create(t, id) != null) return null;
        Arena a = get(id);
        a.name = t.display + " Arena " + n;
        save();
        return a;
    }

    public static boolean remove(String id) {
        boolean r = ARENAS.remove(id.toLowerCase()) != null;
        if (r) save();
        return r;
    }

    // ------------------------------------------------------------------ validation

    private static ArenaValidator.LobbyPoint lobby() {
        double[] c = com.hanzala.bedwars.BedWarsMod.GAME.lobbyCoords();
        if (c == null) return null;
        return new ArenaValidator.LobbyPoint(com.hanzala.bedwars.BedWarsMod.GAME.lobbyDimension(), c[0], c[1], c[2]);
    }

    /** Every error and warning of an arena, with fixes. Includes the dimension, overlap and lobby checks. */
    public static List<ArenaValidator.Issue> validate(Arena a) {
        return ArenaValidator.validate(a, ARENAS.values(), lobby(), Mg::dimensionLoaded);
    }

    /**
     * Can this arena be enabled? Returns null when there is no error (warnings do not block), otherwise a one-line summary
     * of every error.
     */
    public static String enableProblem(Arena a) {
        List<String> errs = new ArrayList<>();
        for (ArenaValidator.Issue i : validate(a)) if (i.isError()) errs.add(i.message());
        return errs.isEmpty() ? null : String.join("; ", errs);
    }

    /** Safety check run before an arena is used: enabled, valid, not overlapping another arena, not covering the lobby. Null = safe. */
    public static String problem(Arena a) {
        String e = enableProblem(a);
        if (e != null) return "not set up yet - " + e;
        if (!a.enabled) return "disabled - an admin must enable it (/mg setup)";
        return null;
    }
}
