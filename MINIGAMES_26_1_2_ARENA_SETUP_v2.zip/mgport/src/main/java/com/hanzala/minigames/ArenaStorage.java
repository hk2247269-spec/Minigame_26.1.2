package com.hanzala.minigames;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

/**
 * Reads and writes arenas.json safely. Pure Java + Gson (no Minecraft classes) so it can be tested without a server.
 *
 * <ul>
 *   <li>Saving writes a temp file, keeps the previous file as arenas.json.bak and then moves the new file into place, so a
 *       crash in the middle of a save can never leave a half-written file.</li>
 *   <li>Loading an old file (schema 1, no "schemaVersion") first copies it to arenas.json.v1.bak, then migrates it: every arena
 *       keeps all of its data, gets the Overworld as dimension and stays enabled.</li>
 *   <li>A file that cannot be parsed is never overwritten silently: the backup is tried, and the broken file is copied to
 *       arenas.json.corrupt-&lt;time&gt; first.</li>
 * </ul>
 */
public final class ArenaStorage {
    private ArenaStorage() { }

    public static final int SCHEMA = 2;

    private static final class Data {
        /** 0 = the field is missing = a file written before schema 2. */
        int schemaVersion = 0;
        List<Arena> arenas = new ArrayList<>();
    }

    /** @param migrated the file was older than {@link #SCHEMA} (caller should save)  @param failed nothing usable could be read */
    public record LoadResult(List<Arena> arenas, boolean migrated, boolean failed) { }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static LoadResult load(Path file, Consumer<String> log) {
        if (!Files.exists(file)) return new LoadResult(new ArrayList<>(), false, false);
        Data d;
        try {
            d = parse(Files.readString(file));
        } catch (Exception e) {
            log.accept("Could not read " + file.getFileName() + ": " + e);
            copyAside(file, "corrupt-" + System.currentTimeMillis(), log);
            Path bak = sibling(file, ".bak");
            try {
                d = Files.exists(bak) ? parse(Files.readString(bak)) : null;
                if (d != null) log.accept("Loaded the last good copy " + bak.getFileName() + " instead.");
            } catch (Exception e2) {
                d = null;
            }
            if (d == null) return new LoadResult(new ArrayList<>(), false, true);
            return finish(d, file, true, log);
        }
        boolean migrated = d.schemaVersion < SCHEMA;
        if (migrated) {
            Path v1 = sibling(file, ".v" + Math.max(1, d.schemaVersion) + ".bak");
            if (!Files.exists(v1)) copyAside(file, null, log, v1);
            log.accept("Migrating " + file.getFileName() + " from schema " + d.schemaVersion + " to " + SCHEMA + " (backup: " + v1.getFileName() + ").");
        } else if (d.schemaVersion > SCHEMA) {
            log.accept(file.getFileName() + " was written by a newer version (schema " + d.schemaVersion + "). Unknown fields are kept out of memory; saving will not remove your backup.");
        }
        return finish(d, file, migrated, log);
    }

    private static Data parse(String text) {
        Data d = GSON.fromJson(text, Data.class);
        if (d == null) throw new IllegalStateException("file is empty");
        if (d.arenas == null) d.arenas = new ArrayList<>();
        return d;
    }

    private static LoadResult finish(Data d, Path file, boolean migrated, Consumer<String> log) {
        List<Arena> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (Arena a : d.arenas) {
            if (a == null) continue;
            if (a.id == null || a.id.isBlank()) {
                a.id = (a.type == null ? "arena" : a.type) + "_recovered" + (out.size() + 1);
                log.accept("An arena without an id was kept as '" + a.id + "'.");
                migrated = true;
            }
            String key = a.id.toLowerCase();
            if (!seen.add(key)) {
                String old = a.id;
                int n = 2;
                while (!seen.add((old + "_" + n).toLowerCase())) n++;
                a.id = old + "_" + n;
                log.accept("Duplicate arena id '" + old + "' was kept as '" + a.id + "'.");
                migrated = true;
            }
            sanitize(a);
            out.add(a);
        }
        return new LoadResult(out, migrated, false);
    }

    /** Repairs missing collections and impossible numbers without dropping any data. */
    static void sanitize(Arena a) {
        if (a.dimension == null || a.dimension.isBlank()) a.dimension = Arena.OVERWORLD;
        if (a.spawns == null) a.spawns = new ArrayList<>();
        a.spawns.removeIf(s -> s == null);
        if (a.params == null) a.params = new LinkedHashMap<>();
        a.updateBox();
        if (a.minPlayers < 2) a.minPlayers = 2;
        if (a.maxPlayers < a.minPlayers) a.maxPlayers = a.minPlayers;
    }

    /** Atomic save. Returns false (and logs) when it failed; the old file is then still intact. */
    public static boolean save(Path file, List<Arena> arenas, Consumer<String> log) {
        try {
            Data d = new Data();
            d.schemaVersion = SCHEMA;
            d.arenas.addAll(arenas);
            Path tmp = sibling(file, ".tmp");
            Files.writeString(tmp, GSON.toJson(d));
            if (Files.exists(file)) Files.copy(file, sibling(file, ".bak"), StandardCopyOption.REPLACE_EXISTING);
            try {
                Files.move(tmp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (Exception e) {
            log.accept("Could not save " + file.getFileName() + ": " + e);
            return false;
        }
    }

    private static Path sibling(Path file, String suffix) { return file.resolveSibling(file.getFileName() + suffix); }

    private static void copyAside(Path file, String suffix, Consumer<String> log) { copyAside(file, suffix, log, sibling(file, "." + suffix)); }

    private static void copyAside(Path file, String ignored, Consumer<String> log, Path target) {
        try {
            Files.copy(file, target, StandardCopyOption.REPLACE_EXISTING);
            log.accept("Copied " + file.getFileName() + " to " + target.getFileName() + ".");
        } catch (Exception e) {
            log.accept("Could not back up " + file.getFileName() + ": " + e);
        }
    }
}
