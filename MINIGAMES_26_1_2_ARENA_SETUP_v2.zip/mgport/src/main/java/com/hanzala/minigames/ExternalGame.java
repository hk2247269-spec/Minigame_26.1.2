package com.hanzala.minigames;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/**
 * Adapter between the central /mg system and a game that keeps its own engine (BedWars, Hide &amp; Seek).
 * Implement it and register it with {@link Mg#registerExternal} from MgMod.
 */
public interface ExternalGame {
    MinigameType type();

    /** True while this player takes part in the game (waiting room included). Used to stop a player being in two games. */
    boolean isInGame(ServerPlayer p);

    /** Current status for the GUI. */
    Mg.Status status(MinecraftServer server);

    /** Normal join from the GUI. Returns an error text or null. */
    String join(ServerPlayer p);

    /** Leave the game (restore + common lobby). Returns false when the player was not in it. */
    boolean leave(ServerPlayer p);

    /** "/mg xx force": move every online player into the game and start it. Returns an error text or null. */
    String forceAll(MinecraftServer server, CommandSourceStack by);

    /** "/mg xx force &lt;player&gt;": move only that player. Returns an error text or null. */
    String forcePlayer(MinecraftServer server, ServerPlayer target);

    /** Safely end the game if one is running: everybody restored and back in the common lobby, arena reset. */
    void forceStop(MinecraftServer server);
}
