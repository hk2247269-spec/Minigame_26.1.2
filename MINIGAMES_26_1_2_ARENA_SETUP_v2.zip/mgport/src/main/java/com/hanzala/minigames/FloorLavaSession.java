package com.hanzala.minigames;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Floor Is Lava. The admin builds platforms / structures inside the arena box. After a warm-up, lava rises one layer at a time
 * from {@code startY}. Lava only replaces air / replaceable blocks and only inside the box. A player who touches lava, leaves the
 * box or falls out of it is eliminated (players are invulnerable, so elimination is the rule). Last player alive wins.
 *
 * Arena numbers (/mg arena set &lt;id&gt; &lt;key&gt; &lt;value&gt;):
 * startY (first lava layer, default = bottom of the box), riseSeconds (seconds per +1 layer, default 8), warmup (seconds before
 * the first layer, default 20).
 *
 * Every block that lava replaces is recorded in a {@link BlockJournal} BEFORE it changes, so the arena is restored after every
 * match, after /mg stop and after a crash.
 */
public final class FloorLavaSession extends GameSession {
    private static final int BLOCKS_PER_TICK = 400;

    private final BlockJournal journal;
    private final BlockPos.MutableBlockPos scratch = new BlockPos.MutableBlockPos();

    /** Highest layer whose fill has been started (-1 sentinel handled by {@link #fillActive}). */
    /** Sessions whose lava is on the map. While any exists, lava the session did not place itself cannot spread (see LevelMixin). */
    private static final Set<FloorLavaSession> LIVE = new HashSet<>();
    /** True only while this class itself is placing / restoring blocks. */
    private static boolean placing;

    /**
     * Called by LevelMixin: true when a lava block change must be refused. Only lava that would appear inside (or within 2 blocks
     * of) the box of a running Floor Is Lava arena, in that arena's own dimension, is refused - natural lava anywhere else in the
     * world, and in other arenas, behaves normally.
     */
    public static boolean blocksFlow(net.minecraft.server.level.ServerLevel lvl, BlockPos pos) {
        if (placing || LIVE.isEmpty()) return false;
        for (FloorLavaSession s : LIVE) {
            if (s.level != lvl) continue;
            Arena a = s.arena;
            if (pos.getX() >= a.minX() - 2 && pos.getX() <= a.maxX() + 2
                    && pos.getY() >= a.minY() - 2 && pos.getY() <= a.maxY() + 2
                    && pos.getZ() >= a.minZ() - 2 && pos.getZ() <= a.maxZ() + 2) return true;
        }
        return false;
    }

    private int lavaY;
    private int nextRiseTick;
    private boolean fillActive;
    private int fillX, fillZ;

    public FloorLavaSession(MinecraftServer server, Arena arena) {
        super(server, arena, MinigameType.FLOOR_LAVA);
        this.journal = new BlockJournal(arena);
    }

    private int startY() { return (int) Math.max(arena.minY(), Math.min(arena.maxY(), arena.param("startY", arena.minY()))); }
    private int riseTicks() { return (int) Math.max(1, arena.param("riseSeconds", 8)) * 20; }
    private int warmupTicks() { return (int) Math.max(0, arena.param("warmup", 20)) * 20; }

    @Override
    protected void onPrepare() {
        lavaY = startY() - 1;
        fillActive = false;
        nextRiseTick = warmupTicks();
        LIVE.add(this);
    }

    @Override
    protected void onStart() {
        // warm-up: nothing rises until matchTicks reaches warmup
    }

    @Override
    protected void tickActive() {
        // 1) rise
        if (!fillActive && matchTicks >= nextRiseTick && lavaY < arena.maxY()) {
            nextRiseTick = matchTicks + riseTicks();
            lavaY++;
            fillActive = true;
            fillX = arena.minX();
            fillZ = arena.minZ();
            for (ServerPlayer p : online(players)) {
                MgUtil.bar(p, "§c§lThe lava rises! §7Now at Y " + lavaY);
                MgUtil.snd(p, SoundEvents.LAVA_AMBIENT, 1f, 0.8f);
            }
        }
        if (fillActive) fillSome();

        // 2) players
        for (ServerPlayer p : online(alive)) { // copy: eliminate() edits the set
            if (!alive.contains(p.getUUID())) continue;
            double x = p.getX(), y = p.getY(), z = p.getZ();
            if (!arena.containsXZ(x, z) || y < arena.minY() - 5 || y >= arena.maxY() + 4) {
                eliminate(p, "left the arena");
                continue;
            }
            if (inLava(x, y + 0.05, z) || inLava(x, y + 0.5, z)) eliminate(p, "touched the lava");
        }

        if (matchTicks % 10 == 0) journal.flush();
    }

    private boolean inLava(double x, double y, double z) {
        if (!arena.contains(x, y, z)) return false;
        scratch.set((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
        BlockState st = level.getBlockState(scratch);
        return st.is(Blocks.LAVA) || st.getFluidState().is(FluidTags.LAVA);
    }

    /** Fills the current layer in slices of BLOCKS_PER_TICK cells. */
    private void fillSome() {
        int budget = BLOCKS_PER_TICK;
        BlockState lava = Blocks.LAVA.defaultBlockState();
        placing = true;
        try {
        while (budget > 0 && fillActive) {
            budget--;
            scratch.set(fillX, lavaY, fillZ);
            BlockState st = level.getBlockState(scratch);
            if (!st.is(Blocks.LAVA) && (st.isAir() || st.canBeReplaced())) {
                BlockPos pos = scratch.immutable();
                if (journal.capture(level, pos)) level.setBlock(pos, lava, 2);
            }
            if (++fillZ > arena.maxZ()) {
                fillZ = arena.minZ();
                if (++fillX > arena.maxX()) fillActive = false;
            }
        }
        } finally { placing = false; }
        journal.flush(); // the original blocks are on disk right after they are replaced
    }

    @Override
    protected List<String> activeLines(ServerPlayer p) {
        int untilRise = warmupTicks() - matchTicks;
        if (untilRise > 0) return List.of("§7Lava starts in §f" + (untilRise + 19) / 20 + "s");
        int next = Math.max(0, nextRiseTick - matchTicks);
        return List.of("§7Lava height: §cY " + Math.max(lavaY, startY() - 1), "§7Next rise: §f" + (next + 19) / 20 + "s");
    }

    @Override
    protected void onMatchOver() {
        fillActive = false;
        journal.flush();
    }

    @Override
    protected boolean resetStep() {
        fillActive = false;
        placing = true; // the restore may put lava back where it was originally; that must not be refused
        try {
            boolean done = journal.restoreSome(level, MgSettings.I.resetBlocksPerTick);
            if (done) LIVE.remove(this);
            return done;
        } finally { placing = false; }
    }

    @Override
    public void flushToDisk() { journal.flush(); LIVE.remove(this); }
}
