package com.hanzala.minigames;

import net.hanzala.hideseek.Cfg;
import net.hanzala.hideseek.Game;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;

/**
 * Plugs the Hide &amp; Seek engine ({@link Game}) into /mg. The engine keeps all its gameplay (disguises, abilities, stats,
 * hiders / seekers, its own sidebar); it now runs in the Overworld and returns players to the common lobby.
 */
public final class HideSeekAdapter implements ExternalGame {
    @Override
    public MinigameType type() { return MinigameType.HIDESEEK; }

    @Override
    public boolean isInGame(ServerPlayer p) { return Game.inGame(p); }

    @Override
    public Mg.Status status(MinecraftServer server) {
        Game g = Game.current;
        if (g == null) {
            Cfg.ArenaCfg a = Cfg.pickArena();
            if (a == null) return new Mg.Status("§8No arena", 0, 0, "-", false, "No Hide & Seek arena has been set up yet (/hs setup).");
            return new Mg.Status("§aWaiting", 0, Cfg.game.maxPlayers, a.name, true, null);
        }
        String label = switch (g.state) {
            case WAITING -> "§aWaiting";
            case COUNTDOWN -> "§eStarting soon";
            case HIDING -> "§cHiding phase";
            case SEEKING -> "§cRunning";
            case ENDED -> "§7Match over";
        };
        boolean joinable = g.joinable();
        return new Mg.Status(label, g.playerCount(), Cfg.game.maxPlayers, g.arenaName(), joinable,
                joinable ? null : (g.playerCount() >= Cfg.game.maxPlayers && (g.state == Game.State.WAITING || g.state == Game.State.COUNTDOWN)
                        ? "The game is full." : "A match is already in progress."));
    }

    @Override
    public String join(ServerPlayer p) { return Game.join(p); }

    @Override
    public boolean leave(ServerPlayer p) {
        if (!Game.inGame(p)) return false;
        Game.leave(p); // restores the player and sends them to the common lobby
        return true;
    }

    @Override
    public String forceAll(MinecraftServer server, CommandSourceStack by) {
        if (Cfg.pickArena() == null) return "No Hide & Seek arena has been set up yet (/hs setup).";
        int joined = 0;
        List<String> errors = new ArrayList<>();
        for (ServerPlayer p : new ArrayList<>(server.getPlayerList().getPlayers())) {
            if (joined >= Cfg.game.maxPlayers) {
                p.sendSystemMessage(MgUtil.msg("§cHide & Seek is full (" + Cfg.game.maxPlayers + " players) - you stay in the lobby."));
                continue;
            }
            String err = Game.join(p);
            if (err == null) joined++;
            else errors.add(p.getName().getString() + ": " + err);
        }
        if (joined < 2) {
            Game.shutdown("not enough players.");
            return "Hide & Seek needs at least 2 players (joined: " + joined + ")." + (errors.isEmpty() ? "" : " " + errors.get(0));
        }
        if (Game.current == null || !Game.current.forceStart(2)) {
            Game.shutdown("could not start.");
            return "Hide & Seek could not be started (a match may already be running).";
        }
        return null;
    }

    @Override
    public String forcePlayer(MinecraftServer server, ServerPlayer target) { return Game.join(target); }

    @Override
    public void forceStop(MinecraftServer server) { Game.shutdown("stopped by an admin."); }
}
