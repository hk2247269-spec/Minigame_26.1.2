package com.hanzala.minigames;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.BiFunction;

/**
 * The central manager: owns every {@link GameSession}, knows which player is in which game (a player can only ever be in
 * ONE game), and implements joining, leaving and the admin force logic for all five minigames.
 */
public final class Mg {
    private Mg() { }

    /** What the GUI shows for one minigame. */
    public record Status(String label, int players, int capacity, String arenaName, boolean joinable, String reason) { }

    private static MinecraftServer server;
    private static final Map<String, GameSession> SESSIONS = new LinkedHashMap<>();   // arena id -> session
    private static final Map<UUID, GameSession> BY_PLAYER = new HashMap<>();
    private static final Map<MinigameType, BiFunction<MinecraftServer, Arena, GameSession>> FACTORIES = new EnumMap<>(MinigameType.class);
    private static final Map<MinigameType, ExternalGame> EXTERNAL = new EnumMap<>(MinigameType.class);

    static {
        FACTORIES.put(MinigameType.TNT_RUN, TntRunSession::new);
        FACTORIES.put(MinigameType.FLOOR_LAVA, FloorLavaSession::new);
        FACTORIES.put(MinigameType.RED_GREEN, RedGreenSession::new);
    }

    public static void registerExternal(ExternalGame game) { EXTERNAL.put(game.type(), game); }

    public static boolean isAvailable(MinigameType t) { return t.external ? EXTERNAL.containsKey(t) : FACTORIES.containsKey(t); }

    // ------------------------------------------------------------------ lifecycle

    public static void init(MinecraftServer s) {
        server = s;
        MgSettings.load();
        ArenaManager.load();
        recoverJournals();
    }

    /** Puts back every block a crashed match changed (the journals are written while a match is running). */
    private static void recoverJournals() {
        for (Arena a : ArenaManager.all()) {
            if (!BlockJournal.existsOnDisk(a)) continue;
            ServerLevel lvl = levelOf(server, a);
            if (lvl == null) {
                MgMod.LOG.warn("Arena '{}' has an unfinished reset journal but its dimension '{}' is not loaded. The journal is kept and will be applied once the dimension exists.", a.id, a.dim());
                continue;
            }
            BlockJournal j = new BlockJournal(a);
            j.loadFromDisk();
            j.restoreAll(lvl);
            MgMod.LOG.info("Restored arena '{}' after an interrupted match.", a.id);
        }
    }

    public static void shutdown() {
        for (GameSession s : new ArrayList<>(SESSIONS.values())) {
            try { s.abortAndResetNow("The server is stopping."); } catch (Exception e) { MgMod.LOG.error("shutdown " + s.arena.id, e); }
        }
        SESSIONS.clear();
        BY_PLAYER.clear();
        MgBoard.clearAll();
        server = null;
    }

    public static void reload() {
        // only the arena-based minigames are stopped; BedWars / Hide & Seek matches keep running
        for (GameSession s : new ArrayList<>(SESSIONS.values())) s.abortAndResetNow("Minigames were reloaded.");
        SESSIONS.clear();
        MgSettings.load();
        ArenaManager.load();
    }

    public static void tick() {
        if (SESSIONS.isEmpty()) return;
        for (GameSession s : new ArrayList<>(SESSIONS.values())) {
            try {
                s.tick();
            } catch (Exception e) {
                MgMod.LOG.error("Minigame " + s.arena.id + " crashed - cancelling it", e);
                try { s.abortAndResetNow("Internal error."); } catch (Exception e2) { MgMod.LOG.error("abort failed", e2); }
            }
        }
    }

    // ------------------------------------------------------------------ dimensions

    /** The level of the arena's dimension, or null when that dimension does not exist / is not loaded. */
    public static ServerLevel levelOf(MinecraftServer srv, Arena a) {
        if (srv == null || a == null) return null;
        try {
            return srv.getLevel(ResourceKey.create(Registries.DIMENSION, Identifier.parse(a.dim())));
        } catch (RuntimeException e) {
            return null;
        }
    }

    /** Is a dimension id loaded on this server? (true while no server runs, so offline validation does not complain) */
    public static boolean dimensionLoaded(String dimension) {
        if (server == null) return true;
        try {
            return server.getLevel(ResourceKey.create(Registries.DIMENSION, Identifier.parse(dimension))) != null;
        } catch (RuntimeException e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ isolation

    /**
     * True when a block position belongs to an arena that is in use right now (players waiting, match running or reset running)
     * and the player is NOT part of any minigame and not an operator. Used to stop outsiders from changing blocks that the
     * arena's reset would not know about.
     */
    public static boolean isLockedFor(ServerPlayer p, net.minecraft.world.level.Level world, BlockPos pos) {
        if (SESSIONS.isEmpty() || BY_PLAYER.containsKey(p.getUUID())) return false;
        for (GameSession s : SESSIONS.values()) {
            if (s.isIdle() || s.level() != world) continue;
            if (s.arena.contains(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5)) {
                return !p.createCommandSourceStack().permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_GAMEMASTER);
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ lookups

    static void bind(UUID id, GameSession s) { BY_PLAYER.put(id, s); }
    static void unbind(UUID id) { BY_PLAYER.remove(id); }

    public static GameSession sessionOf(UUID id) { return BY_PLAYER.get(id); }

    public static GameSession sessionOf(ServerPlayer p) { return p == null ? null : BY_PLAYER.get(p.getUUID()); }

    public static boolean inInternalGame(ServerPlayer p) { return BY_PLAYER.containsKey(p.getUUID()); }

    /**
     * True when the entity is a player who takes part in a minigame OTHER than BedWars (TNT Run, Lava, Red Light, Hide &amp; Seek).
     * BedWars treats such players as "not in BedWars territory": no BedWars messages, damage rules, build rules or sidebar.
     */
    public static boolean inNonBedWarsGame(net.minecraft.world.entity.Entity e) {
        if (!(e instanceof ServerPlayer p)) return false;
        if (BY_PLAYER.containsKey(p.getUUID())) return true;
        ExternalGame hs = EXTERNAL.get(MinigameType.HIDESEEK);
        return hs != null && hs.isInGame(p);
    }

    /** Used by the BedWars sidebar: players in a minigame get the Minigames sidebar instead. */
    public static boolean hasOwnSidebar(ServerPlayer p) { return MgBoard.has(p.getUUID()); }

    public static GameSession sessionFor(Arena a) {
        GameSession s = SESSIONS.get(a.id.toLowerCase());
        if (s != null) return s;
        MinigameType t = a.type();
        if (t == null || server == null) return null;
        BiFunction<MinecraftServer, Arena, GameSession> f = FACTORIES.get(t);
        if (f == null) return null;
        s = f.apply(server, a);
        SESSIONS.put(a.id.toLowerCase(), s);
        return s;
    }

    /** Existing session without creating one (null = arena never used). */
    public static GameSession existingSession(Arena a) { return SESSIONS.get(a.id.toLowerCase()); }

    public static boolean canEdit(Arena a) {
        GameSession s = existingSession(a);
        return s == null || s.isIdle();
    }

    /** "/mg arena reset": puts back the blocks of an unfinished (crashed / interrupted) match. Returns an error text or null. */
    public static String restoreLeftovers(Arena a) {
        if (!canEdit(a)) return "A game is using this arena right now. Stop it first (/mg stop).";
        ServerLevel lvl = levelOf(server, a);
        if (lvl == null) return "The arena's dimension '" + a.dim() + "' is not loaded, so its blocks cannot be restored yet.";
        if (!BlockJournal.existsOnDisk(a)) return "Nothing to restore - this arena has no unfinished reset journal.";
        BlockJournal j = new BlockJournal(a);
        j.loadFromDisk();
        j.restoreAll(lvl);
        return null;
    }

    public static void forgetSession(Arena a) { SESSIONS.remove(a.id.toLowerCase()); }

    private static String busyReason(ServerPlayer p) {
        if (BY_PLAYER.containsKey(p.getUUID())) return "You are already in a minigame. Leave it first.";
        for (ExternalGame e : EXTERNAL.values()) if (e.isInGame(p)) return "You are already in " + e.type().display + ". Leave it first.";
        return null;
    }

    // ------------------------------------------------------------------ join / leave

    public static String join(ServerPlayer p, Arena a) {
        String busy = busyReason(p);
        if (busy != null) return busy;
        GameSession s = sessionFor(a);
        if (s == null) return "That minigame is not available yet.";
        return s.join(p);
    }

    /** Join the best arena of a game: the joinable one that already has the most players. Returns an error text or null. */
    public static String joinBest(ServerPlayer p, MinigameType t) {
        String busy = busyReason(p);
        if (busy != null) return busy;
        if (t.external) {
            ExternalGame e = EXTERNAL.get(t);
            return e == null ? t.display + " is not connected to /mg yet." : e.join(p);
        }
        List<Arena> arenas = ArenaManager.of(t);
        if (arenas.isEmpty()) return "No " + t.display + " arena has been set up yet.";
        GameSession best = null;
        String firstProblem = null;
        for (Arena a : arenas) {
            GameSession s = sessionFor(a);
            if (s == null) return t.display + " is not available yet.";
            String problem = s.joinProblem();
            if (problem == null) {
                if (best == null || s.playerCount() > best.playerCount()) best = s;
            } else if (firstProblem == null) {
                firstProblem = problem;
            }
        }
        if (best == null) return firstProblem != null ? firstProblem : "No arena is available.";
        return best.join(p);
    }

    /** Leaves whatever game the player is in. Returns false when the player was in none. */
    public static boolean leave(ServerPlayer p) {
        GameSession s = BY_PLAYER.get(p.getUUID());
        if (s != null) { s.leave(p, ""); return true; }
        for (ExternalGame e : EXTERNAL.values()) if (e.isInGame(p)) return e.leave(p);
        return false;
    }

    public static void onDisconnect(ServerPlayer p) {
        GameSession s = BY_PLAYER.get(p.getUUID());
        if (s != null) {
            try { s.leave(p, "disconnected"); } catch (Exception e) { MgMod.LOG.error("disconnect cleanup", e); BY_PLAYER.remove(p.getUUID()); }
        }
        MgBoard.forget(p.getUUID());
    }

    /**
     * A session player "died" (void, command...). Returns true when handled: the death must be cancelled and the player
     * is eliminated (match running) or put back on the waiting spot.
     */
    public static boolean onFatalDamage(ServerPlayer p) {
        GameSession s = BY_PLAYER.get(p.getUUID());
        if (s == null) return false;
        p.setHealth(p.getMaxHealth());
        p.clearFire();
        if (s.state == GameSession.State.ACTIVE && s.isAlive(p.getUUID())) s.eliminate(p, "died");
        else s.sendToWaiting(p);
        return true;
    }

    // ------------------------------------------------------------------ status for the GUI

    public static Status status(MinigameType t) {
        if (t.external) {
            ExternalGame e = EXTERNAL.get(t);
            if (e == null) return new Status("§8Not connected yet", 0, 0, "-", false, "Not connected to /mg yet.");
            return e.status(server);
        }
        List<Arena> arenas = ArenaManager.of(t);
        if (!FACTORIES.containsKey(t)) return new Status("§8Coming soon", 0, 0, "-", false, t.display + " is not available yet.");
        if (arenas.isEmpty()) return new Status("§8No arena", 0, 0, "-", false, "No arena has been set up yet.");
        int players = 0, capacity = 0;
        GameSession best = null;
        String reason = null;
        for (Arena a : arenas) {
            GameSession s = sessionFor(a);
            players += s.playerCount();
            capacity += a.maxPlayers;
            String problem = s.joinProblem();
            if (problem == null) { if (best == null || s.playerCount() > best.playerCount()) best = s; }
            else if (reason == null) reason = problem;
        }
        if (best != null) return new Status(best.stateLabel(), players, capacity, best.arena.displayName(), true, null);
        GameSession any = sessionFor(arenas.get(0));
        return new Status(any.stateLabel(), players, capacity, arenas.get(0).displayName(), false, reason);
    }

    public static int playersIn(MinigameType t) {
        int n = 0;
        for (GameSession s : SESSIONS.values()) if (s.type == t) n += s.playerCount();
        return n;
    }

    // ------------------------------------------------------------------ admin force

    /** Safely ends every running minigame (players restored and sent to the common lobby, arenas reset). */
    public static void stopAll(String reason) {
        for (GameSession s : new ArrayList<>(SESSIONS.values())) s.abortAndResetNow(reason);
        for (ExternalGame e : EXTERNAL.values()) e.forceStop(server);
    }

    /** "/mg <game> force": everybody online goes to the game and it starts. Returns an error text or null. */
    public static String forceAll(MinecraftServer srv, MinigameType t, CommandSourceStack by) {
        List<ServerPlayer> everyone = new ArrayList<>(srv.getPlayerList().getPlayers());
        if (t.external) {
            ExternalGame e = EXTERNAL.get(t);
            if (e == null) return t.display + " is not connected to /mg yet.";
            stopAll("An admin forced " + t.display + ".");
            String err = e.forceAll(srv, by);
            if (err == null) announceForce(srv, t);
            return err;
        }
        if (!FACTORIES.containsKey(t)) return t.display + " is not available yet.";
        Arena a = pickArena(t, everyone.size());
        if (a == null) {
            List<Arena> list = ArenaManager.of(t);
            if (list.isEmpty()) return "No " + t.display + " arena exists. Create one with /mg arena create " + t.id + " <id>.";
            return "No " + t.display + " arena is ready: '" + list.get(0).id + "' is " + ArenaManager.problem(list.get(0)) + ".";
        }
        if (everyone.size() < a.minPlayers) {
            return "Not enough players online for " + t.display + " (" + everyone.size() + "/" + a.minPlayers
                    + "). Use /mg " + t.id + " force <player> to place single players instead.";
        }
        stopAll("An admin forced " + t.display + ".");   // ends every other game and resets every arena
        GameSession s = sessionFor(a);
        int moved = 0;
        for (ServerPlayer p : everyone) {
            if (moved >= a.maxPlayers) {
                p.sendSystemMessage(MgUtil.msg("§cArena '" + a.displayName() + "' is full (" + a.maxPlayers + " players) - you stay in the lobby."));
                continue;
            }
            String err = s.join(p);
            if (err == null) moved++;
            else p.sendSystemMessage(MgUtil.msg("§c" + err));
        }
        if (moved == 0) return "Nobody could be moved into the arena.";
        s.startCountdown(true);
        announceForce(srv, t);
        return null;
    }

    /** "/mg <game> force <player>": only that player is moved (leaving any game they were in). Returns an error text or null. */
    public static String forcePlayer(MinecraftServer srv, MinigameType t, ServerPlayer target) {
        leave(target);
        if (t.external) {
            ExternalGame e = EXTERNAL.get(t);
            return e == null ? t.display + " is not connected to /mg yet." : e.forcePlayer(srv, target);
        }
        if (!FACTORIES.containsKey(t)) return t.display + " is not available yet.";
        List<Arena> arenas = ArenaManager.of(t);
        if (arenas.isEmpty()) return "No " + t.display + " arena exists.";
        return joinBest(target, t);
    }

    private static Arena pickArena(MinigameType t, int online) {
        Arena fallback = null;
        for (Arena a : ArenaManager.of(t)) {
            if (ArenaManager.problem(a) != null) continue;
            if (a.maxPlayers >= online) return a;
            if (fallback == null || a.maxPlayers > fallback.maxPlayers) fallback = a;
        }
        return fallback;
    }

    private static void announceForce(MinecraftServer srv, MinigameType t) {
        Component c = Component.literal("§8[§bMinigames§8] §6§lADMIN FORCE: " + t.color + "§l" + t.display + " §7- everybody is being moved to the arena!");
        srv.getPlayerList().broadcastSystemMessage(c, false);
        for (ServerPlayer p : srv.getPlayerList().getPlayers()) MgUtil.title(p, t.color + "§l" + t.display.toUpperCase(), "§7Forced by an administrator", 5, 50, 10);
    }

    /** Arenas sorted for display. */
    public static List<Arena> arenasFor(MinigameType t) {
        List<Arena> l = ArenaManager.of(t);
        l.sort(Comparator.comparing(a -> a.id));
        return l;
    }
}
