package com.hanzala.minigames;

import com.hanzala.bedwars.ServerGui;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/** Arena picker for one game: shows every arena with status and players, click to join. Has Back and Close buttons. */
public final class MgArenaMenu extends ServerGui {
    private static final int[] SLOTS = { 10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25 };
    private final MinigameType type;

    public static void open(ServerPlayer p, MinigameType t) {
        p.openMenu(new SimpleMenuProvider((id, inv, pl) -> new MgArenaMenu(id, inv, t), Component.literal("§8" + t.display + " - arenas")));
    }

    private MgArenaMenu(int containerId, Inventory inventory, MinigameType type) {
        super(4, containerId, inventory);
        this.type = type;
        build();
    }

    @Override
    protected void build() {
        reset();
        put(4, icon(type.icon, type.color + "§l" + type.display, wrap(type.description, 32)));
        if (type.external) {
            Mg.Status st = Mg.status(type);
            put(13, icon(st.joinable() ? Items.LIME_CONCRETE : Items.GRAY_CONCRETE, "§f" + st.arenaName(),
                    List.of("§7Status: " + st.label(), "§7Players: §f" + st.players(), " ",
                            st.joinable() ? "§eClick to join!" : "§c" + (st.reason() == null ? "Not available" : st.reason()))),
                    (p, b, s) -> join(p, null));
        } else {
            List<Arena> arenas = Mg.arenasFor(type);
            if (arenas.isEmpty()) put(13, icon(Items.GRAY_CONCRETE, "§cNo arenas", "§7An admin must set one up:", "§f/mg setup"));
            for (int i = 0; i < arenas.size() && i < SLOTS.length; i++) {
                Arena a = arenas.get(i);
                GameSession s = Mg.sessionFor(a);
                String problem = s == null ? "Not available yet." : s.joinProblem();
                Item mat = problem == null ? (s.state == GameSession.State.COUNTDOWN ? Items.YELLOW_CONCRETE : Items.LIME_CONCRETE)
                        : (s != null && s.isRunning() ? Items.RED_CONCRETE : Items.GRAY_CONCRETE);
                List<String> lore = new ArrayList<>();
                lore.add("§7Status: " + (s == null ? "§8n/a" : s.stateLabel()));
                lore.add("§7Players: §f" + (s == null ? 0 : s.playerCount()) + "§8/§f" + a.maxPlayers + " §8(min " + a.minPlayers + ")");
                lore.add(" ");
                lore.add(problem == null ? "§eClick to join!" : "§c" + problem);
                put(SLOTS[i], icon(mat, "§f" + a.displayName(), lore), (p, b, sh) -> join(p, a));
            }
        }
        put(27, icon(Items.ARROW, "§7Back"), (p, b, s) -> MgMenu.open(p));
        put(31, icon(Items.BARRIER, "§cClose"), (p, b, s) -> p.closeContainer());
        put(35, icon(Items.NAME_TAG, MgBoard.CREDIT));
    }

    private void join(ServerPlayer p, Arena a) {
        String err = a == null ? Mg.joinBest(p, type) : Mg.join(p, a);
        if (err != null) { MgUtil.bar(p, "§c" + err); refresh(); }
        else p.closeContainer();
    }
}
