package com.hanzala.minigames;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.numbers.BlankFormat;
import net.minecraft.network.chat.numbers.NumberFormat;
import net.minecraft.network.protocol.game.ClientboundResetScorePacket;
import net.minecraft.network.protocol.game.ClientboundSetDisplayObjectivePacket;
import net.minecraft.network.protocol.game.ClientboundSetObjectivePacket;
import net.minecraft.network.protocol.game.ClientboundSetScorePacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.criteria.ObjectiveCriteria;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Per-player sidebar for minigame participants (raw packets from a private scoreboard, so the real server scoreboard is never
 * touched). The last line is always the small grey "Owner: HANZALA" credit.
 */
public final class MgBoard {
    private MgBoard() { }

    public static final String CREDIT = "§8Owner: HANZALA";
    private static final String OBJECTIVE = "mg_side";
    private static final String HOLDER = "mg_l";
    private static final int MAX_LINES = 15;

    private static final Scoreboard PACKET_SB = new Scoreboard();
    private static final Objective OBJ = new Objective(PACKET_SB, OBJECTIVE, ObjectiveCriteria.DUMMY,
            Component.literal("MINIGAMES"), ObjectiveCriteria.RenderType.INTEGER, false, BlankFormat.INSTANCE);

    private static final class Shown {
        String title;
        List<String> lines;
    }

    private static final Map<UUID, Shown> SHOWN = new HashMap<>();

    public static boolean has(UUID id) { return SHOWN.containsKey(id); }

    /** Shows or updates the sidebar. {@code lines} are top to bottom, the credit is appended automatically. */
    public static void show(ServerPlayer p, String title, List<String> lines) {
        List<String> wanted = new ArrayList<>(lines.size() > MAX_LINES - 2 ? lines.subList(0, MAX_LINES - 2) : lines);
        wanted.add("");
        wanted.add(CREDIT);
        int n = wanted.size();
        Shown s = SHOWN.get(p.getUUID());
        OBJ.setDisplayName(Component.literal(title));
        if (s == null) {
            p.connection.send(new ClientboundSetObjectivePacket(OBJ, 0));
            p.connection.send(new ClientboundSetDisplayObjectivePacket(DisplaySlot.SIDEBAR, OBJ));
            for (int i = 0; i < n; i++) sendLine(p, i, n, wanted.get(i));
            s = new Shown();
            SHOWN.put(p.getUUID(), s);
        } else {
            if (!title.equals(s.title)) p.connection.send(new ClientboundSetObjectivePacket(OBJ, 2));
            boolean sameShape = s.lines.size() == n;
            for (int i = 0; i < n; i++) {
                if (sameShape && wanted.get(i).equals(s.lines.get(i))) continue;
                sendLine(p, i, n, wanted.get(i));
            }
            for (int i = n; i < s.lines.size(); i++) p.connection.send(new ClientboundResetScorePacket(HOLDER + i, OBJECTIVE));
        }
        s.title = title;
        s.lines = wanted;
    }

    private static void sendLine(ServerPlayer p, int i, int n, String text) {
        // an empty line needs a unique invisible text, otherwise two blank rows would be identical
        String t = text.isEmpty() ? "§" + Integer.toHexString(i % 16) + "§r" : text;
        p.connection.send(new ClientboundSetScorePacket(HOLDER + i, OBJECTIVE, n - i,
                Optional.of(Component.literal(t)), Optional.<NumberFormat>of(BlankFormat.INSTANCE)));
    }

    public static void hide(ServerPlayer p) {
        if (SHOWN.remove(p.getUUID()) != null) p.connection.send(new ClientboundSetObjectivePacket(OBJ, 1));
    }

    /** Forget a disconnected player's state (their client is gone). */
    public static void forget(UUID id) { SHOWN.remove(id); }

    public static void clearAll() { SHOWN.clear(); }
}
