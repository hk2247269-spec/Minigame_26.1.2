package com.hanzala.minigames;

import com.hanzala.bedwars.ServerGui;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/**
 * The main Minigames GUI (a vanilla chest screen driven by the server - no client mod needed).
 * Left-click a game = join it. Right-click (or shift-click) = choose a specific arena.
 */
public final class MgMenu extends ServerGui {
    private static final MinigameType[] GAMES = {
            MinigameType.BEDWARS, MinigameType.HIDESEEK, MinigameType.TNT_RUN, MinigameType.FLOOR_LAVA, MinigameType.RED_GREEN };
    private static final int[] SLOTS = { 11, 12, 13, 14, 15 };

    public static void open(ServerPlayer p) {
        p.openMenu(new SimpleMenuProvider((id, inv, pl) -> new MgMenu(id, inv), Component.literal("§8Minigames")));
    }

    private MgMenu(int containerId, Inventory inventory) {
        super(4, containerId, inventory);
        build();
    }

    @Override
    protected void build() {
        reset();
        put(4, icon(Items.NETHER_STAR, "§b§lMINIGAMES", List.of("§7Pick a game to join.", "§8Left-click: join  |  Right-click: choose arena")));
        for (int i = 0; i < GAMES.length; i++) {
            MinigameType t = GAMES[i];
            Mg.Status st = Mg.status(t);
            List<String> lore = new ArrayList<>();
            lore.add("§7" + t.description);
            lore.add(" ");
            lore.add("§7Status: " + st.label());
            lore.add("§7Players: §f" + st.players() + (st.capacity() > 0 ? "§8/§f" + st.capacity() : ""));
            lore.add("§7Arena: §f" + st.arenaName());
            lore.add(" ");
            if (st.joinable()) lore.add("§eClick to join!");
            else lore.add("§c" + (st.reason() == null ? "Not available" : st.reason()));
            if (!t.external || Mg.isAvailable(t)) lore.add("§8Right-click: choose arena");
            Item shown = t == MinigameType.RED_GREEN && Mg.playersIn(t) > 0 && !st.joinable() ? Items.RED_CONCRETE : t.icon;
            var stack = icon(shown, t.color + "§l" + t.display, lore);
            if (st.joinable()) glow(stack);
            put(SLOTS[i], stack, (p, button, shift) -> {
                if (button == 1 || shift) { MgArenaMenu.open(p, t); return; }
                String err = Mg.joinBest(p, t);
                if (err != null) { MgUtil.bar(p, "§c" + err); refresh(); }
                else p.closeContainer();
            });
        }
        ServerPlayer me = viewer;
        if (me != null && (Mg.sessionOf(me) != null)) {
            put(29, icon(Items.RED_DYE, "§c§lLeave current game", "§7Go back to the lobby."), (p, b, s) -> {
                Mg.leave(p);
                p.closeContainer();
            });
        }
        if (me != null && isAdmin(me)) {
            putAdmin(33, icon(Items.COMMAND_BLOCK, "§6§lAdmin setup", "§7Lobby and arena setup wizard.", "§8Same as /mg setup"), (p, b, s) -> MgSetupMenu.open(p));
        }
        put(31, icon(Items.BARRIER, "§cClose"), (p, b, s) -> p.closeContainer());
        put(35, icon(Items.NAME_TAG, MgBoard.CREDIT));
    }
}
