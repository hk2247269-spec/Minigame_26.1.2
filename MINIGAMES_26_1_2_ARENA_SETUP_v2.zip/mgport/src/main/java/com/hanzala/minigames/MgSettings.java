package com.hanzala.minigames;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** config/minigames/settings.json - global timings shared by every minigame. Edit the file and run /mg reload. */
public final class MgSettings {
    /** Seconds of countdown once the minimum number of players is reached. */
    public int countdownSeconds = 15;
    /** Countdown used by "/mg <game> force". */
    public int forceCountdownSeconds = 5;
    /** "Get ready" phase between the countdown and the real start. */
    public int startingSeconds = 3;
    /** How long the winner is celebrated before everybody is sent back to the lobby. */
    public int endDelaySeconds = 8;
    /** Hard time limit of a match (draw between survivors when reached). */
    public int maxMatchSeconds = 900;
    /** Give every lobby player a compass that reopens /mg menu. */
    public boolean giveMenuItem = true;
    /** How many blocks per tick an arena reset may restore (keeps the server lag-free). */
    public int resetBlocksPerTick = 600;

    public static MgSettings I = new MgSettings();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static Path dir() {
        Path d = FabricLoader.getInstance().getConfigDir().resolve("minigames");
        try { Files.createDirectories(d); } catch (Exception e) { MgMod.LOG.error("Cannot create " + d, e); }
        return d;
    }

    public static void load() {
        Path f = dir().resolve("settings.json");
        try {
            if (Files.exists(f)) {
                MgSettings s = GSON.fromJson(Files.readString(f), MgSettings.class);
                if (s != null) I = s;
            }
            Files.writeString(f, GSON.toJson(I)); // writes defaults / adds new keys
        } catch (Exception e) {
            MgMod.LOG.error("Could not read settings.json, using defaults", e);
        }
        I.countdownSeconds = Math.max(3, I.countdownSeconds);
        I.forceCountdownSeconds = Math.max(3, I.forceCountdownSeconds);
        I.startingSeconds = Math.max(1, I.startingSeconds);
        I.endDelaySeconds = Math.max(2, I.endDelaySeconds);
        I.resetBlocksPerTick = Math.max(50, I.resetBlocksPerTick);
    }
}
