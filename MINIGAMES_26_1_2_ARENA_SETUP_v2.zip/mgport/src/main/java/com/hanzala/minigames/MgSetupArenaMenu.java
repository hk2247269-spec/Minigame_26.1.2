package com.hanzala.minigames;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/**
 * The arena page of the setup wizard (admins only). Stand where you want a point, click the button. Every button shows what is
 * already set. "Check arena" lists every problem with how to fix it; "Enable" is only accepted when there are no errors.
 */
public final class MgSetupArenaMenu extends ServerGui {
    private static final int[] PARAM_SLOTS = { 19, 20, 21, 22, 23, 24 };

    private final String arenaId;
    private boolean confirmDelete;

    public static void open(ServerPlayer p, String arenaId) {
        if (!isAdmin(p)) return;
        Arena a = ArenaManager.get(arenaId);
        if (a == null) return;
        p.openMenu(new SimpleMenuProvider((id, inv, pl) -> new MgSetupArenaMenu(id, inv, arenaId), Component.literal("§8Setup: " + a.displayName())));
    }

    private MgSetupArenaMenu(int containerId, Inventory inventory, String arenaId) {
        super(6, containerId, inventory);
        this.arenaId = arenaId;
        build();
    }

    /** Shows the result of an edit (chat for errors so long texts are readable) and redraws. */
    private void done(ServerPlayer p, String error, String ok) {
        if (error != null) p.sendSystemMessage(MgUtil.msg("§c" + error));
        else bar(p, "§a" + ok);
        confirmDelete = false;
        refresh();
    }

    private static String where(Arena.Loc l) { return l == null ? "§cnot set" : "§a✔ §7" + (int) l.x + " " + (int) l.y + " " + (int) l.z; }

    @Override
    protected void build() {
        reset();
        Arena a = ArenaManager.get(arenaId);
        if (a == null) { // deleted meanwhile
            put(22, icon(Items.BARRIER, "§cThis arena no longer exists"), (p, b, s) -> MgSetupMenu.open(p));
            return;
        }
        MinigameType type = a.type();
        boolean rg = type == MinigameType.RED_GREEN;

        // ---- summary
        List<ArenaValidator.Issue> issues = ArenaManager.validate(a);
        boolean errors = ArenaValidator.hasErrors(issues);
        List<String> sum = new ArrayList<>();
        sum.add(a.enabled ? "§aEnabled - players can join" : (errors ? "§cNot ready" : "§eReady - press Enable"));
        sum.add("§7Dimension: §f" + a.dim());
        sum.add("§7Id: §f" + a.id);
        int shown = 0;
        for (ArenaValidator.Issue i : issues) {
            if (i.isError() && shown++ < 3) sum.add("§c✘ §7" + i.message());
        }
        if (shown < issues.stream().filter(ArenaValidator.Issue::isError).count()) sum.add("§7... press 'Check arena' for all");
        sum.add(" ");
        sum.add("§8Rename: /mg arena name " + a.id + " <text>");
        put(4, icon(type == null ? Items.PAPER : type.icon, (type == null ? "§f" : type.color + "§l") + a.displayName(), sum));

        // ---- locations
        put(10, icon(Items.LIME_DYE, "§e§lSet corner 1", List.of(
                a.hasPos1 ? "§a✔ §7" + a.x1 + " " + a.y1 + " " + a.z1 : "§cnot set",
                "§7Stand in one corner of the arena.", "§7Include the floor and the highest point.", " ", "§eClick: §fuse my position")),
                (p, b, s) -> done(p, ArenaEdit.corner(a, p, true), "Corner 1 set."));
        put(11, icon(Items.ORANGE_DYE, "§e§lSet corner 2", List.of(
                a.hasPos2 ? "§a✔ §7" + a.x2 + " " + a.y2 + " " + a.z2 : "§cnot set",
                "§7Stand in the OPPOSITE corner,", "§7at a different height.", " ", "§eClick: §fuse my position")),
                (p, b, s) -> done(p, ArenaEdit.corner(a, p, false), "Corner 2 set."));
        put(12, icon(Items.ARMOR_STAND, "§e§lAdd spawn", List.of(
                a.spawns.isEmpty() ? "§cnone yet" : "§a✔ §7" + a.spawns.size() + " spawn(s)",
                "§7Players start here when the match begins.", " ", "§eClick: §fadd a spawn at my position", "§eRight-click: §fremove all spawns")),
                (p, b, s) -> {
                    if (b == 1) done(p, ArenaEdit.clearSpawns(a), "All spawns removed.");
                    else done(p, ArenaEdit.addSpawn(a, p), "Spawn #" + (a.spawns.size()) + " added.");
                });
        put(13, icon(Items.CLOCK, "§e§lSet waiting spot", List.of(
                where(a.waiting), "§7Where players wait before the match.", "§8Optional - default: the first spawn.", " ", "§eClick: §fuse my position")),
                (p, b, s) -> done(p, ArenaEdit.setWaiting(a, p), "Waiting spot set."));
        put(14, icon(Items.SPYGLASS, "§e§lSet spectator spot", List.of(
                where(a.spectator), "§7Where eliminated players watch.", "§8Optional - default: above the arena.", " ", "§eClick: §fuse my position")),
                (p, b, s) -> done(p, ArenaEdit.setSpectator(a, p), "Spectator spot set."));
        if (rg) {
            put(15, icon(Items.WHITE_BANNER, "§e§lSet finish line", List.of(
                    where(a.finish), "§7Stand ON the finish line, at the far end.", "§7The statue stands here.", " ", "§eClick: §fuse my position")),
                    (p, b, s) -> done(p, ArenaEdit.setFinish(a, p), "Finish line set."));
        }

        // ---- game numbers
        List<ArenaEdit.Param> params = ArenaEdit.paramsOf(type);
        for (int i = 0; i < params.size() && i < PARAM_SLOTS.length; i++) {
            ArenaEdit.Param prm = params.get(i);
            double cur = prm.current(a);
            String val = cur == Math.rint(cur) ? String.valueOf((long) cur) : String.valueOf(cur);
            put(PARAM_SLOTS[i], icon(Items.COMPARATOR, "§b" + prm.label() + ": §f" + val, List.of(
                    "§7" + prm.help(), " ", "§eClick: §f+" + fmt(prm.step()), "§eRight-click: §f-" + fmt(prm.step()))),
                    (p, b, s) -> done(p, ArenaEdit.nudge(a, prm, b == 1 ? -1 : 1), prm.label() + " changed."));
        }
        put(28, icon(Items.PLAYER_HEAD, "§b§lMinimum players: §f" + a.minPlayers, List.of("§7The countdown starts at this many.", " ", "§eClick: §f+1", "§eRight-click: §f-1")),
                (p, b, s) -> done(p, ArenaEdit.setMin(a, a.minPlayers + (b == 1 ? -1 : 1)), "Minimum players changed."));
        put(29, icon(Items.PLAYER_HEAD, "§b§lMaximum players: §f" + a.maxPlayers, List.of("§7The arena is full at this many.", " ", "§eClick: §f+1", "§eRight-click: §f-1")),
                (p, b, s) -> done(p, ArenaEdit.setMax(a, a.maxPlayers + (b == 1 ? -1 : 1)), "Maximum players changed."));

        // ---- check / enable / test / delete
        put(31, icon(Items.WRITABLE_BOOK, "§b§lCheck arena", List.of("§7Lists every problem and how to fix it.")), (p, b, s) -> {
            p.closeContainer();
            ArenaEdit.report(p.createCommandSourceStack(), a);
        });
        if (a.enabled) {
            put(38, icon(Items.REDSTONE_BLOCK, "§c§lDisable arena", List.of("§7Players can no longer join it.", "§7Nothing is deleted.", " ", "§eClick: §fdisable")),
                    (p, b, s) -> done(p, ArenaEdit.disable(a), "Arena disabled."));
        } else {
            ItemStack enableIcon = icon(errors ? Items.GRAY_CONCRETE : Items.EMERALD_BLOCK, (errors ? "§7§lEnable arena" : "§a§lEnable arena"),
                    errors ? List.of("§cCannot enable yet.", "§7Press 'Check arena' to see what is missing.")
                           : List.of("§aNo errors found.", " ", "§eClick: §fenable - players can join"));
            put(38, errors ? enableIcon : glow(enableIcon), (p, b, s) -> done(p, ArenaEdit.enable(a), "Arena enabled! Players can join it from /mg."));
        }
        put(40, icon(Items.ENDER_PEARL, "§d§lTeleport to arena", List.of("§7Go there to look at it or test it.", " ", "§eClick: §fteleport")), (p, b, s) -> {
            Arena.Loc target = a.waitingSpot();
            if (target == null && a.hasBox) {
                target = new Arena.Loc();
                target.x = (a.minX() + a.maxX() + 1) / 2.0; target.y = a.maxY() + 2; target.z = (a.minZ() + a.maxZ() + 1) / 2.0;
            }
            net.minecraft.server.level.ServerLevel lvl = Mg.levelOf(p.level().getServer(), a);
            if (target == null || lvl == null) { p.sendSystemMessage(MgUtil.msg("§cNothing to teleport to yet (set the corners or a spawn first, and make sure the dimension is loaded).")); return; }
            if (Mg.sessionOf(p) != null) { p.sendSystemMessage(MgUtil.msg("§cLeave your current game first (/mg leave).")); return; }
            MgUtil.tp(p, lvl, target);
            p.closeContainer();
        });
        put(42, icon(Items.TNT, confirmDelete ? "§4§lClick again to DELETE" : "§c§lDelete arena",
                List.of("§7Removes this arena's settings.", "§7No block in the world is touched.", " ", confirmDelete ? "§cClick again to confirm." : "§eClick: §fdelete (asks first)")),
                (p, b, s) -> {
                    if (!confirmDelete) { confirmDelete = true; refresh(); return; }
                    String err = ArenaEdit.delete(a);
                    if (err != null) { done(p, err, ""); return; }
                    p.sendSystemMessage(MgUtil.msg("Arena '" + a.id + "' deleted."));
                    MgSetupMenu.open(p);
                });
        put(34, icon(Items.HOPPER, "§6§lClear all locations", List.of("§7Forgets corners and spots so you can", "§7rebuild the arena - also in another dimension.", "§7Settings stay. The arena is disabled.", " ", "§eClick: §fclear")),
                (p, b, s) -> done(p, ArenaEdit.clearLocations(a), "Locations cleared."));

        put(45, icon(Items.ARROW, "§7Back"), (p, b, s) -> MgSetupMenu.open(p));
        put(49, icon(Items.BARRIER, "§cClose"), (p, b, s) -> p.closeContainer());
        put(53, icon(Items.NAME_TAG, MgBoard.CREDIT));
    }

    private static String fmt(double d) { return d == Math.rint(d) ? String.valueOf((long) d) : String.valueOf(d); }
}
