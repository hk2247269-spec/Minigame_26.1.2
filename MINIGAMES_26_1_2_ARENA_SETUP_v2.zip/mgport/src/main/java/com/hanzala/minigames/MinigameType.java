package com.hanzala.minigames;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

/** The five minigames. BedWars and Hide &amp; Seek are "external": they keep their own engines and plug in through {@link ExternalGame}. */
public enum MinigameType {
    BEDWARS("bw", "BedWars", Items.RED_BED, "§c", "Protect your bed and destroy the others.", true),
    HIDESEEK("hs", "Hide & Seek", Items.PLAYER_HEAD, "§d", "Hiders disguise as blocks, seekers hunt them.", true),
    TNT_RUN("tnt", "TNT Run", Items.TNT, "§6", "The floor vanishes under your feet. Keep running!", false),
    FLOOR_LAVA("lava", "Floor Is Lava", Items.LAVA_BUCKET, "§c", "Lava keeps rising. Climb or burn!", false),
    RED_GREEN("rg", "Red Light, Green Light", Items.GREEN_CONCRETE, "§a", "Move on green, freeze on red, reach the finish.", false);

    public final String id;
    public final String display;
    public final Item icon;
    public final String color;
    public final String description;
    /** true = BedWars / Hide &amp; Seek (own engine); false = built on {@link GameSession}. */
    public final boolean external;

    MinigameType(String id, String display, Item icon, String color, String description, boolean external) {
        this.id = id;
        this.display = display;
        this.icon = icon;
        this.color = color;
        this.description = description;
        this.external = external;
    }

    public static MinigameType byId(String id) {
        if (id == null) return null;
        for (MinigameType t : values()) if (t.id.equalsIgnoreCase(id)) return t;
        return null;
    }
}
