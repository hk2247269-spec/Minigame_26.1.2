package net.hanzala.hideseek;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Block;

import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** All editable configuration: game.json, abilities.json, rewards.json, arenas.json (in config/hideseek/). */
public final class Cfg {
    private Cfg() {}

    static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    public static Path dir;
    public static GameCfg game = new GameCfg();
    public static AbilityCfg abilities = new AbilityCfg();
    public static RewardCfg rewards = new RewardCfg();
    public static Map<String, ArenaCfg> arenas = new LinkedHashMap<>();
    /** Disguise block ids that passed validation. */
    public static List<String> blockIds = new ArrayList<>();

    // ---------- game.json ----------
    public static class GameCfg {
        public int minPlayers = 4;
        public int maxPlayers = 16;
        public int forceStartMinPlayers = 2;
        public int countdownSeconds = 15;
        public int hidingSeconds = 30;
        public int matchSeconds = 300;
        public int resultsSeconds = 12;
        public int playersPerSeeker = 6;
        public boolean allowJoinFromOtherDimensions = false;
        public boolean allowDisguiseChangeWhileSeeking = false;
        public String defaultArena = "";
        public List<String> disguiseBlocks = new ArrayList<>(List.of(
                "minecraft:stone", "minecraft:cobblestone", "minecraft:mossy_cobblestone", "minecraft:dirt",
                "minecraft:oak_planks", "minecraft:spruce_planks", "minecraft:oak_log", "minecraft:crafting_table",
                "minecraft:furnace", "minecraft:barrel", "minecraft:hay_block", "minecraft:pumpkin",
                "minecraft:melon", "minecraft:bookshelf", "minecraft:tnt", "minecraft:end_stone",
                "minecraft:end_stone_bricks", "minecraft:purpur_block", "minecraft:purpur_pillar",
                "minecraft:obsidian", "minecraft:crying_obsidian", "minecraft:bone_block", "minecraft:glowstone",
                "minecraft:sea_lantern", "minecraft:netherrack", "minecraft:deepslate_bricks",
                "minecraft:copper_block", "minecraft:iron_block", "minecraft:gold_block", "minecraft:diamond_block",
                "minecraft:emerald_block", "minecraft:lapis_block", "minecraft:white_wool",
                "minecraft:black_concrete", "minecraft:purple_concrete", "minecraft:magenta_glazed_terracotta",
                "minecraft:amethyst_block", "minecraft:sandstone", "minecraft:bricks", "minecraft:quartz_block",
                "minecraft:smooth_stone", "minecraft:coal_block", "minecraft:redstone_block",
                "minecraft:slime_block", "minecraft:honey_block"));
    }

    // ---------- abilities.json ----------
    public static class Ab {
        public int cooldownSeconds;
        public int durationSeconds;
        public int amplifier;
        public int range;
        public int radius;
        public int maxCount;
    }

    static Ab ab(int cd, int dur, int amp, int range, int radius, int max) {
        Ab a = new Ab();
        a.cooldownSeconds = cd; a.durationSeconds = dur; a.amplifier = amp;
        a.range = range; a.radius = radius; a.maxCount = max;
        return a;
    }

    public static class AbilityCfg {
        public Ab hiderSpeed = ab(20, 5, 1, 0, 0, 0);
        public Ab vanish = ab(25, 3, 0, 0, 0, 0);
        public Ab decoy = ab(10, 0, 0, 0, 0, 3);
        public Ab radar = ab(8, 0, 0, 48, 0, 0);
        public Ab pulse = ab(30, 4, 0, 0, 24, 0);
        public Ab seekerSpeed = ab(30, 8, 0, 0, 0, 0);

        public Ab get(String key) {
            return switch (key) {
                case "h:speed" -> hiderSpeed;
                case "h:vanish" -> vanish;
                case "h:decoy" -> decoy;
                case "s:radar" -> radar;
                case "s:pulse" -> pulse;
                default -> seekerSpeed;
            };
        }
    }

    // ---------- rewards.json ----------
    public static class ItemRw {
        public String item = "minecraft:emerald";
        public int count = 1;
        ItemRw() {}
        ItemRw(String i, int c) { item = i; count = c; }
    }

    public static class RewardCfg {
        public List<ItemRw> participationItems = new ArrayList<>(List.of(new ItemRw("minecraft:emerald", 1)));
        public List<ItemRw> winnerItems = new ArrayList<>(List.of(new ItemRw("minecraft:diamond", 1)));
        public List<ItemRw> survivorItems = new ArrayList<>(List.of(new ItemRw("minecraft:ender_pearl", 2)));
        public List<ItemRw> perKillItems = new ArrayList<>(List.of(new ItemRw("minecraft:gold_ingot", 1)));
        public int winnerXpLevels = 3;
        public List<String> winnerCommands = new ArrayList<>();
        public List<String> participationCommands = new ArrayList<>();
    }

    // ---------- arenas.json ----------
    public static class Loc {
        public double x, y, z;
        public float yaw, pitch;
        public static Loc of(ServerPlayer p) {
            Loc l = new Loc();
            l.x = p.getX(); l.y = p.getY(); l.z = p.getZ(); l.yaw = p.getYRot(); l.pitch = p.getXRot();
            return l;
        }
    }

    public static class ArenaCfg {
        public String name;
        public Loc lobby, hiderSpawn, seekerSpawn, spectatorSpawn, boundsA, boundsB;

        public boolean complete() {
            return lobby != null && hiderSpawn != null && seekerSpawn != null;
        }

        public boolean hasBounds() {
            return boundsA != null && boundsB != null;
        }

        public boolean inside(double x, double y, double z) {
            if (!hasBounds()) return true;
            return x >= Math.min(boundsA.x, boundsB.x) - 1 && x <= Math.max(boundsA.x, boundsB.x) + 1
                    && y >= Math.min(boundsA.y, boundsB.y) - 2 && y <= Math.max(boundsA.y, boundsB.y) + 64
                    && z >= Math.min(boundsA.z, boundsB.z) - 1 && z <= Math.max(boundsA.z, boundsB.z) + 1;
        }
    }

    // ---------- loading / saving ----------
    public static void init(Path configDir) {
        dir = configDir;
        try { Files.createDirectories(dir); } catch (Exception e) { HideSeekMod.LOG.error("Cannot create config dir", e); }
        reload();
    }

    public static void reload() {
        game = load("game.json", GameCfg.class, new GameCfg());
        abilities = load("abilities.json", AbilityCfg.class, new AbilityCfg());
        rewards = load("rewards.json", RewardCfg.class, new RewardCfg());
        Type t = new TypeToken<LinkedHashMap<String, ArenaCfg>>() {}.getType();
        Path p = dir.resolve("arenas.json");
        try {
            if (Files.exists(p)) {
                Map<String, ArenaCfg> m = GSON.fromJson(Files.readString(p), t);
                arenas = m != null ? m : new LinkedHashMap<>();
            } else {
                saveArenas();
            }
        } catch (Exception e) {
            HideSeekMod.LOG.error("arenas.json is broken, keeping previous arenas", e);
        }
        rebuildBlocks();
    }

    static <T> T load(String file, Class<T> cls, T def) {
        Path p = dir.resolve(file);
        try {
            if (!Files.exists(p)) {
                Files.writeString(p, GSON.toJson(def));
                return def;
            }
            T v = GSON.fromJson(Files.readString(p), cls);
            return v != null ? v : def;
        } catch (Exception e) {
            HideSeekMod.LOG.error("Could not read " + file + " - using defaults (file left untouched)", e);
            return def;
        }
    }

    public static void saveArenas() {
        try {
            Files.writeString(dir.resolve("arenas.json"), GSON.toJson(arenas));
        } catch (Exception e) {
            HideSeekMod.LOG.error("Could not save arenas.json", e);
        }
    }

    static void rebuildBlocks() {
        List<String> ok = new ArrayList<>();
        for (String id : game.disguiseBlocks) {
            Identifier rl = Identifier.tryParse(id);
            if (rl == null) continue;
            Optional<Block> b = BuiltInRegistries.BLOCK.getOptional(rl);
            if (b.isPresent() && !b.get().defaultBlockState().isAir() && !ok.contains(id)) ok.add(id);
        }
        if (ok.isEmpty()) ok.add("minecraft:stone");
        blockIds = ok;
    }

    public static ArenaCfg pickArena() {
        List<ArenaCfg> good = new ArrayList<>();
        for (ArenaCfg a : arenas.values()) if (a.complete()) good.add(a);
        if (good.isEmpty()) return null;
        for (ArenaCfg a : good) if (a.name.equalsIgnoreCase(game.defaultArena)) return a;
        return good.get(new Random().nextInt(good.size()));
    }
}
