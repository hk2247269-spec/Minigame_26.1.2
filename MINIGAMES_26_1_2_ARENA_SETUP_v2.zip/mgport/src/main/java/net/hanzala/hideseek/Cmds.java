package net.hanzala.hideseek;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** /hs ... command tree. Player commands only work in the Overworld; admin commands need permission level 2. */
public final class Cmds {
    private Cmds() {}

    static final Map<UUID, String> SELECTED = new HashMap<>();

    static void ok(CommandContext<CommandSourceStack> c, String s) {
        Component m = Util.msg(s);
        c.getSource().sendSuccess(() -> m, false);
    }

    static int fail(CommandContext<CommandSourceStack> c, String s) {
        c.getSource().sendFailure(Util.msg(s));
        return 0;
    }

    /** Player running the command, or null (after telling them why) if not in the Overworld. */
    static ServerPlayer endPlayer(CommandContext<CommandSourceStack> c) {
        ServerPlayer p = c.getSource().getPlayer();
        if (p == null) { fail(c, "This command must be run by a player."); return null; }
        if (!Util.inWorld(p)) {
            fail(c, "Hide & Seek only works in the Overworld.");
            return null;
        }
        return p;
    }

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        LiteralArgumentBuilder<CommandSourceStack> hs = Commands.literal("hs")
                .executes(c -> {
                    ServerPlayer p = c.getSource().getPlayer();
                    if (p == null) return fail(c, "This command must be run by a player.");
                    if (!Util.inWorld(p)) return fail(c, "Hide & Seek only works in the Overworld.");
                    Gui.openMain(p); // the Hide & Seek menu (the games list is /mg)
                    return 1;
                })
                .then(Commands.literal("join").executes(c -> {
                    ServerPlayer p = endPlayer(c); if (p == null) return 0;
                    String err = Game.join(p);
                    return err == null ? 1 : fail(c, err);
                }))
                .then(Commands.literal("leave").executes(c -> {
                    ServerPlayer p = endPlayer(c); if (p == null) return 0;
                    if (!Game.inGame(p)) return fail(c, "You are not in a game.");
                    Game.leave(p);
                    return 1;
                }))
                .then(Commands.literal("stats").executes(c -> { ServerPlayer p = endPlayer(c); if (p == null) return 0; Gui.openStats(p); return 1; }))
                .then(Commands.literal("leaderboard").executes(c -> { ServerPlayer p = endPlayer(c); if (p == null) return 0; Gui.openBoard(p); return 1; }))
                .then(Commands.literal("results").executes(c -> { ServerPlayer p = endPlayer(c); if (p == null) return 0; Gui.openResults(p); return 1; }))
                .then(Commands.literal("start").requires(s -> s.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_GAMEMASTER)).executes(c -> {
                    Game g = Game.current;
                    if (g == null) return fail(c, "No game is open. Players must /hs join first.");
                    if (!g.forceStart(Cfg.game.forceStartMinPlayers))
                        return fail(c, "Cannot start: need " + Cfg.game.forceStartMinPlayers + "+ players and a match not yet running.");
                    ok(c, "Match started.");
                    return 1;
                }))
                .then(Commands.literal("stop").requires(s -> s.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_GAMEMASTER)).executes(c -> {
                    if (Game.current == null) return fail(c, "No game is running.");
                    Game.shutdown("stopped by an admin.");
                    ok(c, "Match stopped.");
                    return 1;
                }))
                .then(Commands.literal("reload").requires(s -> s.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_GAMEMASTER)).executes(c -> {
                    Cfg.reload();
                    ok(c, "Configuration reloaded (" + Cfg.arenas.size() + " arena(s), " + Cfg.blockIds.size() + " disguise blocks).");
                    return 1;
                }))
                .then(npc())
                .then(setup());
        d.register(hs);
    }

    static LiteralArgumentBuilder<CommandSourceStack> npc() {
        return Commands.literal("npc").requires(s -> s.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_GAMEMASTER))
                .then(Commands.literal("add")
                        .then(Commands.literal("menu").executes(c -> {
                            if (!Hub.spawnNpc(c.getSource())) return fail(c, "Could not spawn the NPC.");
                            ok(c, "NPC placed: right-click it to open the /mg minigames menu.");
                            return 1;
                        })))
                .then(Commands.literal("remove").executes(c -> {
                    if (!Hub.removeNearestNpc(c.getSource())) return fail(c, "No menu NPC within 4 blocks.");
                    ok(c, "Removed the nearest menu NPC.");
                    return 1;
                }));
    }

    static ServerPlayer setupPlayer(CommandContext<CommandSourceStack> c) {
        ServerPlayer p = c.getSource().getPlayer();
        if (p == null) { fail(c, "Run this as a player inside the Overworld."); return null; }
        if (!Util.inWorld(p)) { fail(c, "Arena setup must be done inside the Overworld."); return null; }
        return p;
    }

    static Cfg.ArenaCfg selected(CommandContext<CommandSourceStack> c, ServerPlayer p) {
        String n = SELECTED.get(p.getUUID());
        Cfg.ArenaCfg a = n == null ? null : Cfg.arenas.get(n);
        if (a == null) fail(c, "Select an arena first: /hs setup create <name>  or  /hs setup select <name>");
        return a;
    }

    static LiteralArgumentBuilder<CommandSourceStack> point(String lit, String label) {
        return Commands.literal(lit).executes(c -> {
            ServerPlayer p = setupPlayer(c); if (p == null) return 0;
            Cfg.ArenaCfg a = selected(c, p); if (a == null) return 0;
            Cfg.Loc l = Cfg.Loc.of(p);
            switch (lit) {
                case "lobby" -> a.lobby = l;
                case "hiderspawn" -> a.hiderSpawn = l;
                case "seekerspawn" -> a.seekerSpawn = l;
                case "spectator" -> a.spectatorSpawn = l;
                case "pos1" -> a.boundsA = l;
                case "pos2" -> a.boundsB = l;
                default -> {}
            }
            Cfg.saveArenas();
            ok(c, label + " saved for arena '" + a.name + "'." + (a.complete() ? " Arena is ready to play." : ""));
            return 1;
        });
    }

    static LiteralArgumentBuilder<CommandSourceStack> setup() {
        return Commands.literal("setup").requires(s -> s.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_GAMEMASTER))
                .then(Commands.literal("create").then(Commands.argument("name", StringArgumentType.word()).executes(c -> {
                    ServerPlayer p = setupPlayer(c); if (p == null) return 0;
                    String n = StringArgumentType.getString(c, "name");
                    if (Cfg.arenas.containsKey(n)) return fail(c, "That arena already exists. Use /hs setup select " + n);
                    Cfg.ArenaCfg a = new Cfg.ArenaCfg();
                    a.name = n;
                    Cfg.arenas.put(n, a);
                    SELECTED.put(p.getUUID(), n);
                    Cfg.saveArenas();
                    ok(c, "Arena '" + n + "' created and selected. Now stand where you want and run: lobby, hiderspawn, seekerspawn (optional: spectator, pos1, pos2).");
                    return 1;
                })))
                .then(Commands.literal("select").then(Commands.argument("name", StringArgumentType.word()).executes(c -> {
                    ServerPlayer p = setupPlayer(c); if (p == null) return 0;
                    String n = StringArgumentType.getString(c, "name");
                    if (!Cfg.arenas.containsKey(n)) return fail(c, "No such arena.");
                    SELECTED.put(p.getUUID(), n);
                    ok(c, "Selected arena '" + n + "'.");
                    return 1;
                })))
                .then(Commands.literal("delete").then(Commands.argument("name", StringArgumentType.word()).executes(c -> {
                    String n = StringArgumentType.getString(c, "name");
                    if (Game.current != null && Game.current.arena.name.equals(n)) return fail(c, "That arena is in use right now.");
                    if (Cfg.arenas.remove(n) == null) return fail(c, "No such arena.");
                    Cfg.saveArenas();
                    ok(c, "Deleted arena '" + n + "'.");
                    return 1;
                })))
                .then(Commands.literal("list").executes(c -> {
                    if (Cfg.arenas.isEmpty()) { ok(c, "No arenas yet."); return 1; }
                    for (Cfg.ArenaCfg a : Cfg.arenas.values())
                        ok(c, a.name + (a.complete() ? "  [ready]" : "  [incomplete]") + (a.hasBounds() ? "  [bounds]" : ""));
                    return 1;
                }))
                .then(Commands.literal("info").executes(c -> {
                    ServerPlayer p = setupPlayer(c); if (p == null) return 0;
                    Cfg.ArenaCfg a = selected(c, p); if (a == null) return 0;
                    ok(c, a.name + ": lobby=" + (a.lobby != null) + " hiderSpawn=" + (a.hiderSpawn != null)
                            + " seekerSpawn=" + (a.seekerSpawn != null) + " spectator=" + (a.spectatorSpawn != null)
                            + " bounds=" + a.hasBounds());
                    return 1;
                }))
                .then(Commands.literal("clearbounds").executes(c -> {
                    ServerPlayer p = setupPlayer(c); if (p == null) return 0;
                    Cfg.ArenaCfg a = selected(c, p); if (a == null) return 0;
                    a.boundsA = null; a.boundsB = null;
                    Cfg.saveArenas();
                    ok(c, "Bounds cleared.");
                    return 1;
                }))
                .then(point("lobby", "Lobby"))
                .then(point("hiderspawn", "Hider spawn"))
                .then(point("seekerspawn", "Seeker spawn"))
                .then(point("spectator", "Spectator spawn"))
                .then(point("pos1", "Bounds corner 1"))
                .then(point("pos2", "Bounds corner 2"));
    }
}
