package net.hanzala.hideseek;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * A disguise is a vanilla block_display entity that follows the (invisible) hider.
 * Vanilla clients render it, so players need NO client mod.
 */
public final class Disguise {
    private Disguise() {}

    public static final String TAG = "hs_disguise";
    /** UUIDs of disguises that belong to the running game. Any other tagged entity is a leftover and is removed. */
    public static final Set<UUID> ACTIVE = new HashSet<>();

    static void run(ServerLevel lvl, String cmd) {
        MinecraftServer s = lvl.getServer();
        s.getCommands().performPrefixedCommand(s.createCommandSourceStack().withLevel(lvl).withSuppressedOutput(), cmd);
    }

    public static Display.BlockDisplay spawn(ServerLevel lvl, ServerPlayer p, String blockId) {
        UUID id = UUID.randomUUID();
        ACTIVE.add(id);
        long m = id.getMostSignificantBits(), l = id.getLeastSignificantBits();
        String cmd = String.format(Locale.ROOT,
                "summon minecraft:block_display %.3f %.3f %.3f {UUID:[I;%d,%d,%d,%d],block_state:{Name:\"%s\"},Tags:[\"%s\"],teleport_duration:2,view_range:1.5f}",
                p.getX() - 0.5, p.getY(), p.getZ() - 0.5,
                (int) (m >> 32), (int) m, (int) (l >> 32), (int) l, blockId, TAG);
        run(lvl, cmd);
        Entity e = lvl.getEntity(id);
        return e instanceof Display.BlockDisplay d ? d : null;
    }

    public static void setBlock(Display.BlockDisplay d, String blockId) {
        if (d == null || d.isRemoved() || !(d.level() instanceof ServerLevel lvl)) return;
        run(lvl, "data merge entity " + d.getUUID() + " {block_state:{Name:\"" + blockId + "\"}}");
    }

    public static void remove(Display.BlockDisplay d) {
        if (d == null) return;
        ACTIVE.remove(d.getUUID());
        if (!d.isRemoved()) d.discard();
    }
}
