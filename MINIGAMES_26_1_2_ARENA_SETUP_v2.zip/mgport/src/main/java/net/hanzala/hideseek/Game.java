package net.hanzala.hideseek;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.Team;

import java.util.*;

/** One Hide & Seek match: lobby -> countdown -> hiding -> seeking -> results. Lives in the Overworld (arena coordinates are Overworld coordinates). */
public final class Game {
    public enum State { WAITING, COUNTDOWN, HIDING, SEEKING, ENDED }
    public enum Side { NONE, HIDER, SEEKER }

    public static Game current;
    public static Result lastResult;
    static final Random RNG = new Random();
    static final Map<UUID, String[]> PREFS = new HashMap<>(); // [disguise, hiderAbility, seekerAbility]

    public static final class Result {
        public String title, map;
        public int seconds;
        public final List<String[]> rows = new ArrayList<>();
    }

    public static final class PD {
        final UUID id;
        final String name;
        Side side = Side.NONE;
        boolean alive = true;
        int kills;
        Display.BlockDisplay display;
        double lx = Double.NaN, ly, lz;
        long vanishUntil, glowUntil, lastUse = -1;
        final Map<String, Long> cd = new HashMap<>();
        final String[] hud = new String[Hud.LINES];
        boolean hudOn;

        PD(ServerPlayer p) {
            id = p.getUUID();
            name = p.getName().getString();
        }
    }

    record Plan(boolean won, int kills, boolean survived) {}

    final MinecraftServer server;
    /** The world the game is played in (the Overworld; the field keeps its old name to keep the engine code unchanged). */
    final ServerLevel end;
    final Cfg.ArenaCfg arena;
    public State state = State.WAITING;
    public int secs;
    public long tick;
    public final Map<UUID, PD> players = new LinkedHashMap<>();
    final Map<Long, UUID> decoys = new HashMap<>();
    final Map<UUID, Plan> plans = new HashMap<>();
    PlayerTeam hiderTeam, seekerTeam;
    long matchStartTick;

    Game(MinecraftServer s, ServerLevel end, Cfg.ArenaCfg a) {
        this.server = s;
        this.end = end;
        this.arena = a;
    }

    // ================================================================= static helpers
    public static String[] pref(UUID id) {
        return PREFS.computeIfAbsent(id, k -> new String[]{Cfg.blockIds.get(RNG.nextInt(Cfg.blockIds.size())), "speed", "radar"});
    }

    /** Read-only info for the /mg adapter. */
    public String arenaName() { return arena.name; }
    public int playerCount() { return players.size(); }
    public boolean joinable() {
        return (state == State.WAITING || state == State.COUNTDOWN) && players.size() < Cfg.game.maxPlayers;
    }

    public static boolean inGame(ServerPlayer p) {
        return current != null && current.players.containsKey(p.getUUID());
    }

    public static boolean canChangeDisguise(ServerPlayer p) {
        Game g = current;
        if (g == null || !g.players.containsKey(p.getUUID())) return true;
        if (g.state == State.SEEKING) return Cfg.game.allowDisguiseChangeWhileSeeking;
        return true;
    }

    public static boolean canChangeAbility(ServerPlayer p) {
        Game g = current;
        if (g == null || !g.players.containsKey(p.getUUID())) return true;
        return g.state == State.WAITING || g.state == State.COUNTDOWN || g.state == State.ENDED;
    }

    public static void setDisguise(ServerPlayer p, String id) {
        pref(p.getUUID())[0] = id;
        Game g = current;
        if (g == null) return;
        PD pd = g.players.get(p.getUUID());
        if (pd != null && pd.side == Side.HIDER && pd.alive && pd.display != null) Disguise.setBlock(pd.display, id);
    }

    public static String join(ServerPlayer p) {
        MinecraftServer server = HideSeekMod.server;
        if (server == null) return "Server not ready.";
        if (!Util.inWorld(p)) return "Hide & Seek only works in the Overworld.";
        if (inGame(p)) return "You are already in the game.";
        if (com.hanzala.minigames.Mg.inInternalGame(p)) return "You are already in another minigame. Leave it first.";
        if (com.hanzala.bedwars.BedWarsMod.GAME.teamOf(p) != null)
            return "You are in BedWars - leave it before joining Hide & Seek.";
        if (current != null && current.state != State.WAITING && current.state != State.COUNTDOWN) return "A match is already in progress.";
        if (current != null && current.players.size() >= Cfg.game.maxPlayers) return "The game is full.";
        if (current == null) {
            Cfg.ArenaCfg a = Cfg.pickArena();
            if (a == null) return "No arena is configured yet. An admin must set one up with /hs setup.";
            current = new Game(server, server.overworld(), a);
        }
        current.add(p);
        return null;
    }

    public static void leave(ServerPlayer p) {
        if (current != null) current.remove(p, "You left the game.");
        else p.sendSystemMessage(Util.msg("You are not in a game."));
    }

    public static void shutdown(String why) {
        if (current != null) current.abort(why);
    }

    // ================================================================= membership
    ServerPlayer player(PD pd) {
        return server.getPlayerList().getPlayer(pd.id);
    }

    void tp(ServerPlayer p, Cfg.Loc l) {
        p.teleportTo(end, l.x, l.y, l.z, Set.<Relative>of(), l.yaw, l.pitch, true);
    }

    void broadcast(String s) {
        Component c = Util.msg(s);
        for (PD pd : players.values()) {
            ServerPlayer p = player(pd);
            if (p != null) p.sendSystemMessage(c);
        }
    }

    void add(ServerPlayer p) {
        Backup.save(p);
        PD pd = new PD(p);
        players.put(pd.id, pd);
        p.getInventory().clearContent();
        p.removeAllEffects();
        p.setGameMode(GameType.ADVENTURE);
        p.setHealth(p.getMaxHealth());
        p.getFoodData().setFoodLevel(20);
        tp(p, arena.lobby);
        applyLoadout(p, pd);
        Hud.show(p, pd);
        broadcast(pd.name + " joined (" + players.size() + "/" + Cfg.game.maxPlayers + ")");
        if (state == State.WAITING && players.size() >= Cfg.game.minPlayers) {
            state = State.COUNTDOWN;
            secs = Cfg.game.countdownSeconds;
            broadcast("Enough players! Starting in " + secs + " seconds.");
        }
        Hud.refresh(this);
    }

    void remove(ServerPlayer p, String why) {
        PD pd = players.remove(p.getUUID());
        if (pd == null) return;
        dropDisguise(pd);
        if (hiderTeam != null) end.getServer().getScoreboard().removePlayerFromTeam(p.getScoreboardName(), hiderTeam);
        if (seekerTeam != null) end.getServer().getScoreboard().removePlayerFromTeam(p.getScoreboardName(), seekerTeam);
        Hud.hide(p, pd);
        boolean restored = false;
        try {
            restored = Backup.restore(p, server);
            if (!restored) p.setGameMode(GameType.SURVIVAL);
        } catch (Exception e) {
            HideSeekMod.LOG.error("restore failed", e);
        }
        // everybody ends up in the ONE common lobby with the menu compass
        if (com.hanzala.minigames.Lobby.available() || !restored) com.hanzala.minigames.Lobby.send(p);
        com.hanzala.minigames.Lobby.giveMenuItem(p);
        grantRewards(p);
        p.sendSystemMessage(Util.msg(why));
        if (!players.isEmpty()) broadcast(pd.name + " left the game.");
        afterChange();
    }

    void afterChange() {
        if (players.isEmpty()) {
            close();
            return;
        }
        switch (state) {
            case COUNTDOWN -> {
                if (players.size() < Cfg.game.minPlayers) {
                    state = State.WAITING;
                    broadcast("Not enough players - countdown cancelled.");
                }
            }
            case HIDING, SEEKING -> checkWin();
            default -> {}
        }
        Hud.refresh(this);
    }

    void abort(String why) {
        plans.clear();
        for (PD pd : new ArrayList<>(players.values())) {
            ServerPlayer p = player(pd);
            if (p != null) remove(p, "Match cancelled: " + why);
        }
        close();
    }

    void close() {
        cleanupWorld();
        Scoreboard sb = server.getScoreboard();
        if (hiderTeam != null) { sb.removePlayerTeam(hiderTeam); hiderTeam = null; }
        if (seekerTeam != null) { sb.removePlayerTeam(seekerTeam); seekerTeam = null; }
        if (current == this) current = null;
    }

    void cleanupWorld() {
        for (PD pd : players.values()) dropDisguise(pd);
        for (Long key : decoys.keySet()) {
            BlockPos pos = BlockPos.of(key);
            if (end.getBlockState(pos).getBlock() != Blocks.AIR) end.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
        }
        decoys.clear();
    }

    void dropDisguise(PD pd) {
        if (pd.display != null) {
            Disguise.remove(pd.display);
            pd.display = null;
        }
    }

    // ================================================================= counts
    public int hidersAlive() {
        int n = 0;
        for (PD pd : players.values()) if (pd.side == Side.HIDER && pd.alive) n++;
        return n;
    }

    public int seekersCount() {
        int n = 0;
        for (PD pd : players.values()) if (pd.side == Side.SEEKER) n++;
        return n;
    }

    public boolean nearParticipant(Entity e) {
        for (PD pd : players.values()) {
            ServerPlayer p = player(pd);
            if (p != null && p.distanceToSqr(e) < 25) return true;
        }
        return false;
    }

    // ================================================================= loadouts
    static ItemStack make(String act) {
        return switch (act) {
            case "menu" -> Util.icon(Items.NETHER_STAR, "Hide & Seek Menu", ChatFormatting.LIGHT_PURPLE, "Right-click to open");
            case "leave" -> Util.icon(Items.RED_DYE, "Leave Game", ChatFormatting.RED, "Right-click to leave");
            default -> Util.icon(Gui.abItem(act), Gui.abName(act), act.startsWith("s:") ? ChatFormatting.RED : ChatFormatting.LIGHT_PURPLE,
                    Gui.abDesc(act), "Right-click to use");
        };
    }

    static String actionOf(Item it) {
        if (it == Items.NETHER_STAR) return "menu";
        if (it == Items.RED_DYE) return "leave";
        if (it == Items.SUGAR) return "h:speed";
        if (it == Items.ENDER_EYE) return "h:vanish";
        if (it == Items.CLAY_BALL) return "h:decoy";
        if (it == Items.COMPASS) return "s:radar";
        if (it == Items.GLOWSTONE_DUST) return "s:pulse";
        if (it == Items.FEATHER) return "s:speed";
        return null;
    }

    Map<Integer, String> expected(PD pd) {
        Map<Integer, String> m = new HashMap<>();
        boolean lobby = state == State.WAITING || state == State.COUNTDOWN || state == State.ENDED;
        if (lobby) {
            m.put(3, "menu");
            m.put(5, "leave");
        } else if (pd.side == Side.HIDER && pd.alive) {
            m.put(0, "h:" + pref(pd.id)[1]);
            m.put(1, "menu");
        } else if (pd.side == Side.SEEKER) {
            m.put(0, "s:" + pref(pd.id)[2]);
            m.put(1, "menu");
        }
        return m;
    }

    void applyLoadout(ServerPlayer p, PD pd) {
        Map<Integer, String> exp = expected(pd);
        Inventory inv = p.getInventory();
        boolean changed = false;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            String want = exp.get(i);
            ItemStack have = inv.getItem(i);
            if (want == null) {
                if (!have.isEmpty()) { inv.setItem(i, ItemStack.EMPTY); changed = true; }
            } else if (!have.is(make(want).getItem())) {
                inv.setItem(i, make(want));
                changed = true;
            }
        }
        if (changed) p.inventoryMenu.broadcastChanges();
    }

    // ================================================================= effects helpers
    static void eff(ServerPlayer p, Holder<MobEffect> e, int ticks, int amp) {
        p.addEffect(new MobEffectInstance(e, ticks, amp, false, false, false));
    }

    PlayerTeam team(String name, ChatFormatting color, boolean seeFriendlyInvisibles) {
        Scoreboard sb = server.getScoreboard();
        PlayerTeam t = sb.getPlayerTeam(name);
        if (t == null) t = sb.addPlayerTeam(name);
        t.setColor(color);
        t.setNameTagVisibility(Team.Visibility.NEVER);
        t.setCollisionRule(Team.CollisionRule.NEVER);
        t.setSeeFriendlyInvisibles(seeFriendlyInvisibles);
        return t;
    }

    // ================================================================= match start
    public boolean forceStart(int minPlayers) {
        if ((state != State.WAITING && state != State.COUNTDOWN) || players.size() < minPlayers) return false;
        startMatch();
        return true;
    }

    void startMatch() {
        List<PD> list = new ArrayList<>(players.values());
        Collections.shuffle(list, RNG);
        int seekers = Math.max(1, (int) Math.round(list.size() / (double) Math.max(1, Cfg.game.playersPerSeeker)));
        seekers = Math.min(seekers, Math.max(1, list.size() - 1));
        hiderTeam = team("hs_hiders", ChatFormatting.LIGHT_PURPLE, false);
        seekerTeam = team("hs_seekers", ChatFormatting.RED, true);
        Scoreboard sb = server.getScoreboard();
        int freeze = (Cfg.game.hidingSeconds + 1) * 20;
        for (int i = 0; i < list.size(); i++) {
            PD pd = list.get(i);
            ServerPlayer p = player(pd);
            if (p == null) continue;
            pd.side = i < seekers ? Side.SEEKER : Side.HIDER;
            pd.alive = true;
            pd.kills = 0;
            pd.cd.clear();
            p.removeAllEffects();
            p.setGameMode(GameType.ADVENTURE);
            p.setHealth(p.getMaxHealth());
            if (pd.side == Side.SEEKER) {
                sb.addPlayerToTeam(p.getScoreboardName(), seekerTeam);
                tp(p, arena.seekerSpawn);
                eff(p, MobEffects.BLINDNESS, freeze, 0);
                eff(p, MobEffects.SLOWNESS, freeze, 6);
                eff(p, MobEffects.JUMP_BOOST, freeze, 128);
                Hud.title(p, Util.txt("SEEKER", ChatFormatting.RED), Util.txt("Wait for the hiding time to end", ChatFormatting.GRAY), 5, 50, 10);
            } else {
                sb.addPlayerToTeam(p.getScoreboardName(), hiderTeam);
                tp(p, arena.hiderSpawn);
                eff(p, MobEffects.INVISIBILITY, 20 * 3600, 0);
                pd.lx = Double.NaN;
                pd.display = Disguise.spawn(end, p, pref(pd.id)[0]);
                Hud.title(p, Util.txt("HIDER", ChatFormatting.LIGHT_PURPLE), Util.txt("Hide as " + Util.pretty(pref(pd.id)[0]) + "!", ChatFormatting.GRAY), 5, 50, 10);
            }
            applyLoadout(p, pd);
            Util.snd(p, SoundEvents.ENDER_DRAGON_GROWL, 0.6f, 1f);
        }
        state = State.HIDING;
        secs = Cfg.game.hidingSeconds;
        matchStartTick = tick;
        broadcast(seekers + " seeker(s) chosen. Hiders have " + secs + " seconds to hide!");
        Hud.refresh(this);
    }

    void release() {
        state = State.SEEKING;
        secs = Cfg.game.matchSeconds;
        for (PD pd : players.values()) {
            ServerPlayer p = player(pd);
            if (p == null) continue;
            if (pd.side == Side.SEEKER) {
                p.removeEffect(MobEffects.BLINDNESS);
                p.removeEffect(MobEffects.SLOWNESS);
                p.removeEffect(MobEffects.JUMP_BOOST);
                Hud.title(p, Util.txt("SEEK!", ChatFormatting.RED), Util.txt("Find every hider", ChatFormatting.GRAY), 3, 30, 10);
            } else if (pd.alive) {
                Hud.title(p, Util.txt("SEEKERS RELEASED", ChatFormatting.LIGHT_PURPLE), Util.txt("Stay hidden!", ChatFormatting.GRAY), 3, 30, 10);
            }
            Util.snd(p, SoundEvents.ENDER_DRAGON_GROWL, 0.8f, 0.8f);
        }
        broadcast("The seekers have been released!");
    }

    // ================================================================= ticking
    public void tick() {
        tick++;
        if (state == State.HIDING || state == State.SEEKING) tickDisguises();
        if (tick % 4 == 0) Hud.animate(this);
        if (tick % 20 == 0) second();
    }

    void tickDisguises() {
        for (PD pd : players.values()) {
            if (pd.side != Side.HIDER || !pd.alive) continue;
            ServerPlayer p = player(pd);
            if (p == null) continue;
            if (pd.vanishUntil > 0 && tick >= pd.vanishUntil) {
                pd.vanishUntil = 0;
                pd.display = Disguise.spawn(end, p, pref(pd.id)[0]);
                pd.lx = Double.NaN;
            }
            if (pd.glowUntil > 0 && tick >= pd.glowUntil) {
                pd.glowUntil = 0;
                if (pd.display != null) pd.display.setGlowingTag(false);
            }
            Display.BlockDisplay d = pd.display;
            if (d == null) continue;
            if (d.isRemoved()) {
                pd.display = Disguise.spawn(end, p, pref(pd.id)[0]);
                pd.lx = Double.NaN;
                continue;
            }
            double x = p.getX(), y = p.getY(), z = p.getZ();
            if (x != pd.lx || y != pd.ly || z != pd.lz) {
                d.setPos(x - 0.5, y, z - 0.5);
                pd.lx = x; pd.ly = y; pd.lz = z;
            }
        }
    }

    void second() {
        // drop players that vanished or left the Overworld
        for (PD pd : new ArrayList<>(players.values())) {
            ServerPlayer p = player(pd);
            if (p == null) {
                players.remove(pd.id);
                dropDisguise(pd);
            } else if (!Util.inWorld(p)) {
                remove(p, "You left the Overworld, so you were removed from the game.");
            }
        }
        if (current != this) return;
        if (players.isEmpty()) { close(); return; }

        switch (state) {
            case WAITING -> {}
            case COUNTDOWN -> {
                if (players.size() < Cfg.game.minPlayers) {
                    state = State.WAITING;
                } else {
                    secs--;
                    if (secs <= 0) startMatch();
                    else countdownFx();
                }
            }
            case HIDING -> {
                secs--;
                if (secs <= 0) release();
                else hidingFx();
            }
            case SEEKING -> {
                secs--;
                if (secs <= 0) finishMatch("HIDERS");
                else if (secs <= 10) {
                    for (PD pd : players.values()) {
                        ServerPlayer p = player(pd);
                        if (p != null) Util.snd(p, SoundEvents.EXPERIENCE_ORB_PICKUP, 0.7f, 0.6f);
                    }
                }
            }
            case ENDED -> {
                secs--;
                if (secs <= 0) finalizeEnd();
            }
        }
        if (current != this) return;

        boolean live = state == State.HIDING || state == State.SEEKING;
        for (PD pd : players.values()) {
            ServerPlayer p = player(pd);
            if (p == null) continue;
            applyLoadout(p, pd);
            p.getFoodData().setFoodLevel(20);
            if (live && (pd.side == Side.SEEKER || pd.alive)) keepInArena(p);
        }
        Hud.refresh(this);
    }

    void keepInArena(ServerPlayer p) {
        double minY = Math.min(arena.lobby.y, arena.hiderSpawn.y) - 48;
        if (p.getY() < minY || !arena.inside(p.getX(), p.getY(), p.getZ())) {
            PD pd = players.get(p.getUUID());
            tp(p, pd != null && pd.side == Side.SEEKER ? arena.seekerSpawn : arena.hiderSpawn);
            p.sendSystemMessage(Util.msg("Stay inside the arena!"));
        }
    }

    void countdownFx() {
        for (PD pd : players.values()) {
            ServerPlayer p = player(pd);
            if (p == null) continue;
            if (secs <= 5) {
                Hud.title(p, Util.txt(String.valueOf(secs), ChatFormatting.LIGHT_PURPLE), Util.txt("Get ready", ChatFormatting.GRAY), 0, 15, 5);
                Util.snd(p, SoundEvents.EXPERIENCE_ORB_PICKUP, 1f, 1f + (5 - secs) * 0.1f);
            } else {
                Hud.bar(p, Util.txt("Match starts in " + secs + "s", ChatFormatting.LIGHT_PURPLE));
            }
        }
    }

    void hidingFx() {
        for (PD pd : players.values()) {
            ServerPlayer p = player(pd);
            if (p == null) continue;
            if (pd.side == Side.SEEKER) {
                Hud.bar(p, Util.txt("Frozen - released in " + secs + "s", ChatFormatting.RED));
                if (secs <= 5) Hud.title(p, Util.txt(String.valueOf(secs), ChatFormatting.RED), Component.empty(), 0, 15, 5);
            } else if (pd.alive) {
                Hud.bar(p, Util.txt("Hide! Seekers released in " + secs + "s", ChatFormatting.LIGHT_PURPLE));
            }
            if (secs <= 5) Util.snd(p, SoundEvents.EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
        }
    }

    // ================================================================= win / end
    void checkWin() {
        if (state != State.HIDING && state != State.SEEKING) return;
        if (seekersCount() == 0) {
            abort("all seekers left.");
            return;
        }
        if (hidersAlive() == 0) {
            if (state == State.HIDING) abort("all hiders left.");
            else finishMatch("SEEKERS");
        }
    }

    void finishMatch(String winner) {
        if (state == State.ENDED) return;
        boolean hidersWon = winner.equals("HIDERS");
        state = State.ENDED;
        secs = Cfg.game.resultsSeconds;
        cleanupWorld();

        Result r = new Result();
        r.title = hidersWon ? "HIDERS WIN" : "SEEKERS WIN";
        r.map = arena.name;
        r.seconds = (int) ((tick - matchStartTick) / 20);
        List<PD> sorted = new ArrayList<>(players.values());
        sorted.sort((a, b) -> Integer.compare(b.kills, a.kills));
        for (PD pd : sorted) {
            boolean seeker = pd.side == Side.SEEKER;
            boolean won = seeker != hidersWon;
            boolean survived = !seeker && pd.alive;
            r.rows.add(new String[]{pd.name, seeker ? "Seeker" : "Hider", String.valueOf(pd.kills),
                    won ? (survived ? "Winner - survived" : "Winner") : (seeker || pd.alive ? "Lost" : "Caught")});
            plans.put(pd.id, new Plan(won, pd.kills, survived));
            Stats.Rec s = Stats.get(pd.id, pd.name);
            s.games++;
            s.kills += pd.kills;
            if (won) { s.wins++; if (seeker) s.seekerWins++; else s.hiderWins++; }
            if (!seeker && !pd.alive) s.caught++;
            if (survived && hidersWon) s.survived++;
        }
        Stats.save();
        lastResult = r;

        Scoreboard sb = server.getScoreboard();
        if (hiderTeam != null) { sb.removePlayerTeam(hiderTeam); hiderTeam = null; }
        if (seekerTeam != null) { sb.removePlayerTeam(seekerTeam); seekerTeam = null; }

        for (PD pd : players.values()) {
            ServerPlayer p = player(pd);
            if (p == null) continue;
            boolean won = (pd.side == Side.SEEKER) != hidersWon;
            p.removeAllEffects();
            p.setGameMode(GameType.ADVENTURE);
            tp(p, arena.lobby);
            applyLoadout(p, pd);
            Hud.title(p, Util.txt(r.title, hidersWon ? ChatFormatting.LIGHT_PURPLE : ChatFormatting.RED),
                    Util.txt(won ? "Victory!" : "Better luck next time", ChatFormatting.GRAY), 5, 70, 20);
            Util.snd(p, won ? SoundEvents.PLAYER_LEVELUP : SoundEvents.ENDERMAN_DEATH, 1f, 1f);
            Util.fx(end, ParticleTypes.END_ROD, p.getX(), p.getY() + 1, p.getZ(), 30, 0.6, 0.05);
        }
        broadcast(r.title + "! Results are in /hs results.");
        Sched.later(() -> {
            if (current != this) return;
            for (PD pd : players.values()) {
                ServerPlayer p = player(pd);
                if (p != null && p.containerMenu == p.inventoryMenu) Gui.openResults(p);
            }
        });
    }

    void finalizeEnd() {
        for (PD pd : new ArrayList<>(players.values())) {
            ServerPlayer p = player(pd);
            if (p != null) remove(p, "Thanks for playing!");
        }
        close();
    }

    // ================================================================= rewards (each player at most once)
    static ItemStack stackOf(Cfg.ItemRw r, int mult) {
        Identifier rl = Identifier.tryParse(r.item);
        if (rl == null) return ItemStack.EMPTY;
        Optional<Item> it = BuiltInRegistries.ITEM.getOptional(rl);
        if (it.isEmpty() || it.get() == Items.AIR) return ItemStack.EMPTY;
        return new ItemStack(it.get(), Math.max(1, Math.min(r.count * mult, 64 * 4)));
    }

    void give(ServerPlayer p, List<Cfg.ItemRw> list, int mult) {
        for (Cfg.ItemRw r : list) {
            ItemStack st = stackOf(r, mult);
            if (st.isEmpty()) continue;
            if (!p.getInventory().add(st)) p.drop(st, false);
        }
    }

    void cmd(ServerPlayer p, String c) {
        server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(),
                c.replace("%player%", p.getName().getString()));
    }

    void grantRewards(ServerPlayer p) {
        Plan plan = plans.remove(p.getUUID()); // removing first guarantees no duplicate payout
        if (plan == null) return;
        Cfg.RewardCfg rc = Cfg.rewards;
        give(p, rc.participationItems, 1);
        for (String c : rc.participationCommands) cmd(p, c);
        if (plan.won()) {
            give(p, rc.winnerItems, 1);
            if (rc.winnerXpLevels > 0) p.giveExperienceLevels(rc.winnerXpLevels);
            for (String c : rc.winnerCommands) cmd(p, c);
        }
        if (plan.survived()) give(p, rc.survivorItems, 1);
        if (plan.kills() > 0) give(p, rc.perKillItems, plan.kills());
        p.inventoryMenu.broadcastChanges();
        p.sendSystemMessage(Util.msg("Rewards received."));
    }

    // ================================================================= combat
    /** Returns true when the attack must be cancelled. */
    public boolean onAttack(ServerPlayer atk, Entity target) {
        PD a = players.get(atk.getUUID());
        PD v = target instanceof ServerPlayer tp ? players.get(tp.getUUID()) : null;
        if (a == null && v == null) return false;
        if (a != null && v != null && state == State.SEEKING && a.side == Side.SEEKER && v.side == Side.HIDER && v.alive) {
            eliminate(v, a);
        }
        return true;
    }

    void eliminate(PD v, PD killer) {
        ServerPlayer vp = player(v);
        if (vp == null) return;
        v.alive = false;
        killer.kills++;
        dropDisguise(v);
        v.vanishUntil = 0;
        double x = vp.getX(), y = vp.getY() + 0.8, z = vp.getZ();
        Util.fx(end, ParticleTypes.PORTAL, x, y, z, 120, 0.5, 0.8);
        Util.fx(end, ParticleTypes.END_ROD, x, y, z, 40, 0.4, 0.15);
        Util.fx(end, ParticleTypes.REVERSE_PORTAL, x, y, z, 60, 0.4, 0.3);
        end.playSound(null, x, y, z, SoundEvents.ENDERMAN_DEATH, SoundSource.PLAYERS, 1f, 1f);
        vp.removeAllEffects();
        vp.getInventory().clearContent();
        vp.setGameMode(GameType.SPECTATOR);
        Hud.title(vp, Util.txt("ELIMINATED", ChatFormatting.RED), Util.txt("Found by " + killer.name, ChatFormatting.GRAY), 3, 50, 15);
        ServerPlayer kp = player(killer);
        if (kp != null) {
            Hud.bar(kp, Util.txt("Eliminated " + v.name + "! (" + killer.kills + ")", ChatFormatting.GOLD));
            Util.snd(kp, SoundEvents.PLAYER_LEVELUP, 0.8f, 1.4f);
        }
        broadcast(v.name + " was found by " + killer.name + "! " + hidersAlive() + " hider(s) left.");
        Hud.refresh(this);
        checkWin();
    }

    /** Participants can never break/place/interact with blocks. Seekers who break a decoy get stunned. */
    public boolean onAttackBlock(ServerPlayer p, BlockPos pos) {
        PD pd = players.get(p.getUUID());
        if (pd == null) return false;
        if (pd.side == Side.SEEKER && decoys.containsKey(pos.asLong())) {
            decoys.remove(pos.asLong());
            end.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
            Util.fx(end, ParticleTypes.WITCH, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 30, 0.4, 0.1);
            eff(p, MobEffects.BLINDNESS, 40, 0);
            eff(p, MobEffects.SLOWNESS, 60, 2);
            Hud.title(p, Util.txt("DECOY!", ChatFormatting.LIGHT_PURPLE), Util.txt("You wasted time on a fake block", ChatFormatting.GRAY), 0, 30, 10);
            Util.snd(p, SoundEvents.ENDERMAN_TELEPORT, 1f, 0.7f);
        }
        return true;
    }

    // ================================================================= items / abilities
    /** Returns true if the player is a participant (the vanilla action is then always cancelled). */
    public boolean onUse(ServerPlayer p, ItemStack st) {
        PD pd = players.get(p.getUUID());
        if (pd == null) return false;
        String act = actionOf(st.getItem());
        if (act == null || pd.lastUse == tick) return true;
        pd.lastUse = tick;
        switch (act) {
            case "menu" -> Sched.later(() -> { if (players.containsKey(p.getUUID())) Gui.openMain(p); });
            case "leave" -> Sched.later(() -> { if (players.containsKey(p.getUUID())) remove(p, "You left the game."); });
            default -> {
                boolean hiderItem = act.startsWith("h:");
                boolean usableState = hiderItem ? (state == State.HIDING || state == State.SEEKING) : state == State.SEEKING;
                if (!usableState) { Hud.bar(p, Util.txt("Not usable right now", ChatFormatting.GRAY)); return true; }
                if (hiderItem != (pd.side == Side.HIDER) || (hiderItem && !pd.alive)) return true;
                ability(p, pd, act);
            }
        }
        return true;
    }

    boolean cooldown(ServerPlayer p, PD pd, String act, Cfg.Ab a) {
        Long until = pd.cd.get(act);
        if (until != null && until > tick) {
            Hud.bar(p, Util.txt(Gui.abName(act) + " ready in " + ((until - tick + 19) / 20) + "s", ChatFormatting.RED));
            return false;
        }
        pd.cd.put(act, tick + a.cooldownSeconds * 20L);
        return true;
    }

    void ability(ServerPlayer p, PD pd, String act) {
        Cfg.Ab a = Cfg.abilities.get(act);
        switch (act) {
            case "h:speed", "s:speed" -> {
                if (!cooldown(p, pd, act, a)) return;
                eff(p, MobEffects.SPEED, a.durationSeconds * 20, a.amplifier);
                Util.fx(end, ParticleTypes.PORTAL, p.getX(), p.getY() + 0.5, p.getZ(), 30, 0.4, 0.4);
                Util.snd(p, SoundEvents.ENDERMAN_TELEPORT, 0.6f, 1.5f);
            }
            case "h:vanish" -> {
                if (pd.display == null || !cooldown(p, pd, act, a)) return;
                dropDisguise(pd);
                pd.vanishUntil = tick + a.durationSeconds * 20L;
                Util.fx(end, ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 0.5, p.getZ(), 40, 0.4, 0.2);
                Util.snd(p, SoundEvents.ENDERMAN_TELEPORT, 0.6f, 0.8f);
            }
            case "h:decoy" -> placeDecoy(p, pd, a);
            case "s:radar" -> {
                if (!cooldown(p, pd, act, a)) return;
                PD best = null; ServerPlayer bp = null; double bd = Double.MAX_VALUE;
                for (PD o : players.values()) {
                    if (o.side != Side.HIDER || !o.alive) continue;
                    ServerPlayer op = player(o);
                    if (op == null) continue;
                    double d = p.distanceTo(op);
                    if (d <= a.range && d < bd) { bd = d; best = o; bp = op; }
                }
                if (best == null) {
                    Hud.bar(p, Util.txt("Radar: no hiders within " + a.range + " blocks", ChatFormatting.GRAY));
                } else {
                    double dx = bp.getX() - p.getX(), dz = bp.getZ() - p.getZ();
                    double tyaw = Math.toDegrees(Math.atan2(-dx, dz));
                    double rel = ((tyaw - p.getYRot()) % 360 + 360) % 360;
                    String[] arrows = {"\u2191", "\u2197", "\u2192", "\u2198", "\u2193", "\u2199", "\u2190", "\u2196"};
                    String ar = arrows[(int) Math.round(rel / 45.0) % 8];
                    Hud.bar(p, Util.txt("RADAR  " + ar + "  " + String.format("%.0f", bd) + " blocks", ChatFormatting.LIGHT_PURPLE));
                }
                Util.snd(p, SoundEvents.EXPERIENCE_ORB_PICKUP, 0.8f, 0.5f);
            }
            case "s:pulse" -> {
                if (!cooldown(p, pd, act, a)) return;
                int hit = 0;
                for (int i = 0; i < 32; i++) {
                    double ang = i * Math.PI / 16;
                    Util.fx(end, ParticleTypes.END_ROD, p.getX() + Math.cos(ang) * 3, p.getY() + 0.3, p.getZ() + Math.sin(ang) * 3, 1, 0.0, 0.02);
                }
                for (PD o : players.values()) {
                    if (o.side != Side.HIDER || !o.alive || o.display == null) continue;
                    ServerPlayer op = player(o);
                    if (op == null || p.distanceTo(op) > a.radius) continue;
                    o.display.setGlowingTag(true);
                    o.glowUntil = tick + a.durationSeconds * 20L;
                    Hud.bar(op, Util.txt("A reveal pulse exposed you!", ChatFormatting.RED));
                    Util.snd(op, SoundEvents.BEACON_ACTIVATE, 0.8f, 1.5f);
                    hit++;
                }
                Hud.bar(p, Util.txt("Reveal pulse hit " + hit + " hider(s)", ChatFormatting.LIGHT_PURPLE));
                end.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1f, 1.8f);
            }
            default -> {}
        }
    }

    void placeDecoy(ServerPlayer p, PD pd, Cfg.Ab a) {
        int mine = 0;
        for (UUID u : decoys.values()) if (u.equals(pd.id)) mine++;
        if (mine >= a.maxCount) { Hud.bar(p, Util.txt("Decoy limit reached (" + a.maxCount + ")", ChatFormatting.RED)); return; }
        Direction dir = p.getDirection();
        BlockPos pos = p.blockPosition().relative(dir);
        BlockState cur = end.getBlockState(pos);
        if (!cur.isAir() || !end.getEntitiesOfClass(Player.class, new AABB(pos)).isEmpty()
                || !arena.inside(pos.getX(), pos.getY(), pos.getZ())) {
            Hud.bar(p, Util.txt("No room for a decoy there", ChatFormatting.RED));
            return;
        }
        if (!cooldown(p, pd, "h:decoy", a)) return;
        Block b = BuiltInRegistries.BLOCK.getOptional(Identifier.parse(pref(pd.id)[0])).orElse(Blocks.STONE);
        end.setBlock(pos, b.defaultBlockState(), 3);
        decoys.put(pos.asLong(), pd.id);
        Util.fx(end, ParticleTypes.PORTAL, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 25, 0.4, 0.3);
        Util.snd(p, SoundEvents.ENDERMAN_TELEPORT, 0.6f, 1.2f);
    }
}
