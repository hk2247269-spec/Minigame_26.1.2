package net.hanzala.hideseek;

import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Purple/black chest menus (purple + black). Menus are fully server-side: every click is cancelled, so items can
 * never be taken out, and each button runs a handler that re-validates the game state first.
 */
public final class Gui {
    private Gui() {}

    public static final class Menu extends ChestMenu {
        final int rows;
        final Map<Integer, Runnable> acts = new HashMap<>();
        final SimpleContainer box;
        long last;

        Menu(int id, Inventory inv, SimpleContainer box, int rows) {
            super(type(rows), id, inv, box, rows);
            this.rows = rows;
            this.box = box;
        }

        static MenuType<ChestMenu> type(int rows) {
            return switch (rows) {
                case 1 -> MenuType.GENERIC_9x1;
                case 2 -> MenuType.GENERIC_9x2;
                case 3 -> MenuType.GENERIC_9x3;
                case 4 -> MenuType.GENERIC_9x4;
                case 5 -> MenuType.GENERIC_9x5;
                default -> MenuType.GENERIC_9x6;
            };
        }

        void set(int slot, ItemStack s, Runnable r) {
            box.setItem(slot, s);
            if (r != null) acts.put(slot, r);
        }

        void border() {
            int n = rows * 9;
            for (int i = 0; i < n; i++) {
                boolean edge = i < 9 || i >= n - 9 || i % 9 == 0 || i % 9 == 8;
                ItemStack pane = new ItemStack(edge ? Items.PURPLE_STAINED_GLASS_PANE : Items.BLACK_STAINED_GLASS_PANE);
                pane.set(net.minecraft.core.component.DataComponents.CUSTOM_NAME, Component.literal(" "));
                box.setItem(i, pane);
            }
        }

        @Override
        public void clicked(int slot, int button, ContainerInput type, Player player) {
            if (!(player instanceof ServerPlayer sp)) return;
            long now = System.nanoTime();
            if (slot >= 0 && slot < rows * 9 && (type == ContainerInput.PICKUP || type == ContainerInput.QUICK_MOVE)
                    && now - last > 150_000_000L) {
                last = now;
                Runnable r = acts.get(slot);
                if (r != null) {
                    Sched.later(() -> {
                        if (sp.containerMenu == this && Util.inWorld(sp)) r.run();
                        else sp.closeContainer();
                    });
                }
            }
            sendAllDataToRemote(); // undo whatever the client predicted
        }

        @Override
        public ItemStack quickMoveStack(Player p, int i) {
            return ItemStack.EMPTY;
        }
    }

    static void open(ServerPlayer p, String title, int rows, Consumer<Menu> fill) {
        if (!Util.inWorld(p)) {
            p.sendSystemMessage(Util.msg("Hide & Seek only works in the Overworld."));
            return;
        }
        p.openMenu(new SimpleMenuProvider((id, inv, pl) -> {
            Menu m = new Menu(id, inv, new SimpleContainer(rows * 9), rows);
            m.border();
            fill.accept(m);
            return m;
        }, Util.txt(title, ChatFormatting.DARK_PURPLE)));
    }

    // ------------------------------------------------------------------ main menu
    public static void openMain(ServerPlayer p) {
        open(p, "\u2726 Hide & Seek \u2726", 3, m -> {
            m.set(10, Util.icon(Items.END_PORTAL_FRAME, "Join Game", ChatFormatting.LIGHT_PURPLE, "Join or leave the match"), () -> openJoin(p));
            m.set(11, Util.icon(Items.PURPUR_BLOCK, "Block Selection", ChatFormatting.LIGHT_PURPLE, "Choose your hider disguise"), () -> openBlocks(p, 0));
            m.set(12, Util.icon(Items.DRAGON_BREATH, "Ability Selection", ChatFormatting.LIGHT_PURPLE, "Pick your abilities"), () -> openAbilities(p));
            m.set(14, Util.icon(Items.BOOK, "Statistics", ChatFormatting.LIGHT_PURPLE, "Your career stats"), () -> openStats(p));
            m.set(15, Util.icon(Items.END_CRYSTAL, "Leaderboard", ChatFormatting.LIGHT_PURPLE, "Top players"), () -> openBoard(p));
            m.set(16, Util.icon(Items.MAP, "Match Results", ChatFormatting.LIGHT_PURPLE, "Last finished match"), () -> openResults(p));
            m.set(22, Util.icon(Items.BARRIER, "Close", ChatFormatting.GRAY), p::closeContainer);
        });
    }

    // ------------------------------------------------------------------ join
    public static void openJoin(ServerPlayer p) {
        open(p, "Join Game", 3, m -> {
            Game g = Game.current;
            boolean in = Game.inGame(p);
            String status = g == null ? "No match - join to open one" : g.state.name();
            String players = g == null ? "0/" + Cfg.game.maxPlayers : g.players.size() + "/" + Cfg.game.maxPlayers;
            String map = g == null ? "(chosen on start)" : g.arena.name;
            m.set(11, Util.icon(Items.ENDER_EYE, "Match Info", ChatFormatting.LIGHT_PURPLE,
                    "Status: " + status, "Players: " + players, "Map: " + map), null);
            if (!in) {
                m.set(13, Util.icon(Items.END_PORTAL_FRAME, "JOIN", ChatFormatting.GREEN, "Click to join the match"), () -> {
                    String err = Game.join(p);
                    p.closeContainer();
                    if (err != null) p.sendSystemMessage(Util.msg(err));
                });
            } else {
                m.set(15, Util.icon(Items.BARRIER, "LEAVE", ChatFormatting.RED, "Click to leave the match"), () -> {
                    p.closeContainer();
                    Game.leave(p);
                });
            }
            m.set(22, Util.icon(Items.ARROW, "Back", ChatFormatting.GRAY), () -> openMain(p));
        });
    }

    // ------------------------------------------------------------------ blocks
    public static void openBlocks(ServerPlayer p, int page) {
        open(p, "Block Selection", 6, m -> {
            List<String> ids = Cfg.blockIds;
            int pages = Math.max(1, (ids.size() + 44) / 45);
            int pg = Math.max(0, Math.min(page, pages - 1));
            String cur = Game.pref(p.getUUID())[0];
            for (int i = 0; i < 45; i++) {
                int idx = pg * 45 + i;
                if (idx >= ids.size()) { m.box.setItem(i, ItemStack.EMPTY); continue; }
                String id = ids.get(idx);
                Block b = BuiltInRegistries.BLOCK.getOptional(Identifier.parse(id)).orElse(null);
                Item it = b == null ? Items.STONE : b.asItem();
                if (it == Items.AIR) it = Items.STONE;
                ItemStack s = Util.icon(it, Util.pretty(id), ChatFormatting.WHITE,
                        id.equals(cur) ? "Currently selected" : "Click to disguise as this");
                if (id.equals(cur)) Util.glint(s);
                final int fp = pg;
                m.set(i, s, () -> {
                    if (!Game.canChangeDisguise(p)) {
                        p.sendSystemMessage(Util.msg("You cannot change your disguise right now."));
                        return;
                    }
                    Game.setDisguise(p, id);
                    p.sendSystemMessage(Util.msg("Disguise set to " + Util.pretty(id) + "."));
                    openBlocks(p, fp);
                });
            }
            final int fpg = pg;
            if (pg > 0) m.set(45, Util.icon(Items.ARROW, "Previous page", ChatFormatting.LIGHT_PURPLE), () -> openBlocks(p, fpg - 1));
            if (pg < pages - 1) m.set(53, Util.icon(Items.ARROW, "Next page", ChatFormatting.LIGHT_PURPLE), () -> openBlocks(p, fpg + 1));
            m.set(49, Util.icon(Items.BARRIER, "Back", ChatFormatting.GRAY, "Page " + (pg + 1) + "/" + pages), () -> openMain(p));
        });
    }

    // ------------------------------------------------------------------ abilities
    static final String[][] HIDER_ABS = {{"speed", "h:speed"}, {"vanish", "h:vanish"}, {"decoy", "h:decoy"}};
    static final String[][] SEEKER_ABS = {{"radar", "s:radar"}, {"pulse", "s:pulse"}, {"speed", "s:speed"}};

    static Item abItem(String act) {
        return switch (act) {
            case "h:speed" -> Items.SUGAR;
            case "h:vanish" -> Items.ENDER_EYE;
            case "h:decoy" -> Items.CLAY_BALL;
            case "s:radar" -> Items.COMPASS;
            case "s:pulse" -> Items.GLOWSTONE_DUST;
            default -> Items.FEATHER;
        };
    }

    static String abName(String act) {
        return switch (act) {
            case "h:speed" -> "Speed Boost";
            case "h:vanish" -> "Vanish";
            case "h:decoy" -> "Fake Decoy Block";
            case "s:radar" -> "Radar";
            case "s:pulse" -> "Reveal Pulse";
            default -> "Seeker Sprint";
        };
    }

    static String abDesc(String act) {
        Cfg.Ab a = Cfg.abilities.get(act);
        return switch (act) {
            case "h:speed", "s:speed" -> "Speed for " + a.durationSeconds + "s, cooldown " + a.cooldownSeconds + "s";
            case "h:vanish" -> "Disguise hidden for " + a.durationSeconds + "s, cooldown " + a.cooldownSeconds + "s";
            case "h:decoy" -> "Place up to " + a.maxCount + " fake blocks, cooldown " + a.cooldownSeconds + "s";
            case "s:radar" -> "Nearest hider within " + a.range + " blocks, cooldown " + a.cooldownSeconds + "s";
            default -> "Reveals hiders within " + a.radius + " blocks for " + a.durationSeconds + "s, cooldown " + a.cooldownSeconds + "s";
        };
    }

    public static void openAbilities(ServerPlayer p) {
        open(p, "Ability Selection", 4, m -> {
            String[] pref = Game.pref(p.getUUID());
            m.set(10, Util.icon(Items.PURPUR_BLOCK, "Hider ability", ChatFormatting.LIGHT_PURPLE, "Used while you are a Hider"), null);
            for (int i = 0; i < 3; i++) {
                String key = HIDER_ABS[i][0], act = HIDER_ABS[i][1];
                ItemStack s = Util.icon(abItem(act), abName(act), ChatFormatting.WHITE, abDesc(act), key.equals(pref[1]) ? "SELECTED" : "Click to select");
                if (key.equals(pref[1])) Util.glint(s);
                m.set(12 + i, s, () -> {
                    if (!Game.canChangeAbility(p)) { p.sendSystemMessage(Util.msg("You cannot change abilities during a match.")); return; }
                    Game.pref(p.getUUID())[1] = key;
                    openAbilities(p);
                });
            }
            m.set(19, Util.icon(Items.ENDER_EYE, "Seeker ability", ChatFormatting.RED, "Used while you are a Seeker"), null);
            for (int i = 0; i < 3; i++) {
                String key = SEEKER_ABS[i][0], act = SEEKER_ABS[i][1];
                ItemStack s = Util.icon(abItem(act), abName(act), ChatFormatting.WHITE, abDesc(act), key.equals(pref[2]) ? "SELECTED" : "Click to select");
                if (key.equals(pref[2])) Util.glint(s);
                m.set(21 + i, s, () -> {
                    if (!Game.canChangeAbility(p)) { p.sendSystemMessage(Util.msg("You cannot change abilities during a match.")); return; }
                    Game.pref(p.getUUID())[2] = key;
                    openAbilities(p);
                });
            }
            m.set(31, Util.icon(Items.ARROW, "Back", ChatFormatting.GRAY), () -> openMain(p));
        });
    }

    // ------------------------------------------------------------------ stats / leaderboard / results
    public static void openStats(ServerPlayer p) {
        open(p, "Statistics", 3, m -> {
            Stats.Rec r = Stats.get(p.getUUID(), p.getName().getString());
            m.set(10, Util.icon(Items.PAPER, "Games played", ChatFormatting.LIGHT_PURPLE, String.valueOf(r.games)), null);
            m.set(11, Util.icon(Items.NETHER_STAR, "Wins", ChatFormatting.LIGHT_PURPLE, String.valueOf(r.wins), "As Hider: " + r.hiderWins, "As Seeker: " + r.seekerWins), null);
            m.set(12, Util.icon(Items.ENDER_EYE, "Eliminations", ChatFormatting.LIGHT_PURPLE, String.valueOf(r.kills)), null);
            m.set(13, Util.icon(Items.SKELETON_SKULL, "Times caught", ChatFormatting.LIGHT_PURPLE, String.valueOf(r.caught)), null);
            m.set(14, Util.icon(Items.PURPUR_BLOCK, "Rounds survived", ChatFormatting.LIGHT_PURPLE, String.valueOf(r.survived)), null);
            double wr = r.games == 0 ? 0 : 100.0 * r.wins / r.games;
            m.set(15, Util.icon(Items.EXPERIENCE_BOTTLE, "Win rate", ChatFormatting.LIGHT_PURPLE, String.format("%.1f%%", wr)), null);
            m.set(22, Util.icon(Items.ARROW, "Back", ChatFormatting.GRAY), () -> openMain(p));
        });
    }

    public static void openBoard(ServerPlayer p) {
        open(p, "Leaderboard", 4, m -> {
            int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21};
            List<Stats.Rec> top = Stats.top(10);
            for (int i = 0; i < top.size(); i++) {
                Stats.Rec r = top.get(i);
                Item it = i == 0 ? Items.NETHERITE_INGOT : i == 1 ? Items.GOLD_INGOT : i == 2 ? Items.IRON_INGOT : Items.COPPER_INGOT;
                m.set(slots[i], Util.icon(it, "#" + (i + 1) + "  " + r.name, i < 3 ? ChatFormatting.LIGHT_PURPLE : ChatFormatting.WHITE,
                        "Wins: " + r.wins, "Eliminations: " + r.kills, "Games: " + r.games), null);
            }
            if (top.isEmpty()) m.set(13, Util.icon(Items.BARRIER, "No matches played yet", ChatFormatting.GRAY), null);
            m.set(31, Util.icon(Items.ARROW, "Back", ChatFormatting.GRAY), () -> openMain(p));
        });
    }

    public static void openResults(ServerPlayer p) {
        open(p, "Match Results", 5, m -> {
            Game.Result r = Game.lastResult;
            if (r == null) {
                m.set(22, Util.icon(Items.BARRIER, "No finished match yet", ChatFormatting.GRAY), null);
            } else {
                m.set(4, Util.icon(Items.DRAGON_HEAD, r.title, ChatFormatting.LIGHT_PURPLE, "Map: " + r.map, "Duration: " + Util.time(r.seconds)), null);
                int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
                for (int i = 0; i < r.rows.size() && i < slots.length; i++) {
                    String[] row = r.rows.get(i); // name, team, kills, outcome
                    boolean seeker = row[1].equals("Seeker");
                    m.set(slots[i], Util.icon(seeker ? Items.ENDER_EYE : Items.PURPUR_BLOCK, row[0],
                            seeker ? ChatFormatting.RED : ChatFormatting.LIGHT_PURPLE, row[1], "Eliminations: " + row[2], row[3]), null);
                }
            }
            m.set(40, Util.icon(Items.ARROW, "Back", ChatFormatting.GRAY), () -> openMain(p));
        });
    }
}
