package net.hanzala.hideseek;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Hide & Seek - Copyright (c) 2026 HANZALA. All rights reserved.
 * Every hook below first checks that the player is a participant of the running game (who are always in the
 * End), so players and entities in other dimensions are never touched.
 */
public class HideSeekMod implements ModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("endhideseek");
    public static MinecraftServer server;

    @Override
    public void onInitialize() {
        Cfg.init(FabricLoader.getInstance().getConfigDir().resolve("hideseek"));
        Backup.init();
        Stats.load();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> Cmds.register(dispatcher));

        ServerLifecycleEvents.SERVER_STARTED.register(s -> server = s);
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> server = null);
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> {
            Game.shutdown("server stopping.");
            Stats.save();
        });

        // One cheap check per tick; does nothing at all when no game is open.
        ServerTickEvents.END_SERVER_TICK.register(s -> {
            Sched.drain();
            Game g = Game.current;
            if (g != null) g.tick();
        });

        // Disconnect: give the inventory back immediately, no rewards, remove from game.
        ServerPlayConnectionEvents.DISCONNECT.register((handler, s) -> {
            ServerPlayer p = handler.player;
            Game g = Game.current;
            if (g != null && g.players.containsKey(p.getUUID())) {
                try { g.remove(p, "Disconnected."); } catch (Exception e) { LOG.error("disconnect cleanup", e); }
            }
        });
        // Join: if a crash left a backup behind, give it back.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, s) -> {
            ServerPlayer p = handler.player;
            Sched.later(() -> {
                if (!Game.inGame(p) && Backup.exists(p)) {
                    Backup.restore(p, s);
                    p.sendSystemMessage(Util.msg("Your inventory was restored after an interrupted match."));
                }
            });
        });

        // Participants take no damage (fall, void handled by arena checks, mobs...).
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) ->
                !(entity instanceof ServerPlayer p && Game.inGame(p)));

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClientSide() || !(player instanceof ServerPlayer sp) || Game.current == null) return InteractionResult.PASS;
            return Game.current.onAttack(sp, entity) ? InteractionResult.FAIL : InteractionResult.PASS;
        });
        AttackBlockCallback.EVENT.register((player, world, hand, pos, dir) -> {
            if (world.isClientSide() || !(player instanceof ServerPlayer sp) || Game.current == null) return InteractionResult.PASS;
            return Game.current.onAttackBlock(sp, pos) ? InteractionResult.FAIL : InteractionResult.PASS;
        });
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClientSide() || !(player instanceof ServerPlayer sp) || Game.current == null) return InteractionResult.PASS;
            return Game.current.onUse(sp, sp.getItemInHand(hand)) ? InteractionResult.FAIL : InteractionResult.PASS;
        });
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.isClientSide() || !(player instanceof ServerPlayer sp) || Game.current == null) return InteractionResult.PASS;
            return Game.current.onUse(sp, sp.getItemInHand(hand)) ? InteractionResult.FAIL : InteractionResult.PASS;
        });

        // Menu NPCs (/hs npc add menu): right-click opens the /mg menu, never the villager trade screen.
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClientSide() || !(player instanceof ServerPlayer sp) || !Hub.isHubNpc(entity)) return InteractionResult.PASS;
            Hub.onNpcClick(sp, entity);
            return InteractionResult.SUCCESS;
        });

        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            // Leftover disguise entities (e.g. after a crash) are removed.
            if (entity.entityTags().contains(Disguise.TAG) && !Disguise.ACTIVE.contains(entity.getUUID())) {
                world.getServer().execute(entity::discard);
                return;
            }
            // Dropped items next to players inside the game are deleted (no item duplication / littering).
            if (entity instanceof ItemEntity && world.dimension() == Level.OVERWORLD && Game.current != null
                    && Game.current.nearParticipant(entity)) {
                world.getServer().execute(entity::discard);
            }
        });

        LOG.info("Hide & Seek loaded (Overworld, joined through /mg).");
    }
}
