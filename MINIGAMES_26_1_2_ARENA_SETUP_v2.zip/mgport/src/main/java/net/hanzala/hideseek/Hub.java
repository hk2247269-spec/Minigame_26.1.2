package net.hanzala.hideseek;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/**
 * Menu NPCs: frozen villagers that open the /mg minigames menu when right-clicked (placed with /hs npc add menu).
 * The old "travel to the End / Overworld" NPCs of earlier versions keep working as menu NPCs - nothing teleports to another
 * dimension any more.
 */
public final class Hub {
    private Hub() {}

    public static final String TAG_MENU = "hub_menu";
    /** Tags of NPCs placed by older versions (still recognised). */
    public static final String TAG_TO_END = "hub_to_end";
    public static final String TAG_TO_OVERWORLD = "hub_to_overworld";

    public static boolean isHubNpc(Entity e) {
        return e.entityTags().contains(TAG_MENU) || e.entityTags().contains(TAG_TO_END) || e.entityTags().contains(TAG_TO_OVERWORLD);
    }

    /** Right-click handler. Returns true when the entity was a hub NPC (the click is then consumed). */
    public static boolean onNpcClick(ServerPlayer p, Entity npc) {
        if (!isHubNpc(npc)) return false;
        com.hanzala.minigames.MgMenu.open(p);
        return true;
    }

    public static boolean spawnNpc(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        Vec3 pos = source.getPosition();
        Villager v = EntityType.VILLAGER.create(level, EntitySpawnReason.COMMAND);
        if (v == null) return false;
        v.setPos(pos.x, pos.y, pos.z);
        v.setYRot(source.getRotation().y);
        v.setNoAi(true);
        v.setInvulnerable(true);
        v.setSilent(true);
        v.setPersistenceRequired();
        v.setCustomName(Component.literal("§b§lMINIGAMES"));
        v.setCustomNameVisible(true);
        v.addTag(TAG_MENU);
        level.addFreshEntity(v);
        return true;
    }

    /** Removes the nearest hub NPC within 4 blocks. */
    public static boolean removeNearestNpc(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        Vec3 pos = source.getPosition();
        List<Villager> found = level.getEntitiesOfClass(Villager.class, new AABB(pos, pos).inflate(4), Hub::isHubNpc);
        if (found.isEmpty()) return false;
        found.stream().min(Comparator.comparingDouble(v -> v.distanceToSqr(pos))).ifPresent(Entity::discard);
        return true;
    }
}
