package net.hanzala.hideseek;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.numbers.BlankFormat;
import net.minecraft.network.chat.numbers.NumberFormat;
import net.minecraft.network.protocol.game.*;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.criteria.ObjectiveCriteria;

import java.util.Optional;

/**
 * Per-player sidebar scoreboard, titles and action bars.
 * The scoreboard is sent as raw packets from a private Scoreboard object, so it never touches the real
 * server scoreboard and only players inside the game ever receive it.
 */
public final class Hud {
    private Hud() {}

    static final String OBJ_NAME = "hs_side";
    static final Scoreboard SB = new Scoreboard();
    static final Objective OBJ = new Objective(SB, OBJ_NAME, ObjectiveCriteria.DUMMY,
            Component.literal("HIDE & SEEK"), ObjectiveCriteria.RenderType.INTEGER, false, null);
    static final int LINES = 13;
    static final ChatFormatting[] PAL = {ChatFormatting.DARK_PURPLE, ChatFormatting.LIGHT_PURPLE, ChatFormatting.WHITE,
            ChatFormatting.LIGHT_PURPLE, ChatFormatting.DARK_PURPLE, ChatFormatting.DARK_GRAY};

    static Component title(long frame) {
        String s = "HIDE & SEEK";
        MutableComponent c = Component.empty();
        for (int i = 0; i < s.length(); i++) {
            c.append(Component.literal(String.valueOf(s.charAt(i)))
                    .withStyle(PAL[(int) ((i + frame) % PAL.length)], ChatFormatting.BOLD));
        }
        return c;
    }

    public static void show(ServerPlayer p, Game.PD pd) {
        OBJ.setDisplayName(title(0));
        p.connection.send(new ClientboundSetObjectivePacket(OBJ, 0));
        p.connection.send(new ClientboundSetDisplayObjectivePacket(DisplaySlot.SIDEBAR, OBJ));
        java.util.Arrays.fill(pd.hud, null);
        pd.hudOn = true;
    }

    public static void hide(ServerPlayer p, Game.PD pd) {
        if (!pd.hudOn) return;
        pd.hudOn = false;
        p.connection.send(new ClientboundSetObjectivePacket(OBJ, 1));
    }

    /** Animated title: one tiny packet per player, a few times per second. */
    public static void animate(Game g) {
        OBJ.setDisplayName(title(g.tick / 4));
        ClientboundSetObjectivePacket pk = new ClientboundSetObjectivePacket(OBJ, 2);
        for (Game.PD pd : g.players.values()) {
            if (!pd.hudOn) continue;
            ServerPlayer p = g.player(pd);
            if (p != null) p.connection.send(pk);
        }
    }

    static Component line(String label, String value, ChatFormatting vc) {
        return Component.literal(label).withStyle(ChatFormatting.GRAY).append(Component.literal(value).withStyle(vc));
    }

    static Component blank() {
        return Component.literal(" ");
    }

    static Component[] lines(Game g, Game.PD pd) {
        Component[] l = new Component[LINES];
        Game.State st = g.state;
        String status = switch (st) {
            case WAITING -> "Waiting";
            case COUNTDOWN -> "Starting";
            case HIDING -> "Hiding";
            case SEEKING -> "Seeking";
            case ENDED -> "Match over";
        };
        boolean live = st == Game.State.HIDING || st == Game.State.SEEKING;
        ChatFormatting teamColor = pd.side == Game.Side.SEEKER ? ChatFormatting.RED : ChatFormatting.LIGHT_PURPLE;
        String time = (st == Game.State.WAITING || st == Game.State.ENDED) ? "--:--" : Util.time(g.secs);
        String role = pd.side == Game.Side.NONE ? "Lobby"
                : pd.side == Game.Side.SEEKER ? "Seeker" : (pd.alive ? "Hider" : "Spectator");
        String disguise = pd.side == Game.Side.SEEKER ? "None (seeker)" : Util.pretty(Game.pref(pd.id)[0]);

        l[0] = blank();
        l[1] = line("Status: ", status, ChatFormatting.LIGHT_PURPLE);
        l[2] = line("Map: ", g.arena.name, ChatFormatting.WHITE);
        l[3] = Component.literal("  ");
        if (live || st == Game.State.ENDED) {
            l[4] = line("Hiders: ", String.valueOf(g.hidersAlive()), ChatFormatting.LIGHT_PURPLE);
            l[5] = line("Seekers: ", String.valueOf(g.seekersCount()), ChatFormatting.RED);
        } else {
            l[4] = line("Players: ", g.players.size() + "/" + Cfg.game.maxPlayers, ChatFormatting.LIGHT_PURPLE);
            l[5] = line("Needed: ", String.valueOf(Cfg.game.minPlayers), ChatFormatting.GRAY);
        }
        l[6] = line("Time: ", time, ChatFormatting.YELLOW);
        l[7] = Component.literal("   ");
        l[8] = line("Role: ", role, teamColor);
        l[9] = line("Disguise: ", disguise, ChatFormatting.WHITE);
        l[10] = line("Kills: ", String.valueOf(pd.kills), ChatFormatting.GOLD);
        l[11] = Component.literal("    ");
        l[12] = Component.literal("Owner: HANZALA").withStyle(ChatFormatting.DARK_GRAY);
        return l;
    }

    public static void refresh(Game g) {
        for (Game.PD pd : g.players.values()) {
            if (!pd.hudOn) continue;
            ServerPlayer p = g.player(pd);
            if (p == null) continue;
            Component[] l = lines(g, pd);
            for (int i = 0; i < LINES; i++) {
                String key = l[i].getString() + (pd.side == Game.Side.SEEKER ? "S" : "H");
                if (key.equals(pd.hud[i])) continue;
                pd.hud[i] = key;
                p.connection.send(new ClientboundSetScorePacket("hs" + i, OBJ_NAME, LINES - i,
                        Optional.of(l[i]), Optional.<NumberFormat>of(BlankFormat.INSTANCE)));
            }
        }
    }

    public static void title(ServerPlayer p, Component title, Component sub, int in, int stay, int out) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(in, stay, out));
        p.connection.send(new ClientboundSetSubtitleTextPacket(sub));
        p.connection.send(new ClientboundSetTitleTextPacket(title));
    }

    public static void bar(ServerPlayer p, Component c) {
        p.sendOverlayMessage(c);
    }
}
