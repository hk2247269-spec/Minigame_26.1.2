package net.hanzala.hideseek;

import java.util.ArrayList;
import java.util.List;

/** Tiny "run this on the next server tick" queue. Used so menu clicks never change menus mid-click. */
public final class Sched {
    private static final List<Runnable> QUEUE = new ArrayList<>();

    private Sched() {}

    public static void later(Runnable r) {
        QUEUE.add(r);
    }

    public static void drain() {
        if (QUEUE.isEmpty()) return;
        List<Runnable> copy = new ArrayList<>(QUEUE);
        QUEUE.clear();
        for (Runnable r : copy) {
            try {
                r.run();
            } catch (Exception e) {
                HideSeekMod.LOG.error("Scheduled task failed", e);
            }
        }
    }
}
