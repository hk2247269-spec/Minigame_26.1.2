package net.hanzala.hideseek;

import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.nio.file.*;
import java.util.*;

/** Persistent player statistics (config/hideseek/stats.json). */
public final class Stats {
    private Stats() {}

    public static class Rec {
        public String name = "";
        public int games, wins, seekerWins, hiderWins, kills, caught, survived;
    }

    static Map<String, Rec> data = new HashMap<>();
    static Path file;

    public static void load() {
        file = Cfg.dir.resolve("stats.json");
        try {
            if (Files.exists(file)) {
                Type t = new TypeToken<HashMap<String, Rec>>() {}.getType();
                Map<String, Rec> m = Cfg.GSON.fromJson(Files.readString(file), t);
                if (m != null) data = m;
            }
        } catch (Exception e) {
            HideSeekMod.LOG.error("Could not read stats.json", e);
        }
    }

    public static void save() {
        try {
            Path tmp = file.resolveSibling("stats.json.tmp");
            Files.writeString(tmp, Cfg.GSON.toJson(data));
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            HideSeekMod.LOG.error("Could not save stats.json", e);
        }
    }

    public static Rec get(UUID id, String name) {
        Rec r = data.computeIfAbsent(id.toString(), k -> new Rec());
        r.name = name;
        return r;
    }

    public static List<Rec> top(int n) {
        List<Rec> l = new ArrayList<>(data.values());
        l.sort((a, b) -> b.wins != a.wins ? Integer.compare(b.wins, a.wins) : Integer.compare(b.kills, a.kills));
        return l.subList(0, Math.min(n, l.size()));
    }
}
