package com.hanzala.minigames;

import java.nio.file.*;
import java.util.*;

/**
 * Plain-Java self test of the arena data model, migration, storage and validation (no Minecraft needed).
 * Run with tools/selftest/run.sh
 */
public final class ArenaLogicSelfTest {
    static int checks, failures;
    static final List<String> LOG = new ArrayList<>();

    static void check(boolean ok, String what) {
        checks++;
        if (!ok) { failures++; System.out.println("FAIL: " + what); } else System.out.println("ok:   " + what);
    }

    static Arena box(String id, String type, int x1, int z1, int x2, int z2) {
        Arena a = new Arena();
        a.id = id; a.type = type; a.name = id;
        a.x1 = x1; a.y1 = 60; a.z1 = z1; a.x2 = x2; a.y2 = 100; a.z2 = z2;
        a.hasPos1 = a.hasPos2 = true; a.updateBox();
        Arena.Loc s = new Arena.Loc(); s.x = (x1 + x2) / 2.0; s.y = 98; s.z = (z1 + z2) / 2.0;
        a.spawns.add(s);
        return a;
    }

    static boolean has(List<ArenaValidator.Issue> l, String fragment, boolean error) {
        for (ArenaValidator.Issue i : l) if (i.isError() == error && i.message().contains(fragment)) return true;
        return false;
    }

    public static void main(String[] args) throws Exception {
        Path tmp = Files.createTempDirectory("arena-selftest");
        Path exampleV1 = Path.of(args[0]);

        // ---------- migration of the shipped (schema 1) example file
        Path f = tmp.resolve("arenas.json");
        Files.copy(exampleV1, f);
        String before = Files.readString(f);
        ArenaStorage.LoadResult r = ArenaStorage.load(f, LOG::add);
        check(!r.failed() && r.migrated(), "schema-1 file is detected and migrated");
        check(r.arenas().size() == 3, "all 3 arenas survive migration");
        Arena tnt = r.arenas().get(0), rg = r.arenas().get(2);
        check(Arena.OVERWORLD.equals(tnt.dim()), "migrated arena is in the Overworld");
        check(tnt.enabled && rg.enabled, "migrated arenas stay enabled");
        check(tnt.spawns.size() == 1 && tnt.param("delay", 0) == 12.0 && tnt.maxPlayers == 16, "spawns, params, limits preserved");
        check(rg.finish != null && rg.finish.z == 1097.5 && rg.param("redGrace", 0) == 10.0, "finish line + params preserved");
        check(Files.exists(tmp.resolve("arenas.json.v1.bak")) && Files.readString(tmp.resolve("arenas.json.v1.bak")).equals(before), "byte-exact v1 backup written");
        check(ArenaStorage.save(f, r.arenas(), LOG::add), "save succeeds");
        ArenaStorage.LoadResult r2 = ArenaStorage.load(f, LOG::add);
        check(!r2.migrated() && r2.arenas().size() == 3, "second load: schema 2, no migration");
        check(Files.readString(f).contains("\"schemaVersion\": 2") && Files.readString(f).contains("\"dimension\": \"minecraft:overworld\""), "file now stores schemaVersion and dimension");
        check(Files.exists(tmp.resolve("arenas.json.bak")) && !Files.exists(tmp.resolve("arenas.json.tmp")), "save keeps .bak and leaves no temp file");

        // ---------- corrupt file is never silently overwritten
        Files.writeString(f, "{ this is not json");
        ArenaStorage.LoadResult r3 = ArenaStorage.load(f, LOG::add);
        check(!r3.failed() && r3.arenas().size() == 3, "corrupt file: last good .bak is used");
        boolean corruptCopy = false;
        try (var s = Files.list(tmp)) { corruptCopy = s.anyMatch(p -> p.getFileName().toString().startsWith("arenas.json.corrupt-")); }
        check(corruptCopy, "corrupt file was copied aside before anything else");
        Files.delete(tmp.resolve("arenas.json.bak"));
        Files.writeString(f, "garbage");
        check(ArenaStorage.load(f, LOG::add).failed(), "corrupt file without backup: reported as failed");

        // ---------- duplicate / broken entries are kept, not dropped
        Path g = tmp.resolve("dup.json");
        Files.writeString(g, "{\"arenas\":[{\"id\":\"A\",\"type\":\"tnt\"},{\"id\":\"a\",\"type\":\"tnt\"},{\"type\":\"lava\"},null]}");
        ArenaStorage.LoadResult r4 = ArenaStorage.load(g, LOG::add);
        check(r4.arenas().size() == 3, "duplicate id and id-less arena are kept (3 of 3 real entries)");
        Set<String> ids = new HashSet<>(); for (Arena a : r4.arenas()) ids.add(a.id.toLowerCase());
        check(ids.size() == 3, "all ids unique after repair");
        check(r4.arenas().get(0).spawns != null && r4.arenas().get(0).params != null && r4.arenas().get(0).minPlayers >= 2, "null collections / limits repaired");

        // ---------- validator
        Arena empty = new Arena(); empty.id = "e"; empty.type = "tnt";
        List<ArenaValidator.Issue> v = ArenaValidator.checkArena(empty);
        check(has(v, "Boundaries are not set", true) && has(v, "No player spawn", true), "empty arena: boundaries + spawn errors");
        check(v.stream().allMatch(i -> i.fix() != null && !i.fix().isBlank()), "every issue explains how to fix it");
        check(empty.missing() != null, "missing() reports problems");

        Arena ok = box("t", "tnt", 0, 0, 30, 30);
        check(!ArenaValidator.hasErrors(ArenaValidator.checkArena(ok)), "complete TNT arena has no errors");
        check(has(ArenaValidator.checkArena(ok), "No waiting location", false) && has(ArenaValidator.checkArena(ok), "No spectator", false), "missing waiting/spectator are warnings, not errors");

        Arena out = box("o", "tnt", 0, 0, 30, 30); out.spawns.get(0).x = 500;
        check(has(ArenaValidator.checkArena(out), "outside the boundaries", true), "spawn outside box is an error");

        Arena a1 = box("a1", "tnt", 0, 0, 30, 30), a2 = box("a2", "lava", 20, 20, 50, 50);
        check(has(ArenaValidator.validate(a1, List.of(a1, a2), null, null), "overlap", true), "overlapping boxes in same dimension: error");
        a2.dimension = "minecraft:the_nether";
        check(!has(ArenaValidator.validate(a1, List.of(a1, a2), null, null), "overlap", true) && !a1.overlaps(a2), "same coordinates in different dimensions do not overlap");

        ArenaValidator.LobbyPoint lobbyIn = new ArenaValidator.LobbyPoint(Arena.OVERWORLD, 10, 70, 10);
        check(has(ArenaValidator.validate(a1, List.of(a1), lobbyIn, null), "covers the common lobby", true), "arena covering the lobby: error");
        ArenaValidator.LobbyPoint lobbyNear = new ArenaValidator.LobbyPoint(Arena.OVERWORLD, 33, 70, 10);
        check(has(ArenaValidator.validate(a1, List.of(a1), lobbyNear, null), "too close", true), "arena next to the lobby: error");
        ArenaValidator.LobbyPoint lobbyOther = new ArenaValidator.LobbyPoint("minecraft:the_end", 10, 70, 10);
        check(!ArenaValidator.hasErrors(ArenaValidator.validate(a1, List.of(a1), lobbyOther, null)), "lobby in another dimension does not conflict");

        check(has(ArenaValidator.validate(a1, List.of(a1), null, d -> false), "not loaded", true), "unloaded dimension: error");
        check(!ArenaValidator.hasErrors(ArenaValidator.validate(a1, List.of(a1), null, d -> true)), "loaded dimension: ok");
        a1.dimension = "Bad Dim!";
        check(has(ArenaValidator.checkArena(a1), "not a valid identifier", true), "invalid dimension id: error");
        a1.dimension = "mypack:arena_world";
        check(!ArenaValidator.hasErrors(ArenaValidator.checkArena(a1)), "custom dimension id accepted");

        Arena rgA = box("r", "rg", 0, 0, 30, 100);
        check(has(ArenaValidator.checkArena(rgA), "finish line is not set", true), "rg without finish: error");
        rgA.finish = new Arena.Loc(); rgA.finish.x = 15; rgA.finish.y = 61; rgA.finish.z = 52;
        check(has(ArenaValidator.checkArena(rgA), "less than 5 blocks", true), "rg finish too near spawns: error");
        rgA.finish.z = 97;
        check(!ArenaValidator.hasErrors(ArenaValidator.checkArena(rgA)), "rg with a proper finish: ok");
        rgA.params.put("greenMin", 9.0);
        check(has(ArenaValidator.checkArena(rgA), "Green light", false), "rg green min > max: warning");

        Arena lava = box("l", "lava", 0, 0, 30, 30); lava.params.put("startY", 500.0);
        check(has(ArenaValidator.checkArena(lava), "lava start height", false), "lava startY outside box: warning");

        Arena lim = box("m", "tnt", 0, 0, 30, 30); lim.minPlayers = 8; lim.maxPlayers = 4;
        check(has(ArenaValidator.checkArena(lim), "Maximum players", true), "max < min: error");

        // ---------- dimension binding
        Arena b = new Arena(); b.id = "b"; b.type = "tnt";
        check(b.bindDimension("minecraft:the_nether") == null && b.dim().equals("minecraft:the_nether"), "empty arena adopts the dimension of the admin");
        b.hasPos1 = true;
        check(b.bindDimension("minecraft:overworld") != null, "arena with locations refuses another dimension");
        check(b.bindDimension("minecraft:the_nether") == null, "same dimension accepted");
        b.clearLocations();
        check(!b.enabled && !b.hasAnyLocation() && b.bindDimension("minecraft:overworld") == null && b.dim().equals("minecraft:overworld"), "clearLocations frees the arena to move dimension and disables it");

        System.out.println("\n" + checks + " checks, " + failures + " failed");
        System.out.println("--- log lines produced:"); LOG.forEach(l -> System.out.println("  " + l));
        System.exit(failures == 0 ? 0 : 1);
    }
}
