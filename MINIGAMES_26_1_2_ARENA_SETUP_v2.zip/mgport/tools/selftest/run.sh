#!/usr/bin/env bash
# Compiles and runs the Minecraft-free self test. Needs a JDK and gson on the classpath (set GSON_JAR).
set -e
cd "$(dirname "$0")/../.."
GSON_JAR="${GSON_JAR:-$(find ~/.gradle ~/.m2 /opt -name 'gson-*.jar' 2>/dev/null | head -1)}"
OUT="$(mktemp -d)"
M=src/main/java/com/hanzala/minigames
javac -d "$OUT" -cp "$GSON_JAR" \
  tools/selftest/stubs/net/minecraft/server/level/ServerPlayer.java tools/selftest/stubs/com/hanzala/minigames/MinigameType.java \
  $M/Arena.java $M/ArenaValidator.java $M/ArenaStorage.java tools/selftest/ArenaLogicSelfTest.java
java -cp "$OUT:$GSON_JAR" com.hanzala.minigames.ArenaLogicSelfTest config-example/minigames/arenas.json
