package com.hanzala.minigames;
/** Test-only stand-in (the real enum needs Minecraft item classes). NOT part of the mod. */
public enum MinigameType {
    TNT_RUN("tnt"), FLOOR_LAVA("lava"), RED_GREEN("rg");
    public final String id;
    MinigameType(String id) { this.id = id; }
    public static MinigameType byId(String id) { for (MinigameType t : values()) if (t.id.equalsIgnoreCase(id)) return t; return null; }
}
