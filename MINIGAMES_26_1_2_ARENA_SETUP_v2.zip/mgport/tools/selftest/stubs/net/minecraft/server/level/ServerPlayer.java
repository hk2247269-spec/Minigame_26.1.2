package net.minecraft.server.level;
/** Test-only stand-in so the pure arena logic compiles without Minecraft. NOT part of the mod. */
public class ServerPlayer {
    public double getX() { return 0; } public double getY() { return 0; } public double getZ() { return 0; }
    public float getYRot() { return 0; } public float getXRot() { return 0; }
}
