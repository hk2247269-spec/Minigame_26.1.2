package com.hanzala.minigames;

import com.hanzala.bedwars.ServerGui;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/** Optional page of the setup wizard: every arena of ONE game, and a button to add another one. Only reached by right-click. */
public final class MgSetupListMenu extends ServerGui {
    private static final int[] SLOTS = { 10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25 };
    private final MinigameType type;

    public static void open(ServerPlayer p, MinigameType t) {
        if (!isAdmin(p)) return;
        p.openMenu(new SimpleMenuProvider((id, inv, pl) -> new MgSetupListMenu(id, inv, t), Component.literal("§8Setup: " + t.display + " arenas")));
    }

    private MgSetupListMenu(int containerId, Inventory inventory, MinigameType type) {
        super(4, containerId, inventory);
        this.type = type;
        build();
    }

    @Override
    protected void build() {
        reset();
        put(4, icon(type.icon, type.color + "§l" + type.display,
                List.of("§7Most servers need just ONE arena per game.", "§7Extra arenas let several matches run at once.")));
        List<Arena> arenas = ArenaManager.of(type);
        for (int i = 0; i < arenas.size() && i < SLOTS.length; i++) {
            Arena a = arenas.get(i);
            List<ArenaValidator.Issue> issues = ArenaManager.validate(a);
            boolean errors = ArenaValidator.hasErrors(issues);
            Item mat = errors ? Items.RED_CONCRETE : (a.enabled ? Items.LIME_CONCRETE : Items.YELLOW_CONCRETE);
            List<String> lore = new ArrayList<>();
            lore.add(errors ? "§cNeeds setup" : (a.enabled ? "§aEnabled" : "§eReady - not enabled yet"));
            lore.add("§7Id: §f" + a.id + "  §7Dimension: §f" + a.dim());
            lore.add(" ");
            lore.add("§eClick: §fedit this arena");
            put(SLOTS[i], icon(mat, "§f" + a.displayName(), lore), (p, b, s) -> MgSetupArenaMenu.open(p, a.id));
        }
        put(31, icon(Items.EMERALD, "§a§l+ Add another arena", List.of("§7Creates a new, empty arena of this game.", "§7It stays disabled until you enable it.")), (p, b, s) -> {
            if (arenas.size() >= SLOTS.length) { bar(p, "§cThat is the maximum for the menu. Use /mg arena create for more."); return; }
            Arena created = ArenaManager.createExtra(type);
            if (created == null) { bar(p, "§cCould not create the arena. See the server log."); return; }
            MgSetupArenaMenu.open(p, created.id);
        });
        put(27, icon(Items.ARROW, "§7Back"), (p, b, s) -> MgSetupMenu.open(p));
        put(35, icon(Items.NAME_TAG, MgBoard.CREDIT));
    }
}
