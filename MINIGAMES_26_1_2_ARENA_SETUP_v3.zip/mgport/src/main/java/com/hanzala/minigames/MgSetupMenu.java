package com.hanzala.minigames;

import com.hanzala.bedwars.ServerGui;
import com.hanzala.bedwars.AdminSetupMenu;
import com.hanzala.bedwars.BedWarsMod;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/**
 * /mg setup - the first page of the setup wizard (admins only).
 * Step 1: set the ONE common lobby. Step 2: click a game to set up its arena (one default arena per game).
 * Right-click a game to manage extra arenas of that game (optional).
 */
public final class MgSetupMenu extends ServerGui {
    private static final MinigameType[] GAMES = {
            MinigameType.BEDWARS, MinigameType.HIDESEEK, MinigameType.TNT_RUN, MinigameType.FLOOR_LAVA, MinigameType.RED_GREEN };
    private static final int[] SLOTS = { 20, 21, 22, 23, 24 };

    public static void open(ServerPlayer p) {
        if (!isAdmin(p)) { p.sendSystemMessage(MgUtil.msg("§cOnly operators can use the setup wizard.")); return; }
        p.openMenu(new SimpleMenuProvider((id, inv, pl) -> new MgSetupMenu(id, inv), Component.literal("§8Minigames Setup")));
    }

    private MgSetupMenu(int containerId, Inventory inventory) {
        super(4, containerId, inventory);
        build();
    }

    @Override
    protected void build() {
        reset();
        put(4, icon(Items.NETHER_STAR, "§b§lMINIGAMES SETUP",
                List.of("§71. Set the common lobby.", "§72. Click a game and fill in its arena.", "§73. Check it, then enable it.", " ",
                        "§8Everything is saved automatically.")));

        // ---- step 1: lobby
        boolean hasLobby = BedWarsMod.GAME.hasLobby();
        List<String> lobby = new ArrayList<>();
        if (hasLobby) {
            double[] c = BedWarsMod.GAME.lobbyCoords();
            lobby.add("§aSet §7at " + (int) c[0] + " " + (int) c[1] + " " + (int) c[2]);
            lobby.add("§7Dimension: §f" + BedWarsMod.GAME.lobbyDimension());
        } else {
            lobby.add("§cNot set yet - players would go to the world spawn.");
        }
        lobby.add(" ");
        lobby.add("§eClick: §fset the lobby to where you stand");
        lobby.add("§eRight-click: §fteleport to the lobby");
        lobby.add("§8All games send players back here.");
        put(10, icon(hasLobby ? Items.BEACON : Items.ENDER_PEARL, "§e§l1. Common lobby", lobby), (p, button, shift) -> {
            if (button == 1) {
                if (!BedWarsMod.GAME.teleportToLobbyAny(p, p.level().getServer())) { bar(p, "§cNo lobby is set yet."); return; }
                p.closeContainer();
                return;
            }
            if (BedWarsMod.GAME.isRunning()) { bar(p, "§cThe lobby cannot be changed while a BedWars match is running."); return; }
            BedWarsMod.GAME.setLobby(p);
            bar(p, "§aLobby set to your position (" + MgUtil.dimId(p) + ").");
            refresh();
        });

        // ---- step 2: games
        for (int i = 0; i < GAMES.length; i++) {
            MinigameType t = GAMES[i];
            put(SLOTS[i], gameIcon(t), (p, button, shift) -> {
                if (t == MinigameType.BEDWARS) { AdminSetupMenu.open(p); return; }
                if (t == MinigameType.HIDESEEK) {
                    p.closeContainer();
                    p.sendSystemMessage(MgUtil.msg("Hide & Seek has its own setup: type §e/hs setup§7 and follow the steps."));
                    return;
                }
                if (button == 1 || shift) { MgSetupListMenu.open(p, t); return; }
                Arena a = ArenaManager.createDefault(t);
                if (a == null) { bar(p, "§cCould not create the arena. See the server log."); return; }
                MgSetupArenaMenu.open(p, a.id);
            });
        }

        put(29, icon(Items.WRITABLE_BOOK, "§b§lCheck everything", List.of("§7Prints the lobby and every arena with",
                "§7what is missing and how to fix it.")), (p, b, s) -> {
            p.closeContainer();
            var src = p.createCommandSourceStack();
            p.sendSystemMessage(MgUtil.msg(hasLobby ? "§aLobby: set (" + BedWarsMod.GAME.lobbyDimension() + ")" : "§cLobby: not set - click the beacon in /mg setup."));
            List<Arena> all = ArenaManager.all();
            if (all.isEmpty()) p.sendSystemMessage(MgUtil.msg("No arenas yet. Click a game in /mg setup to create its arena."));
            for (Arena a : all) ArenaEdit.report(src, a);
        });
        put(27, icon(Items.ARROW, "§7Back to /mg menu"), (p, b, s) -> MgMenu.open(p));
        put(31, icon(Items.BARRIER, "§cClose"), (p, b, s) -> p.closeContainer());
        put(35, icon(Items.NAME_TAG, MgBoard.CREDIT));
    }

    /** One game button: its status in plain words (and what a click does). */
    private ItemStack gameIcon(MinigameType t) {
        List<String> lore = new ArrayList<>();
        Item mat;
        String step = "§e§l2. ";
        if (t == MinigameType.BEDWARS) {
            mat = t.icon;
            lore.add("§7BedWars has its own setup panel");
            lore.add("§7(team spawns, beds, generators, shop).");
            lore.add(" ");
            lore.add("§eClick: §fopen the BedWars setup");
        } else if (t == MinigameType.HIDESEEK) {
            mat = t.icon;
            net.hanzala.hideseek.Cfg.ArenaCfg cfg = net.hanzala.hideseek.Cfg.pickArena();
            lore.add(cfg != null ? "§aArena ready: §f" + cfg.name : "§cNo arena yet");
            lore.add("§7Hide & Seek has its own setup: §e/hs setup");
            lore.add(" ");
            lore.add("§eClick: §fshow how");
        } else {
            Arena a = ArenaManager.defaultFor(t);
            if (a == null) {
                mat = Items.GRAY_CONCRETE;
                lore.add("§cNo arena yet");
                lore.add("§7Click to create \"" + t.display + " Arena\".");
            } else {
                List<ArenaValidator.Issue> issues = ArenaManager.validate(a);
                long errors = issues.stream().filter(ArenaValidator.Issue::isError).count();
                if (errors > 0) {
                    mat = Items.RED_CONCRETE;
                    lore.add("§c" + errors + " thing(s) still to do");
                    for (ArenaValidator.Issue i : issues) if (i.isError() && lore.size() < 5) lore.add("§7- " + i.message());
                } else if (!a.enabled) {
                    mat = Items.YELLOW_CONCRETE;
                    lore.add("§eReady - click and press Enable");
                } else {
                    mat = Items.LIME_CONCRETE;
                    lore.add("§aEnabled and playable");
                }
                lore.add("§7Dimension: §f" + a.dim());
                int extra = ArenaManager.of(t).size() - 1;
                if (extra > 0) lore.add("§7+ " + extra + " extra arena(s)");
            }
            lore.add(" ");
            lore.add("§eClick: §fset up the arena");
            lore.add("§eRight-click: §fextra arenas (optional)");
        }
        return icon(mat, step + t.color + t.display, lore);
    }
}
