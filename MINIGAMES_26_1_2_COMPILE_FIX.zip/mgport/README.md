# MINIGAMES network (Fabric, Minecraft 26.1.2, Java 25)

Owner: HANZALA

This project combines BedWars, Hide & Seek, TNT Run, Floor Is Lava, and Red Light Green Light under the `/mg` menu and admin force-command system.

## Target platform
- Minecraft Java Edition 26.1.2
- Fabric Loader 0.19.3+
- Fabric API 0.155.3+26.1.2
- Java 25

See `BUILDING.md` for the toolchain and build instructions.

**Porting note:** This is a 26.1.2 migration baseline. The source code originated on 1.21.8 and must pass the 26.1.2 compiler/build before it can be considered a working 26.1.2 mod. Minecraft 26.1 changes mappings, Fabric Loom, APIs, and other internals; changing version numbers alone is not sufficient.
