# MINIGAMES

Target: Minecraft Java Edition 26.1.2, Fabric, Java 25.

Games: BedWars, Hide & Seek, TNT Run, Floor Is Lava, and Red Light Green Light.

The `/mg` command opens the shared minigames interface. Admin force commands select a game for players, while the network uses one common lobby.

Build and compatibility status: see the root `BUILDING.md`. This is a source migration baseline and is not certified until the 26.1.2 GitHub Actions build passes and gameplay is tested on a 26.1.2 Fabric server.
