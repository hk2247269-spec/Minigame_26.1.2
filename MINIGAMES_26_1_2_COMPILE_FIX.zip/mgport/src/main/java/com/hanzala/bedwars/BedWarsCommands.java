package com.hanzala.bedwars;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

import java.util.List;
import java.util.Map;

public final class BedWarsCommands {
    private BedWarsCommands() { }

    private static final SuggestionProvider<CommandSourceStack> TEAM_SUGGEST =
            (ctx, b) -> SharedSuggestionProvider.suggest(BedWarsGameManager.TEAMS, b);
    private static final SuggestionProvider<CommandSourceStack> TEAM_OR_NEUTRAL =
            (ctx, b) -> SharedSuggestionProvider.suggest(List.of("red", "blue", "green", "yellow", "pink", "white", "neutral"), b);
    private static final SuggestionProvider<CommandSourceStack> GEN_TYPES =
            (ctx, b) -> SharedSuggestionProvider.suggest(List.of("iron", "gold", "diamond", "emerald"), b);
    private static final SuggestionProvider<CommandSourceStack> SHOP_ITEMS =
            (ctx, b) -> SharedSuggestionProvider.suggest(BedWarsShop.offerIds(), b);
    private static final SuggestionProvider<CommandSourceStack> ARMOR_TIERS =
            (ctx, b) -> SharedSuggestionProvider.suggest(List.of("chain", "iron", "diamond"), b);

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(root()));
    }

    private static boolean admin(CommandSourceStack s) { return s.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_GAMEMASTER); }

    private static LiteralArgumentBuilder<CommandSourceStack> root() {
        return Commands.literal("bw")
                .executes(ctx -> help(ctx.getSource()))
                .then(Commands.literal("help").executes(ctx -> help(ctx.getSource())))
                .then(menu())
                .then(Commands.literal("teams").executes(ctx -> teams(ctx.getSource())))
                .then(Commands.literal("stats")
                        .executes(ctx -> stats(ctx.getSource(), ctx.getSource().getPlayerOrException()))
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(ctx -> stats(ctx.getSource(), EntityArgument.getPlayer(ctx, "player")))))
                .then(Commands.literal("top").executes(ctx -> {
                    for (String line : StatsManager.top(5)) ctx.getSource().sendSuccess(() -> Component.literal(line), false);
                    return 1;
                }))
                .then(Commands.literal("tc").then(Commands.argument("message", StringArgumentType.greedyString())
                        .executes(ctx -> teamChat(ctx.getSource(), StringArgumentType.getString(ctx, "message")))))
                .then(Commands.literal("reload").requires(BedWarsCommands::admin).executes(ctx -> {
                    Settings.load();
                    ShopConfig.load();
                    ctx.getSource().sendSuccess(() -> Component.literal("BedWars settings and shop reloaded."), true);
                    return 1;
                }))
                .then(Commands.literal("status").executes(ctx -> {
                    ctx.getSource().sendSuccess(() -> Component.literal(BedWarsMod.GAME.status()), false);
                    return 1;
                }))
                .then(team())
                .then(shop())
                .then(generator())
                .then(Commands.literal("start").requires(BedWarsCommands::admin).executes(ctx -> start(ctx.getSource())))
                .then(Commands.literal("stop").requires(BedWarsCommands::admin).executes(ctx -> {
                    if (!BedWarsMod.GAME.stop(ctx.getSource().getServer())) {
                        ctx.getSource().sendFailure(Component.literal("No match or countdown is running."));
                        return 0;
                    }
                    return 1;
                }))
                .then(Commands.literal("admin").requires(BedWarsCommands::admin).executes(ctx -> {
                    AdminMenu.open(ctx.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("setup").requires(BedWarsCommands::admin).executes(ctx -> {
                    for (String line : BedWarsMod.GAME.setupReport()) ctx.getSource().sendSuccess(() -> Component.literal(line), false);
                    return 1;
                })
                        .then(Commands.literal("clear")
                                .executes(ctx -> clearSetupWarning(ctx.getSource()))
                                .then(Commands.literal("confirm").executes(ctx -> clearSetup(ctx.getSource())))))
                .then(Commands.literal("spawn").then(Commands.literal("set").requires(BedWarsCommands::admin)
                        .then(Commands.argument("team", StringArgumentType.word()).suggests(TEAM_SUGGEST).executes(ctx -> {
                            ServerPlayer player = ctx.getSource().getPlayerOrException();
                            String team = BedWarsGameManager.normalizeTeam(StringArgumentType.getString(ctx, "team"));
                            if (team == null) { ctx.getSource().sendFailure(Component.literal("Team must be red, blue, green, yellow, pink or white.")); return 0; }
                            BedWarsMod.GAME.setSpawn(player, team);
                            ctx.getSource().sendSuccess(() -> Component.literal("Set the " + team + " team spawn/respawn point."), true);
                            return 1;
                        }))))
                .then(Commands.literal("lobby")
                        .executes(ctx -> {
                            if (!BedWarsMod.GAME.hasLobby()) { ctx.getSource().sendFailure(Component.literal("No lobby set. An operator can use /bw lobby set.")); return 0; }
                            BedWarsMod.GAME.teleportToLobby(ctx.getSource().getPlayerOrException());
                            return 1;
                        })
                        .then(Commands.literal("set").requires(BedWarsCommands::admin).executes(ctx -> {
                            BedWarsMod.GAME.setLobby(ctx.getSource().getPlayerOrException());
                            ctx.getSource().sendSuccess(() -> Component.literal("Lobby spawn set at your position."), true);
                            return 1;
                        })))
                .then(Commands.literal("bed").then(Commands.literal("set").requires(BedWarsCommands::admin)
                        .then(Commands.argument("team", StringArgumentType.word()).suggests(TEAM_SUGGEST).executes(ctx -> setBed(ctx.getSource(),
                                StringArgumentType.getString(ctx, "team"))))))
                .then(region())
                .then(Commands.literal("npc").requires(BedWarsCommands::admin)
                        .then(Commands.literal("add").executes(ctx -> {
                            boolean ok = ShopNpc.spawn(ctx.getSource());
                            if (ok) ctx.getSource().sendSuccess(() -> Component.literal("Shop villager placed. Right-click it to open the shop."), true);
                            else ctx.getSource().sendFailure(Component.literal("Could not spawn the shop villager."));
                            return ok ? 1 : 0;
                        }))
                        .then(Commands.literal("remove").executes(ctx -> {
                            boolean ok = ShopNpc.removeNearest(ctx.getSource());
                            if (ok) ctx.getSource().sendSuccess(() -> Component.literal("Removed the nearest shop villager."), true);
                            else ctx.getSource().sendFailure(Component.literal("No shop villager within 4 blocks."));
                            return ok ? 1 : 0;
                        })));
    }

    // ------------------------------------------------------------------ simple commands

    private static int help(CommandSourceStack s) {
        s.sendSuccess(() -> Component.literal("✦ BEDWARS ✦").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
        s.sendSuccess(() -> Component.literal("§e/bw menu §7team GUI   §e/bw shop §7open shop   §e/bw lobby §7go to lobby"), false);
        s.sendSuccess(() -> Component.literal("§e/bw teams §7rosters   §e/bw status §7game info   §e/bw generator upgrade"), false);
        s.sendSuccess(() -> Component.literal("§e/bw tc <msg> §7team chat   §e/bw stats [player]   §e/bw top §7leaderboard"), false);
        if (admin(s)) {
            s.sendSuccess(() -> Component.literal("§6Admin: §e/bw admin §7(admin GUI)  /bw setup  /bw setup clear  /bw start  /bw stop  /bw reload"), false);
            s.sendSuccess(() -> Component.literal("§6Setup: §7/bw lobby set | spawn set <team> | bed set <team> | region add | generator add | npc add"), false);
        }
        return 1;
    }


    /** /bw menu opens the team-selection chest GUI (no chat buttons). */
    private static LiteralArgumentBuilder<CommandSourceStack> menu() {
        return Commands.literal("menu").executes(ctx -> {
            TeamMenu.open(ctx.getSource().getPlayerOrException());
            return 1;
        });
    }

    private static int teams(CommandSourceStack s) {
        Map<String, List<String>> roster = BedWarsMod.GAME.getTeamRoster(s.getServer());
        s.sendSuccess(() -> Component.literal("§6§lTEAM SELECTION §7(2–6 teams; no auto-balance)"), false);
        roster.forEach((team, players) -> s.sendSuccess(() -> Component.literal(BedWarsGameManager.label(team)
                + " §7(" + players.size() + "): §f" + (players.isEmpty() ? "—" : String.join(", ", players))), false));
        return 1;
    }

    private static int stats(CommandSourceStack s, ServerPlayer target) {
        for (String line : StatsManager.statLines(target.getGameProfile().getName(), StatsManager.get(target.getUUID()))) {
            s.sendSuccess(() -> Component.literal(line), false);
        }
        return 1;
    }

    private static int teamChat(CommandSourceStack s, String message) throws CommandSyntaxException {
        ServerPlayer sender = s.getPlayerOrException();
        String team = BedWarsMod.GAME.teamOf(sender);
        if (team == null) { s.sendFailure(Component.literal("Join a team first (/bw menu).")); return 0; }
        String clean = message.replace('§', ' ');
        Component line = Component.literal(BedWarsGameManager.color(team) + "[TEAM] §f" + sender.getGameProfile().getName() + "§7: §f" + clean);
        for (ServerPlayer p : s.getServer().getPlayerList().getPlayers()) {
            if (team.equals(BedWarsMod.GAME.teamOf(p))) p.sendSystemMessage(line);
        }
        return 1;
    }

    /** /bw setup clear: explains what will be removed. Nothing is changed until "confirm" is added. */
    private static int clearSetupWarning(CommandSourceStack s) {
        s.sendSuccess(() -> Component.literal("§c§lThis removes the WHOLE arena setup:"), false);
        s.sendSuccess(() -> Component.literal("§7- lobby, all team spawns and all registered beds (bed blocks stay in the world)"), false);
        s.sendSuccess(() -> Component.literal("§7- all generators and generator tiers"), false);
        s.sendSuccess(() -> Component.literal("§7- all protected regions"), false);
        s.sendSuccess(() -> Component.literal("§7- all shop villagers"), false);
        s.sendSuccess(() -> Component.literal("§7Shop prices, settings and player teams are kept."), false);
        s.sendSuccess(() -> Component.literal("§eRun §6/bw setup clear confirm §eto do it."), false);
        return 1;
    }

    /** /bw setup clear confirm: wipes lobby, spawns, beds, generators, protected regions and shop villagers. */
    private static int clearSetup(CommandSourceStack s) {
        if (BedWarsMod.GAME.isRunning() || BedWarsMod.GAME.isCountingDown()) {
            s.sendFailure(Component.literal("Stop the match or countdown first (/bw stop), then clear the setup."));
            return 0;
        }
        String basics = BedWarsMod.GAME.clearSetup();
        int generators = BedWarsGeneratorManager.clearAll();
        int regions = BedWarsMod.PROTECTION.clearRegions();
        int npcs = ShopNpc.removeAll(s.getServer());
        s.sendSuccess(() -> Component.literal("§aSetup cleared: §f" + basics + ", " + generators + " generator(s), "
                + regions + " protected region(s), " + npcs + " shop villager(s)."), true);
        return 1;
    }

    private static int start(CommandSourceStack s) {
        List<String> problems = BedWarsMod.GAME.start(s.getServer());
        if (problems.isEmpty()) return 1;
        s.sendFailure(Component.literal("Cannot start the match:"));
        for (String p : problems) s.sendFailure(Component.literal(" - " + p));
        return 0;
    }

    private static int setBed(CommandSourceStack s, String teamArg) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = s.getPlayerOrException();
        String team = BedWarsGameManager.normalizeTeam(teamArg);
        if (team == null) { s.sendFailure(Component.literal("Team must be red, blue, green, yellow, pink or white.")); return 0; }
        if (trySetBed(player, team)) {
            s.sendSuccess(() -> Component.literal("Registered the " + team + " team bed."), true);
            return 1;
        }
        s.sendFailure(Component.literal("Look at (or stand on) a bed block and run this command again."));
        return 0;
    }

    /** Registers the bed the player is looking at, standing in or standing on. Also used by the admin GUI. */
    static boolean trySetBed(ServerPlayer player, String team) {
        ServerLevel level = (ServerLevel) player.level();
        BlockPos[] candidates = new BlockPos[3];
        HitResult hit = player.pick(6.0, 1.0F, false);
        candidates[0] = hit instanceof BlockHitResult bhr ? bhr.getBlockPos() : player.blockPosition();
        candidates[1] = player.blockPosition();
        candidates[2] = player.blockPosition().below();
        for (BlockPos pos : candidates) {
            if (BedWarsMod.GAME.setBed(level, pos, team)) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ team

    private static LiteralArgumentBuilder<CommandSourceStack> team() {
        return Commands.literal("team")
                .executes(ctx -> { TeamMenu.open(ctx.getSource().getPlayerOrException()); return 1; })
                .then(Commands.literal("join").then(Commands.argument("team", StringArgumentType.word()).suggests(TEAM_SUGGEST).executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    String raw = StringArgumentType.getString(ctx, "team");
                    if (!BedWarsMod.GAME.assignTeam(player, raw)) {
                        ctx.getSource().sendFailure(Component.literal("Invalid team or a match is already running. Available: red, blue, green, yellow, pink, white."));
                        return 0;
                    }
                    String t = BedWarsGameManager.normalizeTeam(raw);
                    ctx.getSource().sendSuccess(() -> Component.literal("You joined " + BedWarsGameManager.label(t) + "§r. Unequal team sizes are allowed."), false);
                    return 1;
                })))
                .then(Commands.literal("leave").executes(ctx -> {
                    if (!BedWarsMod.GAME.leaveTeam(ctx.getSource().getPlayerOrException())) {
                        ctx.getSource().sendFailure(Component.literal("You cannot leave a team during a match, or you were not in a team."));
                        return 0;
                    }
                    ctx.getSource().sendSuccess(() -> Component.literal("You left your team."), false);
                    return 1;
                }))
                .then(Commands.literal("set").requires(BedWarsCommands::admin)
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("team", StringArgumentType.word()).suggests(TEAM_SUGGEST).executes(ctx -> {
                                    ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                                    String raw = StringArgumentType.getString(ctx, "team");
                                    if (!BedWarsMod.GAME.assignTeamByAdmin(target, raw)) {
                                        ctx.getSource().sendFailure(Component.literal("Invalid team. Use red, blue, green, yellow, pink or white."));
                                        return 0;
                                    }
                                    ctx.getSource().sendSuccess(() -> Component.literal("Moved " + target.getGameProfile().getName() + " to " + raw + "."), true);
                                    target.sendSystemMessage(Component.literal("An admin moved you to team " + raw + "."));
                                    return 1;
                                }))));
    }

    // ------------------------------------------------------------------ shop / generators / regions

    private static LiteralArgumentBuilder<CommandSourceStack> shop() {
        return Commands.literal("shop")
                .executes(ctx -> { BedWarsShop.open(ctx.getSource().getPlayerOrException()); return 1; })
                .then(Commands.literal("list").executes(ctx -> { BedWarsShop.list(ctx.getSource().getPlayerOrException()); return 1; }))
                .then(Commands.literal("buy").then(Commands.argument("item", StringArgumentType.word()).suggests(SHOP_ITEMS).executes(ctx ->
                        BedWarsShop.buy(ctx.getSource().getPlayerOrException(), StringArgumentType.getString(ctx, "item")) ? 1 : 0)))
                .then(Commands.literal("armor").then(Commands.argument("tier", StringArgumentType.word()).suggests(ARMOR_TIERS).executes(ctx ->
                        BedWarsShop.buyArmor(ctx.getSource().getPlayerOrException(), StringArgumentType.getString(ctx, "tier")) ? 1 : 0)));
    }

    private static LiteralArgumentBuilder<CommandSourceStack> generator() {
        return Commands.literal("generator")
                .then(Commands.literal("upgrade").executes(ctx -> BedWarsGeneratorManager.upgrade(ctx.getSource().getPlayerOrException()) ? 1 : 0))
                .then(Commands.literal("list").requires(BedWarsCommands::admin).executes(ctx -> {
                    for (String line : BedWarsGeneratorManager.listLines()) ctx.getSource().sendSuccess(() -> Component.literal(line), false);
                    return 1;
                }))
                .then(Commands.literal("add").requires(BedWarsCommands::admin)
                        .then(Commands.argument("type", StringArgumentType.word()).suggests(GEN_TYPES)
                                .then(Commands.argument("team", StringArgumentType.word()).suggests(TEAM_OR_NEUTRAL).executes(ctx -> {
                                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                                    String type = StringArgumentType.getString(ctx, "type");
                                    String team = StringArgumentType.getString(ctx, "team");
                                    if (!BedWarsGeneratorManager.add((ServerLevel) player.level(), player.blockPosition(), type, team)) {
                                        ctx.getSource().sendFailure(Component.literal("Use /bw generator add <iron|gold|diamond|emerald> <team|neutral> while standing at the generator in the Overworld."));
                                        return 0;
                                    }
                                    ctx.getSource().sendSuccess(() -> Component.literal("Generator registered at your position."), true);
                                    return 1;
                                }))))
                .then(Commands.literal("remove").requires(BedWarsCommands::admin).executes(ctx -> {
                    boolean removed = BedWarsGeneratorManager.remove(ctx.getSource().getPlayerOrException().blockPosition());
                    if (removed) ctx.getSource().sendSuccess(() -> Component.literal("Generator removed."), true);
                    else ctx.getSource().sendFailure(Component.literal("No generator registered at your position."));
                    return removed ? 1 : 0;
                }));
    }

    private static LiteralArgumentBuilder<CommandSourceStack> region() {
        return Commands.literal("region").requires(BedWarsCommands::admin)
                .then(Commands.literal("add").then(Commands.argument("name", StringArgumentType.word())
                        .then(Commands.argument("from", BlockPosArgument.blockPos())
                                .then(Commands.argument("to", BlockPosArgument.blockPos()).executes(ctx -> {
                                    BlockPos a = BlockPosArgument.getBlockPos(ctx, "from");
                                    BlockPos b = BlockPosArgument.getBlockPos(ctx, "to");
                                    BedWarsMod.PROTECTION.addRegion(StringArgumentType.getString(ctx, "name"), ctx.getSource().getLevel().dimension(), a, b);
                                    ctx.getSource().sendSuccess(() -> Component.literal("Protected region saved."), true);
                                    return 1;
                                })))))
                .then(Commands.literal("remove").then(Commands.argument("name", StringArgumentType.word()).executes(ctx -> {
                    boolean ok = BedWarsMod.PROTECTION.removeRegion(StringArgumentType.getString(ctx, "name"));
                    if (ok) ctx.getSource().sendSuccess(() -> Component.literal("Protected region removed."), true);
                    else ctx.getSource().sendFailure(Component.literal("No such region."));
                    return ok ? 1 : 0;
                })))
                .then(Commands.literal("list").executes(ctx -> {
                    if (BedWarsMod.PROTECTION.regions().isEmpty()) ctx.getSource().sendSuccess(() -> Component.literal("No protected regions."), false);
                    BedWarsMod.PROTECTION.regions().forEach(r -> ctx.getSource().sendSuccess(() -> Component.literal(r.describe()), false));
                    return 1;
                }));
    }
}
