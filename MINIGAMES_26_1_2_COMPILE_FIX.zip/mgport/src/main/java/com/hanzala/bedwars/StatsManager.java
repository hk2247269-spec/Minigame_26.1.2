package com.hanzala.bedwars;

import net.minecraft.server.level.ServerPlayer;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Per-match and lifetime statistics (config/bedwars/stats.txt). */
public final class StatsManager {
    private StatsManager() { }

    public static final class Rec {
        String name = "?";
        int games, wins, kills, finals, beds, deaths;
    }

    // match counters: [0]=kills (finals included) [1]=final kills [2]=beds [3]=deaths
    private static final Map<UUID, Rec> TOTAL = new HashMap<>();
    private static final Map<UUID, int[]> MATCH = new HashMap<>();
    private static boolean dirty;
    private static int flushTicks;

    private static Path file() { return BedWarsMod.configDir().resolve("stats.txt"); }

    public static void load() {
        TOTAL.clear();
        MATCH.clear();
        dirty = false;
        Path f = file();
        try {
            if (!Files.exists(f)) return;
            for (String raw : Files.readAllLines(f)) {
                String line = raw.split("#", 2)[0].trim();
                if (line.isEmpty()) continue;
                String[] p = line.split("\\s+");
                if (p.length != 8) continue;
                try {
                    Rec r = new Rec();
                    r.games = Integer.parseInt(p[1]); r.wins = Integer.parseInt(p[2]); r.kills = Integer.parseInt(p[3]);
                    r.finals = Integer.parseInt(p[4]); r.beds = Integer.parseInt(p[5]); r.deaths = Integer.parseInt(p[6]);
                    r.name = p[7];
                    TOTAL.put(UUID.fromString(p[0]), r);
                } catch (RuntimeException ignored) { }
            }
        } catch (IOException ex) { BedWarsMod.LOGGER.error("Could not read stats.txt", ex); }
    }

    public static void save() {
        List<String> lines = new ArrayList<>();
        lines.add("# uuid games wins kills finals beds deaths name");
        for (Map.Entry<UUID, Rec> e : TOTAL.entrySet()) {
            Rec r = e.getValue();
            lines.add(e.getKey() + " " + r.games + " " + r.wins + " " + r.kills + " " + r.finals + " " + r.beds + " " + r.deaths + " " + r.name);
        }
        try { Files.write(file(), lines); dirty = false; }
        catch (IOException ex) { BedWarsMod.LOGGER.error("Could not save stats.txt", ex); }
    }

    /** Called every server tick: flushes pending changes about once a minute. */
    public static void tick() {
        if (dirty && ++flushTicks >= 1200) { flushTicks = 0; save(); }
    }

    private static Rec rec(ServerPlayer p) {
        Rec r = TOTAL.computeIfAbsent(p.getUUID(), k -> new Rec());
        r.name = p.getGameProfile().getName();
        return r;
    }

    private static int[] match(ServerPlayer p) { return MATCH.computeIfAbsent(p.getUUID(), k -> new int[4]); }

    public static Rec get(UUID id) { return TOTAL.get(id); }

    /** Kills (final kills included) the player has in the current match. */
    public static int matchKills(UUID id) {
        int[] m = MATCH.get(id);
        return m == null ? 0 : m[0];
    }

    public static void startMatch(Collection<ServerPlayer> participants) {
        MATCH.clear();
        for (ServerPlayer p : participants) {
            rec(p).games++;
            match(p);
        }
        dirty = true;
    }

    public static void kill(ServerPlayer killer, boolean finalKill) {
        Rec r = rec(killer);
        int[] m = match(killer);
        r.kills++; m[0]++;
        if (finalKill) { r.finals++; m[1]++; }
        dirty = true;
    }

    public static void bed(ServerPlayer player) { rec(player).beds++; match(player)[2]++; dirty = true; }

    public static void death(ServerPlayer player) { rec(player).deaths++; match(player)[3]++; dirty = true; }

    /** Closes the match: credits the winners and returns the summary lines to broadcast. */
    public static List<String> finish(Set<UUID> winners, String winnerLabel) {
        for (UUID id : winners) {
            Rec r = TOTAL.get(id);
            if (r != null) r.wins++;
        }
        List<String> out = new ArrayList<>();
        out.add("§6§m     §r §6§lMATCH SUMMARY §6§m     ");
        out.add("§eWinner: " + (winnerLabel == null ? "§7nobody" : winnerLabel));
        List<Map.Entry<UUID, int[]>> ranked = new ArrayList<>(MATCH.entrySet());
        ranked.removeIf(e -> e.getValue()[0] <= 0);
        ranked.sort((a, b) -> Integer.compare(b.getValue()[0], a.getValue()[0]));
        int shown = 0;
        for (Map.Entry<UUID, int[]> e : ranked) {
            if (shown++ >= 3) break;
            Rec r = TOTAL.get(e.getKey());
            out.add("§e" + shown + ". §f" + (r == null ? "?" : r.name) + " §7- §f" + e.getValue()[0] + " kills §8(" + e.getValue()[1] + " final)");
        }
        if (ranked.isEmpty()) out.add("§7No kills this match.");
        int bestBeds = 0;
        for (int[] m : MATCH.values()) bestBeds = Math.max(bestBeds, m[2]);
        if (bestBeds > 0) {
            List<String> names = new ArrayList<>();
            for (Map.Entry<UUID, int[]> e : MATCH.entrySet()) {
                if (e.getValue()[2] == bestBeds) { Rec r = TOTAL.get(e.getKey()); names.add(r == null ? "?" : r.name); }
            }
            out.add("§eMost beds: §f" + String.join(", ", names) + " §7(" + bestBeds + ")");
        }
        dirty = true;
        save();
        return out;
    }

    public static List<String> statLines(String name, Rec r) {
        List<String> out = new ArrayList<>();
        out.add("§6§lBEDWARS STATS §r§f" + name);
        if (r == null || r.games == 0) { out.add("§7No games played yet."); return out; }
        double kd = r.deaths == 0 ? r.kills : (double) r.kills / r.deaths;
        out.add("§eGames: §f" + r.games + " §8| §eWins: §f" + r.wins);
        out.add("§eKills: §f" + r.kills + " §8(§f" + r.finals + " §8final) | §eDeaths: §f" + r.deaths);
        out.add("§eBeds destroyed: §f" + r.beds + " §8| §eK/D: §f" + String.format(Locale.ROOT, "%.2f", kd));
        return out;
    }

    public static List<String> top(int count) {
        List<Rec> all = new ArrayList<>(TOTAL.values());
        all.removeIf(r -> r.games == 0);
        all.sort((a, b) -> a.wins != b.wins ? Integer.compare(b.wins, a.wins) : Integer.compare(b.kills, a.kills));
        List<String> out = new ArrayList<>();
        out.add("§6§lBEDWARS TOP PLAYERS §7(wins, then kills)");
        if (all.isEmpty()) { out.add("§7Nobody has played yet."); return out; }
        for (int i = 0; i < Math.min(count, all.size()); i++) {
            Rec r = all.get(i);
            out.add("§e" + (i + 1) + ". §f" + r.name + " §7- §f" + r.wins + " wins §8| §f" + r.kills + " kills");
        }
        return out;
    }
}
