package com.hanzala.minigames;

import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * One arena of one minigame (stored in config/minigames/arenas.json). Every arena lives in the Overworld and has its own
 * boundary box, spawns, player limits and type-specific numbers ({@link #params}). The boundary box is also the ONLY area a
 * reset is ever allowed to touch.
 */
public final class Arena {
    public static final class Loc {
        public double x, y, z;
        public float yaw, pitch;

        public Loc() { }

        public static Loc of(ServerPlayer p) {
            Loc l = new Loc();
            l.x = p.getX(); l.y = p.getY(); l.z = p.getZ(); l.yaw = p.getYRot(); l.pitch = p.getXRot();
            return l;
        }
    }

    public String id;
    /** {@link MinigameType#id} */
    public String type;
    public String name;
    public boolean hasBox;
    public int x1, y1, z1, x2, y2, z2;
    public boolean hasPos1, hasPos2;
    /** Where players wait before the match (falls back to the first spawn). */
    public Loc waiting;
    public Loc spectator;
    /** Red Light Green Light only: the finish line (also where the statue stands). See RedGreenSession for the convention. */
    public Loc finish;
    public List<Loc> spawns = new ArrayList<>();
    public int minPlayers = 2;
    public int maxPlayers = 16;
    /** Type-specific numbers, e.g. tnt: delay (ticks); lava: startY, riseSeconds; rg: see the handoff document. */
    public Map<String, Double> params = new LinkedHashMap<>();

    public MinigameType type() { return MinigameType.byId(type); }

    public String displayName() { return name != null && !name.isBlank() ? name : id; }

    public double param(String key, double def) {
        Double v = params.get(key);
        return v == null ? def : v;
    }

    public int minX() { return Math.min(x1, x2); }
    public int maxX() { return Math.max(x1, x2); }
    public int minY() { return Math.min(y1, y2); }
    public int maxY() { return Math.max(y1, y2); }
    public int minZ() { return Math.min(z1, z2); }
    public int maxZ() { return Math.max(z1, z2); }

    /** Both corners are known. */
    public void updateBox() { hasBox = hasPos1 && hasPos2; }

    public boolean contains(double x, double y, double z) {
        return hasBox && x >= minX() && x < maxX() + 1 && y >= minY() && y < maxY() + 1 && z >= minZ() && z < maxZ() + 1;
    }

    public boolean containsXZ(double x, double z) {
        return hasBox && x >= minX() && x < maxX() + 1 && z >= minZ() && z < maxZ() + 1;
    }

    public boolean overlaps(Arena o) {
        if (!hasBox || !o.hasBox) return false;
        return minX() <= o.maxX() && maxX() >= o.minX()
                && minY() <= o.maxY() && maxY() >= o.minY()
                && minZ() <= o.maxZ() && maxZ() >= o.minZ();
    }

    public Loc waitingSpot() { return waiting != null ? waiting : (spawns.isEmpty() ? null : spawns.get(0)); }

    public Loc spectatorSpot() {
        if (spectator != null) return spectator;
        Loc l = new Loc();
        l.x = (minX() + maxX() + 1) / 2.0;
        l.z = (minZ() + maxZ() + 1) / 2.0;
        l.y = maxY() + 3;
        return l;
    }

    /** What is still missing for this arena to be playable, or null when it is ready. */
    public String missing() {
        List<String> m = new ArrayList<>();
        if (!hasBox) m.add("boundaries (/mg arena pos1 + pos2)");
        if (spawns.isEmpty()) m.add("a spawn (/mg arena spawn add)");
        if (hasBox) {
            for (Loc s : spawns) {
                if (!contains(s.x, s.y, s.z)) { m.add("all spawns inside the boundaries"); break; }
            }
        }
        if ("rg".equalsIgnoreCase(type)) {
            if (finish == null) m.add("a finish line (/mg arena finish)");
            else if (hasBox && !contains(finish.x, finish.y, finish.z)) m.add("the finish inside the boundaries");
        }
        if (minPlayers < 2) m.add("min players >= 2");
        if (maxPlayers < minPlayers) m.add("max players >= min players");
        return m.isEmpty() ? null : String.join(", ", m);
    }
}
