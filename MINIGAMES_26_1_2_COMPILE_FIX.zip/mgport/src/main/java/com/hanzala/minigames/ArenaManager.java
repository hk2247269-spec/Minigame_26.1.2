package com.hanzala.minigames;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Loads / saves arenas.json and answers "which arenas exist for this game". Arena ids are unique across all games. */
public final class ArenaManager {
    private ArenaManager() { }

    private static final class Data { List<Arena> arenas = new ArrayList<>(); }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Map<String, Arena> ARENAS = new LinkedHashMap<>();

    private static Path file() { return MgSettings.dir().resolve("arenas.json"); }

    public static void load() {
        ARENAS.clear();
        Path f = file();
        try {
            if (Files.exists(f)) {
                Data d = GSON.fromJson(Files.readString(f), Data.class);
                if (d != null && d.arenas != null) for (Arena a : d.arenas) if (a != null && a.id != null) ARENAS.put(a.id.toLowerCase(), a);
            } else {
                save();
            }
        } catch (Exception e) {
            MgMod.LOG.error("Could not read arenas.json (arenas not loaded - fix the file or delete it)", e);
        }
    }

    public static void save() {
        try {
            Data d = new Data();
            d.arenas.addAll(ARENAS.values());
            Files.writeString(file(), GSON.toJson(d));
        } catch (Exception e) {
            MgMod.LOG.error("Could not save arenas.json", e);
        }
    }

    public static Arena get(String id) { return id == null ? null : ARENAS.get(id.toLowerCase()); }

    public static List<Arena> all() { return new ArrayList<>(ARENAS.values()); }

    public static List<Arena> of(MinigameType t) {
        List<Arena> out = new ArrayList<>();
        for (Arena a : ARENAS.values()) if (t.id.equals(a.type)) out.add(a);
        return out;
    }

    /** Returns an error text or null. */
    public static String create(MinigameType t, String id) {
        if (t.external) return t.display + " has its own arena setup (see its own commands).";
        if (!id.matches("[A-Za-z0-9_\\-]{1,24}")) return "Arena id: 1-24 letters, digits, _ or -.";
        if (ARENAS.containsKey(id.toLowerCase())) return "An arena with that id already exists.";
        Arena a = new Arena();
        a.id = id;
        a.type = t.id;
        a.name = id;
        ARENAS.put(id.toLowerCase(), a);
        save();
        return null;
    }

    public static boolean remove(String id) {
        boolean r = ARENAS.remove(id.toLowerCase()) != null;
        if (r) save();
        return r;
    }

    /**
     * Safety check run before an arena is used: complete, not overlapping another arena, not covering the common lobby.
     * Returns a problem text or null when the arena is safe to play and reset.
     */
    public static String problem(Arena a) {
        String m = a.missing();
        if (m != null) return "not set up yet - missing: " + m;
        for (Arena o : ARENAS.values()) {
            if (o != a && a.overlaps(o)) return "overlaps arena '" + o.id + "'";
        }
        double[] lobby = com.hanzala.bedwars.BedWarsMod.GAME.lobbyCoords();
        if (lobby != null && a.contains(lobby[0], lobby[1], lobby[2])) return "covers the common lobby";
        // keep a margin of 3 blocks around the lobby spawn as well
        if (lobby != null && lobby[0] >= a.minX() - 3 && lobby[0] <= a.maxX() + 4 && lobby[2] >= a.minZ() - 3 && lobby[2] <= a.maxZ() + 4
                && lobby[1] >= a.minY() - 3 && lobby[1] <= a.maxY() + 4) return "is too close to the common lobby";
        return null;
    }
}
