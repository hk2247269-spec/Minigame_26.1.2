package com.hanzala.minigames;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.GameType;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * The shared lifecycle of every arena-based minigame (TNT Run, Floor Is Lava, Red Light Green Light):
 *
 * <pre>
 *   WAITING --(min players)--> COUNTDOWN --> STARTING --> ACTIVE --(winner / time)--> ENDING --> RESETTING --> WAITING
 * </pre>
 *
 * One session object exists per arena (created lazily by {@link Mg}). A game only implements the small hooks at the bottom:
 * what happens at the start, every tick while ACTIVE, and how its arena is reset. Joining, leaving, countdown, spectators,
 * winner detection, saving / restoring players, returning them to the common lobby and the sidebar are all done here.
 */
public abstract class GameSession {
    public enum State { WAITING, COUNTDOWN, STARTING, ACTIVE, ENDING, RESETTING }

    public final Arena arena;
    public final MinigameType type;
    protected final MinecraftServer server;
    protected final ServerLevel level;

    public State state = State.WAITING;
    /** Everyone in this session (alive + spectators). */
    protected final Set<UUID> players = new LinkedHashSet<>();
    protected final Set<UUID> alive = new LinkedHashSet<>();
    protected final Set<UUID> spectators = new LinkedHashSet<>();
    protected final List<UUID> eliminationOrder = new ArrayList<>();
    protected int ticksLeft;
    protected int matchTicks;
    /** Set by "/mg <game> force": the countdown is not cancelled when the player count is below the minimum. */
    protected boolean forced;
    private String winnerText = "";

    protected GameSession(MinecraftServer server, Arena arena, MinigameType type) {
        this.server = server;
        this.arena = arena;
        this.type = type;
        this.level = server.overworld(); // every minigame lives in the Overworld
    }

    // ================================================================== hooks a game implements

    /** STARTING begins: players are on their spawns. Clear leftovers, prepare the arena. */
    protected abstract void onPrepare();

    /** ACTIVE begins (countdown is over): release the players, start timers, etc. */
    protected abstract void onStart();

    /** Called every tick while ACTIVE (after the shared per-tick work). */
    protected abstract void tickActive();

    /**
     * Restore the arena. Called every tick while RESETTING until it returns true. Must only touch blocks inside the arena box;
     * use a {@link BlockJournal} and restoreSome(level, MgSettings.I.resetBlocksPerTick).
     */
    protected abstract boolean resetStep();

    /** Extra sidebar lines for the ACTIVE state (the shared lines are added around them). */
    protected List<String> activeLines(ServerPlayer p) { return List.of(); }

    /** A player was eliminated (already moved to spectator). */
    protected void onEliminated(ServerPlayer p) { }

    /** Anything the game must clean up when a match is cancelled / finished (timers, entities...). Always called before RESETTING. */
    protected void onMatchOver() { }

    /** Called when the server stops while a match is on, to flush reset data synchronously. */
    public void flushToDisk() { }

    /** Hard time limit of a match in seconds (games may override, e.g. via an arena param). */
    protected int timeLimitSeconds() { return MgSettings.I.maxMatchSeconds; }

    /** Winners when the time limit is reached (default: everybody still alive = draw). */
    protected List<UUID> timeoutWinners() { return new ArrayList<>(alive); }

    // ================================================================== queries

    public boolean isIdle() { return state == State.WAITING && players.isEmpty(); }
    public boolean isJoinable() { return (state == State.WAITING || state == State.COUNTDOWN) && players.size() < arena.maxPlayers; }
    public boolean isRunning() { return state == State.STARTING || state == State.ACTIVE || state == State.ENDING; }
    public int playerCount() { return players.size(); }
    public boolean has(UUID id) { return players.contains(id); }
    public boolean isAlive(UUID id) { return alive.contains(id); }
    public boolean isSpectator(UUID id) { return spectators.contains(id); }
    public Set<UUID> playerIds() { return new LinkedHashSet<>(players); }

    public String stateLabel() {
        return switch (state) {
            case WAITING -> "§aWaiting";
            case COUNTDOWN -> "§eStarting soon";
            case STARTING -> "§eStarting";
            case ACTIVE -> "§cRunning";
            case ENDING -> "§cEnding";
            case RESETTING -> "§7Resetting";
        };
    }

    /** Why the arena cannot be joined right now, or null when it can. */
    public String joinProblem() {
        String problem = ArenaManager.problem(arena);
        if (problem != null) return "This arena is " + problem + ".";
        if (state == State.RESETTING) return "The arena is being reset - try again in a moment.";
        if (state != State.WAITING && state != State.COUNTDOWN) return "A match is already running in this arena.";
        if (players.size() >= arena.maxPlayers) return "This arena is full (" + arena.maxPlayers + "/" + arena.maxPlayers + ").";
        return null;
    }

    protected ServerPlayer player(UUID id) { return server.getPlayerList().getPlayer(id); }

    protected List<ServerPlayer> online(Set<UUID> ids) {
        List<ServerPlayer> out = new ArrayList<>();
        for (UUID id : ids) {
            ServerPlayer p = player(id);
            if (p != null) out.add(p);
        }
        return out;
    }

    // ================================================================== join / leave

    /** Normal join. Returns an error text (shown to the player) or null on success. */
    public String join(ServerPlayer p) {
        String problem = joinProblem();
        if (problem != null) return problem;
        if (players.contains(p.getUUID())) return "You are already in this game.";
        // an old backup that is still waiting (failed restore / crash): give it back first so it is never mixed up with a new one
        if (PlayerStateStore.exists(p) && !PlayerStateStore.restore(p, server, false)) return "Your saved inventory could not be restored, so you were not moved. Tell an admin.";
        if (!PlayerStateStore.save(p)) return "Could not save your inventory, so you were not moved. Tell an admin.";
        PlayerStateStore.applyGameSettings(p, GameType.ADVENTURE);
        Lobby.giveLeaveItem(p);
        players.add(p.getUUID());
        alive.add(p.getUUID());
        Mg.bind(p.getUUID(), this);
        MgUtil.tp(p, arena.waitingSpot());
        MgUtil.snd(p, SoundEvents.ENDERMAN_TELEPORT, 0.6f, 1.2f);
        tell("§e" + p.getName().getString() + " §7joined §8(§f" + players.size() + "§8/§f" + arena.maxPlayers + "§8)");
        if (state == State.WAITING && players.size() >= arena.minPlayers) startCountdown(false);
        else if (state == State.COUNTDOWN && players.size() >= arena.maxPlayers) ticksLeft = Math.min(ticksLeft, 100);
        updateBoard(p);
        return null;
    }

    /** Removes a player (own choice, disconnect, command). Restores them and sends them to the common lobby. */
    public void leave(ServerPlayer p, String reason) {
        UUID id = p.getUUID();
        if (!players.remove(id)) return;
        boolean wasAlive = alive.remove(id);
        spectators.remove(id);
        Mg.unbind(id);
        returnToLobby(p);
        tell("§e" + p.getName().getString() + " §7left" + (reason == null || reason.isEmpty() ? "." : " (" + reason + ")."));
        if (wasAlive && (state == State.ACTIVE || state == State.STARTING)) eliminationOrder.add(id);
        afterPlayerGone();
    }

    private void afterPlayerGone() {
        if (state == State.COUNTDOWN && !forced && players.size() < arena.minPlayers) {
            state = State.WAITING;
            tell("§cNot enough players - countdown cancelled.");
        }
        if (state == State.ACTIVE || state == State.STARTING) {
            if (players.isEmpty()) { abort("Everyone left."); return; }
            if (state == State.STARTING && !forced && alive.size() < 2) { abort("Not enough players left."); return; }
            if (state == State.ACTIVE) checkWin();
        }
        if (state == State.ENDING && players.isEmpty()) finishEnding();
    }

    /** Restores the saved state, empties the sidebar and teleports the player to the common lobby. */
    protected void returnToLobby(ServerPlayer p) {
        MgBoard.hide(p);
        boolean restored = PlayerStateStore.restore(p, server, !Lobby.available());
        if (!restored) { // backup missing: at least make the player safe
            p.getInventory().clearContent();
            p.setGameMode(GameType.SURVIVAL);
            p.setHealth(p.getMaxHealth());
        }
        if (Lobby.available() || !restored) Lobby.send(p);
        Lobby.giveMenuItem(p);
        p.inventoryMenu.broadcastChanges();
    }

    // ================================================================== countdown / start

    /** Starts the countdown. forced = admin force: countdown is shorter and is not cancelled by a low player count. */
    public void startCountdown(boolean force) {
        if (state != State.WAITING && state != State.COUNTDOWN) return;
        forced = force;
        state = State.COUNTDOWN;
        ticksLeft = (force ? MgSettings.I.forceCountdownSeconds : MgSettings.I.countdownSeconds) * 20;
        tell("§aCountdown started!");
    }

    private void beginStarting() {
        if (players.size() < arena.minPlayers && !forced) { state = State.WAITING; tell("§cNot enough players."); return; }
        state = State.STARTING;
        ticksLeft = MgSettings.I.startingSeconds * 20;
        matchTicks = 0;
        eliminationOrder.clear();
        List<ServerPlayer> list = online(alive);
        for (int i = 0; i < list.size(); i++) {
            ServerPlayer p = list.get(i);
            MgUtil.tp(p, arena.spawns.get(i % arena.spawns.size()));
            MgUtil.title(p, type.color + "§l" + type.display.toUpperCase(), "§7Get ready!", 5, 40, 10);
        }
        onPrepare();
    }

    private void beginActive() {
        state = State.ACTIVE;
        for (ServerPlayer p : online(alive)) {
            MgUtil.title(p, "§a§lGO!", "§7Last one standing wins", 0, 25, 10);
            MgUtil.snd(p, SoundEvents.ENDER_DRAGON_GROWL, 0.5f, 1.2f);
        }
        onStart();
    }

    // ================================================================== elimination / winner

    /** Eliminate a player (alive -> spectator). Safe to call at any time; ignored unless the match is ACTIVE and the player alive. */
    public void eliminate(ServerPlayer p, String why) {
        if (state != State.ACTIVE || !alive.remove(p.getUUID())) return;
        spectators.add(p.getUUID());
        eliminationOrder.add(p.getUUID());
        p.setGameMode(GameType.SPECTATOR);
        MgUtil.tp(p, arena.spectatorSpot());
        MgUtil.title(p, "§c§lELIMINATED", "§7" + why, 0, 40, 10);
        p.sendSystemMessage(MgUtil.msg("You are spectating. Type §e/mg leave§7 to go back to the lobby."));
        MgUtil.snd(p, SoundEvents.ENDERMAN_DEATH, 0.8f, 1f);
        tell("§c" + p.getName().getString() + " §7" + why + " §8(§f" + alive.size() + " §7left§8)");
        onEliminated(p);
        checkWin();
    }

    /** Default: the match ends when one (or zero) players are alive. Games with other rules (finish line) override. */
    protected void checkWin() {
        if (state != State.ACTIVE) return;
        if (alive.size() > 1) return;
        UUID w = !alive.isEmpty() ? alive.iterator().next()
                : (eliminationOrder.isEmpty() ? null : eliminationOrder.get(eliminationOrder.size() - 1));
        end(w == null ? List.of() : List.of(w));
    }

    /** Declares the winners (may be empty = draw), celebrates, and schedules the return to the lobby. */
    protected void end(List<UUID> winners) {
        if (state != State.ACTIVE && state != State.STARTING) return;
        state = State.ENDING;
        ticksLeft = MgSettings.I.endDelaySeconds * 20;
        onMatchOver();
        List<String> names = new ArrayList<>();
        for (UUID w : winners) {
            ServerPlayer wp = player(w);
            if (wp != null) names.add(wp.getName().getString());
        }
        winnerText = names.isEmpty() ? "Nobody" : String.join(", ", names);
        server.getPlayerList().broadcastSystemMessage(Component.literal("§8[§bMinigames§8] " + type.color + "§l" + type.display
                + " §7- winner: §6§l" + winnerText), false);
        for (ServerPlayer p : online(players)) {
            boolean won = winners.contains(p.getUUID());
            MgUtil.title(p, won ? "§6§lVICTORY!" : "§c§lGAME OVER", "§7Winner: §e" + winnerText, 5, 60, 20);
            MgUtil.snd(p, won ? SoundEvents.PLAYER_LEVELUP : SoundEvents.ENDERMAN_DEATH, 1f, 1f);
        }
    }

    /** Cancels the match without a winner and starts the reset. Everybody goes back to the lobby. */
    public void abort(String reason) {
        if (state == State.RESETTING || (state == State.WAITING && players.isEmpty())) return;
        if (state == State.STARTING || state == State.ACTIVE) onMatchOver(); // ENDING already called it
        if (!players.isEmpty()) tell("§cMatch cancelled: " + reason);
        sendEveryoneHome();
        state = State.RESETTING;
        forced = false;
    }

    /** abort() + finish the reset right now (used by force commands and server shutdown). */
    public void abortAndResetNow(String reason) {
        abort(reason);
        if (state == State.RESETTING) {
            for (int guard = 0; guard < 1_000_000 && !resetStep(); guard++) { /* restore everything */ }
            flushToDisk();
            state = State.WAITING;
        }
    }

    private void finishEnding() {
        sendEveryoneHome();
        state = State.RESETTING;
        forced = false;
    }

    private void sendEveryoneHome() {
        for (UUID id : new ArrayList<>(players)) {
            Mg.unbind(id);
            ServerPlayer p = player(id);
            if (p != null) returnToLobby(p);
        }
        players.clear();
        alive.clear();
        spectators.clear();
    }

    // ================================================================== tick

    /** Called once per server tick by {@link Mg#tick}. */
    public void tick() {
        switch (state) {
            case WAITING -> { if (server.getTickCount() % 20 == 0) refreshBoards(); }
            case COUNTDOWN -> tickCountdown();
            case STARTING -> {
                if (--ticksLeft <= 0) beginActive();
                else if (ticksLeft % 20 == 0) refreshBoards();
            }
            case ACTIVE -> tickPlaying();
            case ENDING -> {
                if (--ticksLeft <= 0) finishEnding();
                else if (ticksLeft % 20 == 0) refreshBoards();
            }
            case RESETTING -> {
                if (resetStep()) { flushToDisk(); state = State.WAITING; }
            }
        }
    }

    private void tickCountdown() {
        if (ticksLeft % 20 == 0) {
            int s = ticksLeft / 20;
            if (s > 0 && (s <= 5 || s == 10 || s == 15 || s == 30)) {
                for (ServerPlayer p : online(players)) {
                    if (s <= 5) MgUtil.title(p, "§e§l" + s, "§7" + type.display, 0, 22, 0);
                    MgUtil.snd(p, SoundEvents.EXPERIENCE_ORB_PICKUP, 0.8f, 0.8f + (5 - Math.min(5, s)) * 0.1f);
                }
                tell("§7Starting in §e" + s + "§7 second" + (s == 1 ? "" : "s") + "...");
            }
            refreshBoards();
        }
        if (--ticksLeft <= 0) beginStarting();
    }

    private void tickPlaying() {
        matchTicks++;
        if (matchTicks % 20 == 0) {
            checkWin(); // also ends a forced 1-player match
            if (state != State.ACTIVE) return;
            refreshBoards();
            // spectators must not wander away from the arena
            for (ServerPlayer p : online(spectators)) {
                if (!arena.contains(p.getX(), p.getY(), p.getZ())) MgUtil.tp(p, arena.spectatorSpot());
            }
            // the leave button must stay in the hotbar (players can drop it)
            for (ServerPlayer p : online(players)) {
                Lobby.giveLeaveItem(p);
                p.getFoodData().setFoodLevel(20); // hunger never matters in a minigame
            }
        }
        if (matchTicks >= timeLimitSeconds() * 20) {
            tell("§eTime limit reached!");
            end(timeoutWinners());
            return;
        }
        tickActive();
    }

    // ================================================================== messages / sidebar

    /** Chat message for the players of this session only. */
    protected void tell(String text) {
        Component c = MgUtil.msg(text);
        for (ServerPlayer p : online(players)) p.sendSystemMessage(c);
    }

    protected void refreshBoards() {
        for (ServerPlayer p : online(players)) updateBoard(p);
    }

    protected void updateBoard(ServerPlayer p) {
        List<String> lines = new ArrayList<>();
        lines.add("§7Arena: §f" + arena.displayName());
        switch (state) {
            case WAITING -> {
                lines.add("§7Players: §f" + players.size() + "§8/§f" + arena.maxPlayers);
                lines.add("§eWaiting for " + Math.max(0, arena.minPlayers - players.size()) + " more...");
            }
            case COUNTDOWN -> {
                lines.add("§7Players: §f" + players.size() + "§8/§f" + arena.maxPlayers);
                lines.add("§eStarting in §f" + (ticksLeft + 19) / 20 + "s");
            }
            case STARTING -> {
                lines.add("§7Players: §f" + alive.size());
                lines.add("§eGet ready!");
            }
            case ACTIVE -> {
                lines.add("§7Alive: §a" + alive.size());
                lines.addAll(activeLines(p));
                int left = Math.max(0, timeLimitSeconds() - matchTicks / 20);
                lines.add("§7Time: §f" + left / 60 + ":" + String.format("%02d", left % 60));
                if (spectators.contains(p.getUUID())) lines.add("§8You are spectating");
            }
            case ENDING, RESETTING -> {
                lines.add("§6Winner: §f" + winnerText);
            }
        }
        MgBoard.show(p, type.color + "§l" + type.display.toUpperCase(), lines);
    }
}
