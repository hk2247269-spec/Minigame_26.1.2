package com.hanzala.minigames;

import com.hanzala.bedwars.BedWarsMod;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.Set;

/**
 * The ONE common server lobby. It is the lobby that /bw lobby set created - this class never stores or builds a lobby of its
 * own and never edits lobby blocks. Without a configured lobby the Overworld spawn is used.
 */
public final class Lobby {
    private Lobby() { }

    public static final String MENU_NAME = "§a§lMinigames Menu §7(Right-click)";
    public static final String LEAVE_NAME = "§c§lLeave Game §7(Right-click)";
    public static final int HOTBAR_SLOT = 8;

    public static boolean available() { return BedWarsMod.GAME.hasLobby(); }

    public static void send(ServerPlayer p) {
        MinecraftServer server = p.level().getServer();
        if (server == null) return;
        ServerLevel ow = server.overworld();
        if (!BedWarsMod.GAME.teleportToLobbyFrom(p, ow)) {
            BlockPos spawn = ow.getSharedSpawnPos();
            BlockPos top = ow.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, spawn);
            p.teleportTo(ow, top.getX() + 0.5, top.getY(), top.getZ() + 0.5, Set.<Relative>of(), p.getYRot(), p.getXRot(), true);
        }
        p.resetFallDistance();
    }

    public static boolean isMenuItem(ItemStack s) {
        return s != null && s.is(Items.COMPASS) && s.getHoverName().getString().contains("Minigames Menu");
    }

    public static boolean isLeaveItem(ItemStack s) {
        return s != null && s.is(Items.BARRIER) && s.getHoverName().getString().contains("Leave Game");
    }

    /** Puts the "reopen /mg menu" compass into slot 9 if that slot is free. Never replaces the player's own items. */
    public static void giveMenuItem(ServerPlayer p) {
        if (!MgSettings.I.giveMenuItem) return;
        var inv = p.getInventory();
        for (int i = 0; i < 36; i++) if (isMenuItem(inv.getItem(i))) return;
        if (inv.getItem(HOTBAR_SLOT).isEmpty()) inv.setItem(HOTBAR_SLOT, MgUtil.named(Items.COMPASS, MENU_NAME));
        else if (inv.getFreeSlot() >= 0) inv.add(MgUtil.named(Items.COMPASS, MENU_NAME));
    }

    /** In-game "leave" button in slot 9. Inventory is empty at that point, so this always fits. */
    public static void giveLeaveItem(ServerPlayer p) {
        var inv = p.getInventory();
        if (!isLeaveItem(inv.getItem(HOTBAR_SLOT))) inv.setItem(HOTBAR_SLOT, MgUtil.named(Items.BARRIER, LEAVE_NAME));
    }
}
