package net.hanzala.hideseek;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;

public final class Util {
    private Util() {}

    /** True only when the entity is in the Overworld (every minigame lives there). Every game feature is gated on this. */
    public static boolean inWorld(Entity e) {
        return e.level().dimension() == Level.OVERWORLD;
    }

    public static MutableComponent txt(String s, ChatFormatting f) {
        return Component.literal(s).withStyle(f);
    }

    /** Non-italic styled text (for item names/lore). */
    public static MutableComponent nm(String s, ChatFormatting f) {
        return Component.literal(s).withStyle(Style.EMPTY.withColor(f).withItalic(false));
    }

    public static MutableComponent msg(String s) {
        return Component.literal("[").withStyle(ChatFormatting.DARK_GRAY)
                .append(Component.literal("Hide&Seek").withStyle(ChatFormatting.LIGHT_PURPLE))
                .append(Component.literal("] ").withStyle(ChatFormatting.DARK_GRAY))
                .append(Component.literal(s).withStyle(ChatFormatting.GRAY));
    }

    public static ItemStack icon(Item item, String name, ChatFormatting color, String... lore) {
        ItemStack s = new ItemStack(item);
        s.set(DataComponents.CUSTOM_NAME, nm(name, color));
        if (lore.length > 0) {
            List<Component> l = new ArrayList<>();
            for (String x : lore) l.add(nm(x, ChatFormatting.GRAY));
            s.set(DataComponents.LORE, new ItemLore(l));
        }
        return s;
    }

    public static ItemStack glint(ItemStack s) {
        s.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
        return s;
    }

    public static void snd(ServerPlayer p, SoundEvent e, float vol, float pitch) {
        p.playNotifySound(e, SoundSource.MASTER, vol, pitch);
    }

    public static void fx(ServerLevel l, ParticleOptions o, double x, double y, double z, int n, double spread, double speed) {
        l.sendParticles(o, x, y, z, n, spread, spread, spread, speed);
    }

    public static String pretty(String id) {
        String s = id.contains(":") ? id.substring(id.indexOf(':') + 1) : id;
        StringBuilder b = new StringBuilder();
        for (String w : s.split("_")) {
            if (w.isEmpty()) continue;
            if (b.length() > 0) b.append(' ');
            b.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return b.toString();
    }

    public static String time(int secs) {
        if (secs < 0) secs = 0;
        return String.format("%d:%02d", secs / 60, secs % 60);
    }
}
