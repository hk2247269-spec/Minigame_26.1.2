# Building MINIGAMES for Minecraft 26.1.2

## Target toolchain
- Minecraft Java Edition: 26.1.2
- Fabric Loader: 0.19.3 or newer
- Fabric API: 0.155.3+26.1.2
- Java: 25
- Gradle: 9.4.0
- Fabric Loom: 1.15-SNAPSHOT (`net.fabricmc.fabric-loom`, non-remapping)

## Build locally
1. Install JDK 25.
2. Open this project directory in a terminal.
3. Run `gradle clean build --no-daemon`.
4. Find the resulting mod JAR in `build/libs/`.

## Important port status
This archive updates the project configuration and build toolchain for 26.1.2. The Java source was originally written for 1.21.8, so Minecraft/Fabric API changes may still cause compile errors. Treat the first GitHub Actions run as a port-validation build, not as proof that all gameplay code is already compatible. Fix every compiler error before installing the JAR on a live server.
