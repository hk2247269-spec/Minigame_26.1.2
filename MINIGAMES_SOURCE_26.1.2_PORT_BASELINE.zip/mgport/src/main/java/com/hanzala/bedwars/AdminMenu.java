package com.hanzala.bedwars;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/** Main admin GUI (/bw admin): start/stop, setup checklist, players, arena setup and settings. Operators only. */
public final class AdminMenu extends ServerGui {
    private List<String> problems = List.of();

    public static void open(ServerPlayer player) {
        if (!isAdmin(player)) { bar(player, "§cOperators only."); return; }
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new AdminMenu(id, inv), Component.literal("BedWars Admin")));
    }

    private AdminMenu(int containerId, Inventory inventory) {
        super(4, containerId, inventory);
        build();
    }

    @Override
    protected void build() {
        reset();
        BedWarsGameManager game = BedWarsMod.GAME;

        // Status
        List<String> status = new ArrayList<>();
        status.add(game.isRunning() ? "§aA match is running" : game.isCountingDown() ? "§eCountdown is running" : "§7No match (lobby)");
        status.addAll(game.timelineSummary());
        status.add(" ");
        for (String part : game.status().split(", ")) status.add("§8" + part);
        put(4, icon(Items.CLOCK, "§6§lBEDWARS ADMIN", status));

        // Start
        List<String> startLore = new ArrayList<>();
        startLore.add("§7Starts the countdown, then the match.");
        if (!problems.isEmpty()) {
            startLore.add(" ");
            startLore.add("§cCannot start yet:");
            for (int i = 0; i < problems.size() && i < 6; i++) startLore.add("§c- §f" + problems.get(i));
            if (problems.size() > 6) startLore.add("§c...and " + (problems.size() - 6) + " more");
        }
        putAdmin(10, icon(Items.LIME_CONCRETE, "§a§lSTART MATCH", startLore), (p, button, shift) -> {
            MinecraftServer server = p.getServer();
            if (server == null) return;
            problems = BedWarsMod.GAME.start(server);
            if (problems.isEmpty()) p.closeContainer(); else refresh();
        });

        // Stop
        putAdmin(12, icon(Items.RED_CONCRETE, "§c§lSTOP", "§7Ends a running match (no winner)", "§7or cancels the countdown."), (p, button, shift) -> {
            MinecraftServer server = p.getServer();
            if (server == null) return;
            if (!BedWarsMod.GAME.stop(server)) bar(p, "§cNo match or countdown is running.");
            problems = List.of();
            refresh();
        });

        // Setup checklist (read only)
        List<String> checklist = new ArrayList<>(game.setupReport());
        if (!checklist.isEmpty()) checklist.remove(0); // drop the chat-style header line
        put(14, icon(Items.WRITABLE_BOOK, "§b§lSETUP CHECKLIST", checklist));

        // Generators (read only)
        put(16, icon(Items.BEACON, "§b§lGENERATORS", BedWarsGeneratorManager.summaryLines()));

        // Sub menus
        putAdmin(19, icon(Items.NAME_TAG, "§e§lPLAYERS & TEAMS", "§7Move players between teams.", "§eClick to open"),
                (p, button, shift) -> AdminPlayersMenu.open(p));
        putAdmin(21, icon(Items.COMPASS, "§e§lARENA SETUP", "§7Lobby, team spawns, beds and generators.", "§eClick to open"),
                (p, button, shift) -> AdminSetupMenu.open(p));
        putAdmin(23, icon(Items.COMPARATOR, "§e§lSETTINGS", "§7Switches and timings from settings.txt.", "§eClick to open"),
                (p, button, shift) -> AdminSettingsMenu.open(p));
        putAdmin(25, icon(Items.REPEATER, "§7Reload settings and shop", "§7Use this after editing settings.txt", "§7or shop.txt by hand."), (p, button, shift) -> {
            Settings.load();
            ShopConfig.load();
            bar(p, "§aSettings and shop reloaded.");
            refresh();
        });
        putAdmin(28, icon(Items.EMERALD, "§a§lSHOP & PRICES", "§7Change the price, currency and amount of", "§7every item, armour and generator upgrade,", "§7or switch items off.", "§eClick to open"),
                (p, button, shift) -> AdminShopMenu.open(p));
        putAdmin(30, icon(Items.BEACON, "§b§lGENERATORS", "§7Change generator speeds, item limits", "§7and set a team's generator tier.", "§eClick to open"),
                (p, button, shift) -> AdminGeneratorMenu.open(p));
    }
}
