package com.hanzala.bedwars;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Admin GUI: click a player, then click a team to move them. */
public final class AdminPlayersMenu extends ServerGui {
    private static final int PLAYER_SLOTS = 36;
    private static final int[] TEAM_SLOTS = {37, 38, 39, 40, 41, 42};

    private UUID selected;

    public static void open(ServerPlayer player) {
        if (!isAdmin(player)) { bar(player, "§cOperators only."); return; }
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> new AdminPlayersMenu(id, inv), Component.literal("Players & Teams")));
    }

    private AdminPlayersMenu(int containerId, Inventory inventory) {
        super(6, containerId, inventory);
        build();
    }

    @Override
    protected void build() {
        reset();
        MinecraftServer server = viewer.getServer();
        if (server == null) return;
        BedWarsGameManager game = BedWarsMod.GAME;
        List<ServerPlayer> players = server.getPlayerList().getPlayers();

        for (int i = 0; i < players.size() && i < PLAYER_SLOTS; i++) {
            ServerPlayer sp = players.get(i);
            UUID id = sp.getUUID();
            String team = game.teamOf(sp);
            var stack = icon(Items.NAME_TAG, "§f" + sp.getGameProfile().getName(),
                    "§7Team: " + (team == null ? "§8none" : BedWarsGameManager.label(team)), "§eClick to select");
            if (id.equals(selected)) glow(stack);
            putAdmin(i, stack, (p, button, shift) -> { selected = id; refresh(); });
        }

        String chosen = "§8nobody";
        if (selected != null) {
            ServerPlayer sel = server.getPlayerList().getPlayer(selected);
            if (sel != null) chosen = "§f" + sel.getGameProfile().getName();
        }

        for (int i = 0; i < BedWarsGameManager.TEAMS.size() && i < TEAM_SLOTS.length; i++) {
            String team = BedWarsGameManager.TEAMS.get(i);
            putAdmin(TEAM_SLOTS[i], icon(teamWool(team), BedWarsGameManager.label(team), "§7Move the selected player here.", "§7Selected: " + chosen),
                    (p, button, shift) -> assign(p, team));
        }

        putAdmin(44, icon(Items.BARRIER, "§7Remove from team", "§7Selected: " + chosen, "§8Only works while no match is running."),
                (p, button, shift) -> {
                    ServerPlayer target = target(p);
                    if (target == null) return;
                    if (BedWarsMod.GAME.leaveTeam(target)) bar(p, "§aRemoved " + target.getGameProfile().getName() + " from their team.");
                    else bar(p, "§cThat player has no team, or a match is running.");
                    refresh();
                });

        put(45, icon(Items.ARROW, "§7« Back"), (p, button, shift) -> AdminMenu.open(p));
        List<String> hint = new ArrayList<>();
        hint.add("§71. Click a player");
        hint.add("§72. Click a team");
        if (players.size() > PLAYER_SLOTS) hint.add("§8Only the first " + PLAYER_SLOTS + " players are shown.");
        put(49, icon(Items.PAPER, "§eHow to use", hint));
    }

    /** The selected player if still online; otherwise tells the admin and returns null. */
    private ServerPlayer target(ServerPlayer admin) {
        if (selected == null) { bar(admin, "§cSelect a player first."); return null; }
        MinecraftServer server = admin.getServer();
        ServerPlayer target = server == null ? null : server.getPlayerList().getPlayer(selected);
        if (target == null) {
            selected = null;
            bar(admin, "§cThat player is no longer online.");
            refresh();
        }
        return target;
    }

    private void assign(ServerPlayer admin, String team) {
        ServerPlayer target = target(admin);
        if (target == null) return;
        if (BedWarsMod.GAME.assignTeamByAdmin(target, team)) {
            target.sendSystemMessage(Component.literal("An admin moved you to team " + team + "."));
            bar(admin, "§aMoved " + target.getGameProfile().getName() + " to " + team + ".");
        } else {
            bar(admin, "§cCould not move that player.");
        }
        refresh();
    }
}
