package com.hanzala.bedwars;

import com.google.gson.*;
import com.mojang.serialization.JsonOps;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.RegistryOps;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;

import java.nio.file.*;
import java.util.Set;

/** Persistent pre-match player-state backup, isolated from Hide & Seek backups. */
public final class BedWarsBackup {
    private static Path dir;
    private BedWarsBackup() {}
    public static void init() { dir = BedWarsMod.configDir().resolve("player-backups"); try { Files.createDirectories(dir); } catch (Exception e) { BedWarsMod.LOGGER.error("Backup directory", e); } }
    private static Path file(ServerPlayer p) { return dir.resolve(p.getUUID()+".json"); }
    public static boolean exists(ServerPlayer p) { return dir != null && Files.exists(file(p)); }
    public static void save(ServerPlayer p) {
        if (dir == null || exists(p)) return;
        try {
            RegistryOps<JsonElement> ops=p.level().registryAccess().createSerializationContext(JsonOps.INSTANCE);
            JsonObject o=new JsonObject(); o.addProperty("dim",p.level().dimension().location().toString());
            o.addProperty("x",p.getX()); o.addProperty("y",p.getY()); o.addProperty("z",p.getZ()); o.addProperty("yaw",p.getYRot()); o.addProperty("pitch",p.getXRot());
            o.addProperty("mode",p.gameMode.getGameModeForPlayer().getName()); o.addProperty("health",p.getHealth());
            o.addProperty("food",p.getFoodData().getFoodLevel()); o.addProperty("saturation",p.getFoodData().getSaturationLevel());
            o.addProperty("xp",p.experienceProgress); o.addProperty("level",p.experienceLevel); o.addProperty("totalXp",p.totalExperience);
            JsonArray effects=new JsonArray(); for(MobEffectInstance effect:p.getActiveEffects()) effects.add(MobEffectInstance.CODEC.encodeStart(ops,effect).getOrThrow()); o.add("effects",effects);
            JsonArray items=new JsonArray(); Inventory inv=p.getInventory(); for(int i=0;i<inv.getContainerSize();i++) items.add(ItemStack.OPTIONAL_CODEC.encodeStart(ops,inv.getItem(i)).getOrThrow()); o.add("items",items);
            Files.writeString(file(p),o.toString(),StandardOpenOption.CREATE_NEW);
        } catch(Exception e) { BedWarsMod.LOGGER.error("Could not save BedWars backup for "+p.getName().getString(),e); }
    }
    public static boolean restore(ServerPlayer p, MinecraftServer server) {
        if(!exists(p)) return false;
        try {
            JsonObject o=JsonParser.parseString(Files.readString(file(p))).getAsJsonObject();
            RegistryOps<JsonElement> ops=p.level().registryAccess().createSerializationContext(JsonOps.INSTANCE); Inventory inv=p.getInventory(); inv.clearContent();
            JsonArray arr=o.getAsJsonArray("items"); for(int i=0;i<arr.size()&&i<inv.getContainerSize();i++) inv.setItem(i,ItemStack.OPTIONAL_CODEC.parse(ops,arr.get(i)).result().orElse(ItemStack.EMPTY));
            p.removeAllEffects();
            if(o.has("effects")) { JsonArray effects=o.getAsJsonArray("effects"); for(JsonElement e:effects) MobEffectInstance.CODEC.parse(ops,e).result().ifPresent(p::addEffect); }
            p.setGameMode(GameType.byName(o.get("mode").getAsString(),GameType.SURVIVAL));
            p.setHealth(Math.min(p.getMaxHealth(),Math.max(1f,o.get("health").getAsFloat()))); p.getFoodData().setFoodLevel(o.get("food").getAsInt()); p.getFoodData().setSaturation(o.get("saturation").getAsFloat());
            p.experienceProgress=o.get("xp").getAsFloat(); p.experienceLevel=o.get("level").getAsInt(); p.totalExperience=o.get("totalXp").getAsInt();
            ResourceKey<Level> key=ResourceKey.create(Registries.DIMENSION,ResourceLocation.parse(o.get("dim").getAsString())); ServerLevel lvl=server.getLevel(key);
            if(lvl!=null) p.teleportTo(lvl,o.get("x").getAsDouble(),o.get("y").getAsDouble(),o.get("z").getAsDouble(),Set.<Relative>of(),o.get("yaw").getAsFloat(),o.get("pitch").getAsFloat(),true);
            p.inventoryMenu.broadcastChanges(); Files.deleteIfExists(file(p)); return true;
        } catch(Exception e) { BedWarsMod.LOGGER.error("Could not restore BedWars backup for "+p.getName().getString(),e); return false; }
    }
    public static void delete(ServerPlayer p) { try { if(dir!=null) Files.deleteIfExists(file(p)); } catch(Exception e) { BedWarsMod.LOGGER.error("Could not delete backup",e); } }
}
