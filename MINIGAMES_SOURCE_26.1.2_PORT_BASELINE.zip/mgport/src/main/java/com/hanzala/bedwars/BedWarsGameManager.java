package com.hanzala.bedwars;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** Teams, beds, spawns, lobby, match lifecycle, respawn timers, elimination and victory. */
public final class BedWarsGameManager {
    public static final List<String> TEAMS = List.of("red", "blue", "green", "yellow", "pink", "white");
    private static final Item[] RESOURCES = {Items.IRON_INGOT, Items.GOLD_INGOT, Items.DIAMOND, Items.EMERALD};
    private static final int LAST_HIT_WINDOW = 200; // a knock into the void within 10 s still counts for the attacker

    private final Map<String, TeamBed> beds = new HashMap<>();
    private final Map<UUID, String> playerTeams = new HashMap<>();
    private final Set<UUID> eliminated = new HashSet<>();
    private final Map<String, TeamSpawn> spawns = new HashMap<>();
    private final Map<UUID, Integer> respawning = new HashMap<>();
    private TeamSpawn lobby;
    private Path directory;
    private boolean matchRunning;
    private boolean victoryCheckPending;
    private long tickCounter;

    // countdown / timeline / celebration state (not persisted: a restart ends the match, see recoverAfterRestart)
    private int countdownTicks = -1;
    private long matchTicks;
    // match timeline (see tickTimeline): fixed when the match starts, never reset while it runs
    private long matchEndTicks;
    private String endAction = "sudden_death";
    private boolean suddenDeath;
    private long suddenEndTicks;
    private int upgradeLevel;
    private final Set<String> fired = new HashSet<>();
    private boolean statsOpen;
    private String victoryTeam;
    private int victoryTicks;
    private Set<UUID> victoryMembers = new HashSet<>();
    private int uiTicks;
    private final Map<UUID, Hit> lastHit = new HashMap<>();

    private record Hit(UUID attacker, long tick) { }

    public record TeamSpawn(String dimension, double x, double y, double z, float yaw, float pitch) { }

    private static final class TeamBed {
        final String dimension; final BlockPos foot; final BlockPos head; boolean alive;
        final String blockId; final Direction facing;
        TeamBed(String dimension, BlockPos foot, BlockPos head, boolean alive, String blockId, Direction facing) {
            this.dimension = dimension; this.foot = foot; this.head = head; this.alive = alive;
            this.blockId = blockId; this.facing = facing;
        }
    }

    // ------------------------------------------------------------------ persistence

    private List<String> readData(String name) {
        List<String> out = new ArrayList<>();
        Path file = directory.resolve(name);
        try {
            if (!Files.exists(file)) return out;
            for (String raw : Files.readAllLines(file)) {
                String line = raw.split("#", 2)[0].trim();
                if (!line.isEmpty()) out.add(line);
            }
        } catch (IOException ex) { BedWarsMod.LOGGER.error("Could not read " + name, ex); }
        return out;
    }

    public void load(MinecraftServer server) {
        directory = BedWarsMod.configDir();
        beds.clear(); playerTeams.clear(); eliminated.clear(); spawns.clear(); respawning.clear(); lobby = null;
        for (String line : readData("team-beds.txt")) {
            String[] p = line.split("\\s+");
            if (p.length != 9 && p.length != 11) continue;
            try {
                BlockPos foot = new BlockPos(Integer.parseInt(p[2]), Integer.parseInt(p[3]), Integer.parseInt(p[4]));
                BlockPos head = new BlockPos(Integer.parseInt(p[5]), Integer.parseInt(p[6]), Integer.parseInt(p[7]));
                String blockId = p.length == 11 ? p[9] : null;
                Direction facing = p.length == 11 ? Direction.byName(p[10]) : null;
                beds.put(p[0].toLowerCase(Locale.ROOT), new TeamBed(p[1], foot, head, Boolean.parseBoolean(p[8]), blockId, facing));
            } catch (RuntimeException ignored) { }
        }
        for (String line : readData("player-teams.txt")) {
            String[] p = line.split("\\s+");
            if (p.length != 2) continue;
            try { playerTeams.put(UUID.fromString(p[0]), p[1].toLowerCase(Locale.ROOT)); } catch (RuntimeException ignored) { }
        }
        for (String line : readData("team-spawns.txt")) {
            String[] p = line.split("\\s+");
            if (p.length != 7) continue;
            try {
                spawns.put(p[0].toLowerCase(Locale.ROOT), new TeamSpawn(p[1], Double.parseDouble(p[2]), Double.parseDouble(p[3]),
                        Double.parseDouble(p[4]), Float.parseFloat(p[5]), Float.parseFloat(p[6])));
            } catch (RuntimeException ignored) { }
        }
        for (String line : readData("lobby.txt")) {
            String[] p = line.split("\\s+");
            if (p.length != 6) continue;
            try {
                lobby = new TeamSpawn(p[0], Double.parseDouble(p[1]), Double.parseDouble(p[2]), Double.parseDouble(p[3]),
                        Float.parseFloat(p[4]), Float.parseFloat(p[5]));
            } catch (RuntimeException ignored) { }
        }
        for (String line : readData("eliminated-players.txt")) {
            try { eliminated.add(UUID.fromString(line)); } catch (RuntimeException ignored) { }
        }
        List<String> state = readData("match-state.txt");
        matchRunning = !state.isEmpty() && state.get(0).equalsIgnoreCase("running");
        BedWarsMod.LOGGER.info("Loaded {} beds, {} spawns, {} team assignments (match {})",
                beds.size(), spawns.size(), playerTeams.size(), matchRunning ? "running" : "stopped");
    }

    private void saveBeds() {
        if (directory == null) return;
        List<String> lines = new ArrayList<>();
        lines.add("# team dimension footX footY footZ headX headY headZ alive blockId facing");
        beds.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(e -> {
            TeamBed b = e.getValue();
            String line = e.getKey() + " " + b.dimension + " " + b.foot.getX() + " " + b.foot.getY() + " " + b.foot.getZ()
                    + " " + b.head.getX() + " " + b.head.getY() + " " + b.head.getZ() + " " + b.alive;
            if (b.blockId != null && b.facing != null) line += " " + b.blockId + " " + b.facing.getSerializedName();
            lines.add(line);
        });
        write("team-beds.txt", lines);
    }
    private void saveTeams() {
        if (directory == null) return;
        List<String> lines = new ArrayList<>(); lines.add("# player-uuid team");
        playerTeams.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(e -> lines.add(e.getKey() + " " + e.getValue()));
        write("player-teams.txt", lines);
    }
    private void saveMatchState() { write("match-state.txt", List.of(matchRunning ? "running" : "stopped")); }
    private void saveSpawns() {
        List<String> lines = new ArrayList<>(); lines.add("# team dimension x y z yaw pitch");
        spawns.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(e -> {
            TeamSpawn s = e.getValue();
            lines.add(e.getKey() + " " + s.dimension + " " + s.x + " " + s.y + " " + s.z + " " + s.yaw + " " + s.pitch);
        });
        write("team-spawns.txt", lines);
    }
    private void saveLobby() {
        if (lobby == null) return;
        write("lobby.txt", List.of("# dimension x y z yaw pitch",
                lobby.dimension + " " + lobby.x + " " + lobby.y + " " + lobby.z + " " + lobby.yaw + " " + lobby.pitch));
    }
    private void saveEliminated() {
        List<String> lines = new ArrayList<>(); lines.add("# player-uuid");
        eliminated.stream().map(UUID::toString).sorted().forEach(lines::add);
        write("eliminated-players.txt", lines);
    }
    private void write(String name, List<String> lines) {
        if (directory == null) return;
        try { Files.write(directory.resolve(name), lines); }
        catch (IOException ex) { BedWarsMod.LOGGER.error("Could not save " + name, ex); }
    }

    // ------------------------------------------------------------------ teams

    public static String normalizeTeam(String team) {
        if (team == null) return null;
        String n = team.toLowerCase(Locale.ROOT);
        return TEAMS.contains(n) ? n : null;
    }

    public static String color(String team) {
        return switch (team) {
            case "red" -> "§c"; case "blue" -> "§9"; case "green" -> "§a";
            case "yellow" -> "§e"; case "pink" -> "§d"; default -> "§f";
        };
    }

    public static String label(String team) { return color(team) + "§l" + team.toUpperCase(Locale.ROOT) + "§r"; }

    public boolean assignTeam(ServerPlayer player, String team) {
        String n = normalizeTeam(team);
        if (n == null || matchRunning) return false;
        playerTeams.put(player.getUUID(), n);
        saveTeams();
        return true;
    }

    public boolean assignTeamByAdmin(ServerPlayer player, String team) {
        String n = normalizeTeam(team);
        if (n == null) return false;
        playerTeams.put(player.getUUID(), n);
        saveTeams();
        return true;
    }

    /** Forgets every team pick (players are back in the common lobby, nobody is "in BedWars" any more). Never during a match. */
    public void clearTeams() {
        if (matchRunning) return;
        if (playerTeams.isEmpty()) return;
        playerTeams.clear();
        saveTeams();
    }

    /**
     * Removes a player from BedWars at any time (also during a match). During a match the saved inventory / mode / location
     * are restored and the victory check runs again. Returns false when the player had no team.
     */
    public boolean forceLeave(ServerPlayer player) {
        UUID id = player.getUUID();
        if (playerTeams.remove(id) == null) return false;
        saveTeams();
        if (matchRunning) {
            eliminated.remove(id);
            respawning.remove(id);
            saveEliminated();
            victoryCheckPending = true;
            if (!BedWarsBackup.restore(player, player.getServer())) {
                player.getInventory().clearContent();
                player.removeAllEffects();
                player.setHealth(player.getMaxHealth());
                player.getFoodData().setFoodLevel(20);
                player.setGameMode(GameType.ADVENTURE);
            }
        }
        if (player.getServer() != null) Sidebar.syncTeams(player.getServer());
        return true;
    }

    public boolean leaveTeam(ServerPlayer player) {
        if (matchRunning) return false;
        boolean removed = playerTeams.remove(player.getUUID()) != null;
        if (removed) saveTeams();
        return removed;
    }

    public String teamOf(ServerPlayer player) { return playerTeams.get(player.getUUID()); }

    public boolean hasOnlinePlayersInTeam(MinecraftServer server, String team) {
        for (ServerPlayer p : Dim.players(server)) {
            if (team.equals(playerTeams.get(p.getUUID())) && !eliminated.contains(p.getUUID())) return true;
        }
        return false;
    }

    /** True while the team still has a member who is in the match and not eliminated (online or not). */
    public boolean isTeamInPlay(String team) {
        for (Map.Entry<UUID, String> e : playerTeams.entrySet()) {
            if (team.equals(e.getValue()) && !eliminated.contains(e.getKey())) return true;
        }
        return false;
    }

    /** Teams that currently have at least one ONLINE member. */
    public List<String> getActiveTeams(MinecraftServer server) {
        Set<String> set = new TreeSet<>();
        for (ServerPlayer p : Dim.players(server)) {
            String t = playerTeams.get(p.getUUID());
            if (t != null) set.add(t);
        }
        return new ArrayList<>(set);
    }

    public Map<String, List<String>> getTeamRoster(MinecraftServer server) {
        Map<String, List<String>> roster = new LinkedHashMap<>();
        for (String t : TEAMS) roster.put(t, new ArrayList<>());
        for (ServerPlayer p : Dim.players(server)) {
            String t = playerTeams.get(p.getUUID());
            if (t != null && roster.containsKey(t)) roster.get(t).add(p.getGameProfile().getName());
        }
        return roster;
    }

    // ------------------------------------------------------------------ spawns / lobby / beds

    public void setSpawn(ServerPlayer player, String team) {
        spawns.put(team.toLowerCase(Locale.ROOT), here(player));
        saveSpawns();
    }

    public void setLobby(ServerPlayer player) { lobby = here(player); saveLobby(); }

    /**
     * Forgets the lobby, every team spawn and every registered bed. Only the saved coordinates are removed; the
     * bed blocks in the world are left alone. Returns a short "what was removed" summary line.
     * Call only while no match or countdown is running.
     */
    public String clearSetup() {
        int spawnCount = spawns.size(), bedCount = beds.size();
        boolean hadLobby = lobby != null;
        spawns.clear(); beds.clear(); lobby = null;
        saveSpawns();
        saveBeds();
        write("lobby.txt", List.of("# dimension x y z yaw pitch")); // saveLobby() skips a null lobby, so write the empty file here
        return (hadLobby ? "lobby, " : "") + spawnCount + " team spawn(s), " + bedCount + " bed registration(s)";
    }

    public boolean hasLobby() { return lobby != null; }

    /** {x, y, z} of the common lobby, or null when none is set. Used by the Minigames mod to keep arenas away from it. */
    public double[] lobbyCoords() { return lobby == null ? null : new double[] { lobby.x(), lobby.y(), lobby.z() }; }
    public boolean hasSpawn(String team) { return spawns.containsKey(team); }
    public boolean hasBed(String team) { return beds.containsKey(team); }

    private TeamSpawn here(ServerPlayer p) {
        return new TeamSpawn(p.level().dimension().location().toString(), p.getX(), p.getY(), p.getZ(), p.getYRot(), p.getXRot());
    }

    private void teleport(ServerPlayer player, TeamSpawn s) {
        if (s == null) return;
        if (!s.dimension.equals(player.level().dimension().location().toString())) {
            BedWarsMod.LOGGER.warn("Cannot move {}: target is in {} (cross-dimension teleport is not supported)",
                    player.getGameProfile().getName(), s.dimension);
            return;
        }
        player.connection.teleport(s.x, s.y, s.z, s.yaw, s.pitch);
        player.resetFallDistance();
    }

    public void teleportToLobby(ServerPlayer player) { teleport(player, lobby); }

    /** Moves a player from any dimension to the lobby when the lobby is in the Overworld. False if there is no usable lobby. */
    public boolean teleportToLobbyFrom(ServerPlayer player, net.minecraft.server.level.ServerLevel overworld) {
        if (lobby == null || !"minecraft:overworld".equals(lobby.dimension)) return false;
        player.teleportTo(overworld, lobby.x, lobby.y, lobby.z, java.util.Set.<net.minecraft.world.entity.Relative>of(), lobby.yaw, lobby.pitch, true);
        return true;
    }

    public void routeRespawn(ServerPlayer player) {
        String team = playerTeams.get(player.getUUID());
        if (team != null) teleport(player, spawns.get(team));
    }

    /** True when pos is within r blocks (horizontally) of a team spawn and 0..3 blocks above it. */
    public boolean isNearSpawn(ServerLevel level, BlockPos pos, int r) {
        String dim = level.dimension().location().toString();
        for (TeamSpawn s : spawns.values()) {
            if (!s.dimension().equals(dim)) continue;
            int sx = (int) Math.floor(s.x()), sy = (int) Math.floor(s.y()), sz = (int) Math.floor(s.z());
            if (Math.abs(pos.getX() - sx) <= r && Math.abs(pos.getZ() - sz) <= r && pos.getY() >= sy && pos.getY() <= sy + 3) return true;
        }
        return false;
    }

    private static ServerLevel levelOf(MinecraftServer server, String dimension) {
        try {
            return server.getLevel(ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(dimension)));
        } catch (RuntimeException ex) {
            return null;
        }
    }

    /** Registers the bed block at pos (either half) for a team. */
    public boolean setBed(ServerLevel level, BlockPos pos, String team) {
        BlockState state = level.getBlockState(pos);
        if (!(state.getBlock() instanceof BedBlock)) return false;
        Direction facing = state.getValue(BlockStateProperties.HORIZONTAL_FACING);
        BlockPos foot = state.getValue(BedBlock.PART) == BedPart.HEAD ? pos.relative(facing.getOpposite()) : pos.immutable();
        BlockPos head = foot.relative(facing);
        String blockId = BuiltInRegistries.BLOCK.getKey(state.getBlock()).toString();
        beds.put(team.toLowerCase(Locale.ROOT), new TeamBed(level.dimension().location().toString(), foot.immutable(), head.immutable(), true, blockId, facing));
        saveBeds();
        return true;
    }

    public boolean isRegisteredBed(ServerLevel level, BlockPos pos) { return bedTeamAt(level, pos) != null; }

    public String bedTeamAt(ServerLevel level, BlockPos pos) {
        if (beds.isEmpty()) return null;
        String dim = level.dimension().location().toString();
        for (Map.Entry<String, TeamBed> e : beds.entrySet()) {
            TeamBed b = e.getValue();
            if (b.dimension.equals(dim) && (b.foot.equals(pos) || b.head.equals(pos))) return e.getKey();
        }
        return null;
    }

    private void restoreBeds(MinecraftServer server) {
        for (TeamBed bed : beds.values()) {
            bed.alive = true;
            if (bed.blockId == null || bed.facing == null) continue;
            try {
                ServerLevel level = server.getLevel(ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(bed.dimension)));
                if (level == null) continue;
                Block block = BuiltInRegistries.BLOCK.getValue(ResourceLocation.parse(bed.blockId));
                BlockState base = block.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, bed.facing);
                int flags = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE; // no shape update: half a bed would pop off
                level.setBlock(bed.foot, base.setValue(BedBlock.PART, BedPart.FOOT), flags);
                level.setBlock(bed.head, base.setValue(BedBlock.PART, BedPart.HEAD), flags);
            } catch (RuntimeException ex) { BedWarsMod.LOGGER.error("Could not restore a bed", ex); }
        }
        saveBeds();
    }

    /** Marks a team's bed as destroyed. breaker may be null (explosions). Returns the team or null. */
    public String destroyBed(ServerLevel level, BlockPos pos, ServerPlayer breaker) {
        String dim = level.dimension().location().toString();
        for (Map.Entry<String, TeamBed> e : beds.entrySet()) {
            TeamBed bed = e.getValue();
            if (bed.dimension.equals(dim) && (bed.foot.equals(pos) || bed.head.equals(pos)) && bed.alive) {
                bed.alive = false;
                saveBeds();
                MinecraftServer server = level.getServer();
                String team = e.getKey();
                if (breaker != null && statsOpen) StatsManager.bed(breaker);
                String by = breaker == null ? "" : " §7by " + color(teamOrNone(breaker)) + breaker.getGameProfile().getName();
                Dim.broadcast(server, Component.literal("§6§lBED DESTROYED §r" + label(team) + " §7team's bed was destroyed" + by + "§7!"), false);
                List<ServerPlayer> victims = new ArrayList<>();
                for (ServerPlayer p : Dim.players(server)) {
                    if (team.equals(playerTeams.get(p.getUUID()))) victims.add(p);
                }
                Visuals.bedDestroyed(server, level, bed.head, team, breaker, victims);
                victoryCheckPending = true;
                return team;
            }
        }
        return null;
    }

    private String teamOrNone(ServerPlayer p) { String t = playerTeams.get(p.getUUID()); return t == null ? "white" : t; }

    private static void title(ServerPlayer p, String title, String subtitle) { Visuals.title(p, title, subtitle); }

    // ------------------------------------------------------------------ match lifecycle

    public boolean isRunning() { return matchRunning; }
    public boolean isEliminated(UUID id) { return eliminated.contains(id); }

    private static boolean isOp(ServerPlayer p) { return p.createCommandSourceStack().hasPermission(2); }

    public boolean isCountingDown() { return countdownTicks >= 0; }

    /** Checks that a match can start. Also forgets team picks of players who have left. */
    private List<String> validate(MinecraftServer server) {
        List<String> problems = new ArrayList<>();
        if (matchRunning) { problems.add("A match is already running."); return problems; }
        if (countdownTicks >= 0) { problems.add("A countdown is already running."); return problems; }
        playerTeams.keySet().removeIf(id -> server.getPlayerList().getPlayer(id) == null);
        saveTeams();
        List<String> teams = getActiveTeams(server);
        if (teams.size() < 2) problems.add("At least 2 different teams need online players (/bw menu).");
        for (String t : teams) {
            if (!beds.containsKey(t)) problems.add(t + ": no bed registered. Look at the bed and run /bw bed set " + t);
            if (!spawns.containsKey(t)) problems.add(t + ": no spawn registered. Stand there and run /bw spawn set " + t);
        }
        return problems;
    }

    /** Starts the countdown (or the match at once). Returns a list of problems; an empty list means it started. */
    public List<String> start(MinecraftServer server) {
        List<String> problems = validate(server);
        if (!problems.isEmpty()) return problems;
        int seconds = Settings.integer("countdown_seconds");
        if (seconds <= 0) { begin(server); return problems; }
        countdownTicks = seconds * 20;
        Dim.broadcast(server, Component.literal("§a§lBEDWARS §7starts in §f" + seconds + " §7seconds. Pick your team with §e/bw menu§7!"), false);
        return problems;
    }

    private void begin(MinecraftServer server) {
        if (matchRunning) return; // the timer can never be restarted while a match is running
        countdownTicks = -1;
        eliminated.clear(); respawning.clear(); lastHit.clear(); saveEliminated();
        BuildRules.clear();
        BedWarsMod.PROTECTION.clearPlaced(server);
        restoreBeds(server);
        BedWarsGeneratorManager.resetForMatch(server);
        BedWarsShop.resetArmor();
        victoryTeam = null;
        matchTicks = 0; tickCounter = 0;
        fired.clear(); upgradeLevel = 0; suddenDeath = false; suddenEndTicks = 0L;
        matchEndTicks = Math.max(60, Settings.integer("match_duration_seconds")) * 20L; // fixed for this match
        endAction = Settings.text("match_end_action");
        Visuals.resetMatch();
        matchRunning = true;
        saveMatchState();
        Fx.matchRules(server, true);
        List<ServerPlayer> participants = new ArrayList<>();
        for (ServerPlayer p : Dim.players(server)) {
            if (playerTeams.containsKey(p.getUUID())) { participants.add(p); BedWarsBackup.save(p); preparePlayer(p); }
            // players without a team (lobby visitors) are left alone: they are not part of this match
        }
        StatsManager.startMatch(participants);
        statsOpen = true;
        Dim.broadcast(server, Component.literal("§a§lBEDWARS MATCH STARTED! §7Protect your bed and destroy the others."), false);
        Visuals.go(server);
        Visuals.sfx(server, "entity.ender_dragon.growl", 1.0F);
        Sidebar.syncTeams(server);
        refreshUi(server);
    }

    private void preparePlayer(ServerPlayer p) {
        p.getInventory().clearContent();
        p.removeAllEffects();
        p.setHealth(p.getMaxHealth());
        p.getFoodData().setFoodLevel(20);
        p.getFoodData().setSaturation(20.0F);
        p.setGameMode(GameType.SURVIVAL);
        routeRespawn(p);
        giveKit(p);
    }

    private void giveKit(ServerPlayer p) {
        p.getInventory().add(new ItemStack(Items.WOODEN_SWORD));
        BedWarsShop.restoreArmor(p);
        if (!Settings.flag("leather_kit")) return;
        MinecraftServer server = p.getServer();
        String team = playerTeams.get(p.getUUID());
        if (server == null || team == null) return;
        int rgb = Fx.rgb(team);
        dye(server, p, "head", "leather_helmet", rgb);
        dye(server, p, "chest", "leather_chestplate", rgb);
        if (BedWarsShop.armorTier(p) == 0) { // bought leggings/boots replace the leather ones
            dye(server, p, "legs", "leather_leggings", rgb);
            dye(server, p, "feet", "leather_boots", rgb);
        }
    }

    private static void dye(MinecraftServer server, ServerPlayer p, String slot, String item, int rgb) {
        Fx.run(server, "item replace entity " + p.getUUID() + " armor." + slot + " with minecraft:" + item + "[minecraft:dyed_color=" + rgb + "]");
    }

    /** Stops the countdown, or ends a running match without a winner. */
    public boolean stop(MinecraftServer server) {
        if (countdownTicks >= 0) {
            countdownTicks = -1;
            Dim.broadcast(server, Component.literal("§eThe countdown was cancelled."), false);
            return true;
        }
        if (!matchRunning) return false;
        endMatch(server, null, null);
        return true;
    }

    /** A server that went down during a match comes back with the map and state cleaned up. */
    public void recoverAfterRestart(MinecraftServer server) {
        if (!matchRunning) return;
        BedWarsMod.LOGGER.warn("The server stopped during a BedWars match: resetting the arena.");
        statsOpen = false;
        endMatch(server, null, "server restarted");
    }

    private void endMatch(MinecraftServer server, String winner, String reason) {
        boolean hadStats = statsOpen;
        statsOpen = false;
        matchRunning = false;
        countdownTicks = -1;
        saveMatchState();
        Set<UUID> winners = new HashSet<>();
        if (winner != null) {
            for (Map.Entry<UUID, String> e : playerTeams.entrySet()) if (winner.equals(e.getValue())) winners.add(e.getKey());
        }
        eliminated.clear(); respawning.clear(); lastHit.clear(); saveEliminated();
        suddenDeath = false; upgradeLevel = 0; // generators and scoreboard go back to the lobby values
        BuildRules.clear();
        BedWarsMod.PROTECTION.clearPlaced(server);
        restoreBeds(server);
        BedWarsGeneratorManager.clearDrops(server);
        BedWarsGeneratorManager.resetTiers();
        BedWarsShop.resetArmor();
        Fx.matchRules(server, false);
        boolean celebrating = winner != null && Settings.flag("victory_celebration");
        if (!celebrating) { // with the celebration on, Visuals prints a victory banner instead of this line
            Dim.broadcast(server, Component.literal(winner == null
                    ? "§eThe BedWars match ended" + (reason == null ? "." : " §7(" + reason + ")§e.")
                    : "§6§lVICTORY! §r" + label(winner) + " §6team wins the match!"), false);
        }
        for (ServerPlayer p : Dim.players(server)) {
            boolean member = playerTeams.containsKey(p.getUUID());
            boolean restored = BedWarsBackup.restore(p, server);
            if (!restored && !member) continue; // a lobby visitor who never took part: never touch their inventory
            if (!restored) {
                p.getInventory().clearContent(); p.removeAllEffects(); p.setHealth(p.getMaxHealth());
                p.getFoodData().setFoodLevel(20); p.setGameMode(GameType.ADVENTURE);
            }
            com.hanzala.minigames.Lobby.send(p); // everybody ends up in the common lobby
            com.hanzala.minigames.Lobby.giveMenuItem(p);
        }
        Visuals.resetMatch();
        Visuals.matchEnd(server, winner, winners, new HashMap<>(playerTeams));
        if (hadStats) {
            for (String line : StatsManager.finish(winners, winner == null ? null : label(winner))) {
                Dim.broadcast(server, Component.literal(line), false);
            }
        }
        if (winner != null && Settings.flag("victory_fireworks")) { victoryTeam = winner; victoryTicks = 141; }
        victoryMembers = new HashSet<>(winners);
        // everybody is back in the common lobby: nobody stays "in BedWars" (join again through /mg)
        playerTeams.clear();
        saveTeams();
    }

    // ------------------------------------------------------------------ deaths, respawns, victory

    private boolean bedAlive(String team) { TeamBed b = beds.get(team); return b != null && b.alive; }

    private boolean teamAlive(MinecraftServer server, String team) {
        boolean bed = bedAlive(team);
        for (Map.Entry<UUID, String> e : playerTeams.entrySet()) {
            if (!team.equals(e.getValue()) || eliminated.contains(e.getKey())) continue;
            if (bed || server.getPlayerList().getPlayer(e.getKey()) != null) return true;
        }
        return false;
    }

    public List<String> aliveTeams(MinecraftServer server) {
        List<String> alive = new ArrayList<>();
        Set<String> teams = new TreeSet<>(playerTeams.values());
        for (String t : teams) if (teamAlive(server, t)) alive.add(t);
        return alive;
    }

    public void checkVictory(MinecraftServer server) {
        if (!matchRunning) return;
        List<String> alive = aliveTeams(server);
        if (alive.size() <= 1) endMatch(server, alive.isEmpty() ? null : alive.get(0), null);
    }

    /** Remembers who last hurt a player, so a knock into the void still counts as a kill. */
    public void noteDamage(ServerPlayer victim, ServerPlayer attacker) {
        if (matchRunning) lastHit.put(victim.getUUID(), new Hit(attacker.getUUID(), tickCounter));
    }

    /** The enemy player who gets credit for this death, or null. */
    private ServerPlayer creditedKiller(ServerPlayer victim, DamageSource source, MinecraftServer server) {
        String victimTeam = playerTeams.get(victim.getUUID());
        Entity direct = source == null ? null : source.getEntity();
        if (direct instanceof ServerPlayer kp && kp != victim && !Objects.equals(victimTeam, playerTeams.get(kp.getUUID()))) return kp;
        Hit hit = lastHit.get(victim.getUUID());
        if (hit != null && tickCounter - hit.tick() <= LAST_HIT_WINDOW) {
            ServerPlayer kp = server.getPlayerList().getPlayer(hit.attacker());
            if (kp != null && kp != victim && !Objects.equals(victimTeam, playerTeams.get(kp.getUUID()))) return kp;
        }
        return null;
    }

    private boolean canReceiveLoot(ServerPlayer p) {
        UUID id = p.getUUID();
        return playerTeams.containsKey(id) && !eliminated.contains(id) && !respawning.containsKey(id) && !p.isSpectator();
    }

    private static void give(ServerPlayer p, Item item, int amount) {
        int left = amount;
        while (left > 0) {
            int n = Math.min(left, 64);
            ItemStack stack = new ItemStack(item, n);
            if (!p.getInventory().add(stack)) p.drop(stack, false);
            left -= n;
        }
    }

    /**
     * Runs just before a player dies. Resources go straight to the killer (kill_resource_transfer) and/or
     * everything except resources is removed so no gear piles up on the ground (clean_death_drops).
     */
    public void beforeDeath(ServerPlayer victim, DamageSource source) {
        if (!Dim.inBw(victim) || !matchRunning || !playerTeams.containsKey(victim.getUUID())) return;
        boolean transfer = Settings.flag("kill_resource_transfer");
        boolean clean = Settings.flag("clean_death_drops");
        if (!transfer && !clean) return;
        MinecraftServer server = victim.getServer();
        if (server == null) return;

        ServerPlayer killer = transfer ? creditedKiller(victim, source, server) : null;
        if (killer != null && !canReceiveLoot(killer)) killer = null;

        int[] have = new int[RESOURCES.length];
        for (int i = 0; i < RESOURCES.length; i++) have[i] = BedWarsShop.count(victim, RESOURCES[i]);

        if (clean) victim.getInventory().clearContent();
        if (killer != null) {
            StringBuilder gained = new StringBuilder();
            for (int i = 0; i < RESOURCES.length; i++) {
                if (have[i] <= 0) continue;
                if (!clean) BedWarsShop.take(victim, RESOURCES[i], have[i]);
                give(killer, RESOURCES[i], have[i]);
                gained.append("§a+").append(have[i]).append(" §f").append(BedWarsShop.currencyName(RESOURCES[i])).append("  ");
            }
            if (gained.length() > 0) Visuals.loot(killer, gained.toString().trim());
        } else if (clean) {
            for (int i = 0; i < RESOURCES.length; i++) if (have[i] > 0) give(victim, RESOURCES[i], have[i]); // these drop normally
        }
    }

    public void afterActualDeath(ServerPlayer player, DamageSource source) {
        if (!Dim.inBw(player) || !matchRunning) return;
        String team = playerTeams.get(player.getUUID());
        if (team == null) return;
        MinecraftServer server = player.getServer();
        if (server == null) return;
        ServerPlayer killer = creditedKiller(player, source, server);
        boolean finalKill = !bedAlive(team);
        StatsManager.death(player);
        if (killer != null) {
            StatsManager.kill(killer, finalKill);
            Visuals.kill(server, killer, player.getGameProfile().getName(), finalKill);
        }
        if (finalKill) {
            eliminated.add(player.getUUID());
            saveEliminated();
            String by = killer != null ? " §7by " + killer.getGameProfile().getName() : "";
            Dim.broadcast(server, Component.literal(
                    "§c§lFINAL KILL §r" + color(team) + player.getGameProfile().getName() + "§7 was eliminated" + by + "§7."), false);
            Visuals.eliminated(server, player, team);
            boolean teamOut = true;
            for (Map.Entry<UUID, String> e : playerTeams.entrySet()) {
                if (team.equals(e.getValue()) && !eliminated.contains(e.getKey())) { teamOut = false; break; }
            }
            if (teamOut) {
                Dim.broadcast(server, Component.literal("§4§lTEAM ELIMINATED §r" + label(team)), false);
                Visuals.sfx(server, "entity.lightning_bolt.thunder", 1.0F);
            }
            victoryCheckPending = true;
        }
        lastHit.remove(player.getUUID());
    }

    public void onRespawn(ServerPlayer player) {
        if (!Dim.inBw(player)) return; // respawned somewhere that is not BedWars territory
        UUID id = player.getUUID();
        if (!matchRunning) { teleportToLobby(player); return; }
        if (eliminated.contains(id) || !playerTeams.containsKey(id)) {
            player.setGameMode(GameType.SPECTATOR);
            player.sendSystemMessage(Component.literal("§cYou are eliminated: your team's bed was destroyed."));
            if (eliminated.contains(id)) TeamPovMenu.open(player);
            return;
        }
        player.setGameMode(GameType.SPECTATOR);
        routeRespawn(player);
        respawning.put(id, Math.max(1, Settings.integer("respawn_seconds")) * 20);
    }

    public void onJoin(ServerPlayer player) {
        if (!Dim.inBw(player)) return; // logged in inside the End (Hide & Seek) or Nether: leave them alone
        UUID id = player.getUUID();
        if (matchRunning) {
            if (eliminated.contains(id) || !playerTeams.containsKey(id) || respawning.containsKey(id)) player.setGameMode(GameType.SPECTATOR);
            return;
        }
        if (BedWarsBackup.restore(player, player.getServer())) return;
        if (lobby != null) { teleport(player, lobby); if (!isOp(player)) player.setGameMode(GameType.ADVENTURE); }
    }

    public void onDisconnect() { victoryCheckPending = true; }
    public boolean shouldOpenLobbyMenu(ServerPlayer player) { return Dim.inBw(player) && !matchRunning && lobby != null; }

    public List<ServerPlayer> survivingTeammates(ServerPlayer viewer) {
        String team = teamOf(viewer); if (team == null || viewer.getServer() == null) return List.of();
        List<ServerPlayer> out = new ArrayList<>();
        for (ServerPlayer p : Dim.players(viewer.getServer())) if (!p.getUUID().equals(viewer.getUUID()) && team.equals(teamOf(p)) && !eliminated.contains(p.getUUID()) && !p.isSpectator()) out.add(p);
        return out;
    }

    public boolean spectateTeammate(ServerPlayer viewer, UUID targetId) {
        if (!matchRunning || !eliminated.contains(viewer.getUUID()) || viewer.getServer() == null) return false;
        ServerPlayer target = viewer.getServer().getPlayerList().getPlayer(targetId);
        if (target == null || !survivingTeammates(viewer).contains(target)) return false;
        viewer.setGameMode(GameType.SPECTATOR); viewer.setCamera(target); return true;
    }

    // ------------------------------------------------------------------ ticking

    public void tick(MinecraftServer server) {
        tickVictory(server);
        tickCountdown(server);
        if (matchRunning) tickMatch(server);
        uiTicks++;
        // During a match the scoreboard refreshes on every whole match second (see tickMatch), so it matches the timeline.
        if (!matchRunning && uiTicks % 20 == 0) refreshUi(server);
        else if (uiTicks % 4 == 0 && Settings.flag("scoreboard") && Settings.flag("animated_scoreboard")) Sidebar.title(server, Visuals.header(uiTicks));
    }

    private void tickCountdown(MinecraftServer server) {
        if (countdownTicks < 0) return;
        if (matchRunning) { countdownTicks = -1; return; }
        if (countdownTicks % 20 == 0) {
            int seconds = countdownTicks / 20;
            if (seconds <= 0) {
                countdownTicks = -1;
                List<String> problems = validate(server);
                if (!problems.isEmpty()) {
                    Dim.broadcast(server, Component.literal("§cCountdown cancelled: " + problems.get(0)), false);
                    return;
                }
                begin(server);
                return;
            }
            if (getActiveTeams(server).size() < 2) {
                countdownTicks = -1;
                Dim.broadcast(server, Component.literal("§cCountdown cancelled: at least 2 teams need players."), false);
                return;
            }
            Visuals.countdown(server, seconds, Settings.integer("countdown_titles_from"));
        }
        countdownTicks--;
    }

    private void tickVictory(MinecraftServer server) {
        if (victoryTeam == null) return;
        if (matchRunning || victoryTicks <= 0) { victoryTeam = null; return; }
        victoryTicks--;
        if (victoryTicks % 20 != 0) return;
        for (ServerPlayer p : Dim.players(server)) {
            if (victoryMembers.contains(p.getUUID())) Fx.fireworks(server, p, victoryTeam);
        }
    }

    private void tickMatch(MinecraftServer server) {
        tickCounter++;
        matchTicks++;

        if (matchTicks % 20 == 0) { // once per whole match second: timeline events, then the scoreboard
            tickTimeline(server);
            if (!matchRunning) return;
            refreshUi(server);
        }

        if (!respawning.isEmpty()) {
            for (Map.Entry<UUID, Integer> e : new ArrayList<>(respawning.entrySet())) {
                ServerPlayer p = server.getPlayerList().getPlayer(e.getKey());
                if (p == null) continue;
                int left = e.getValue() - 1;
                if (left <= 0) {
                    respawning.remove(e.getKey());
                    p.setGameMode(GameType.SURVIVAL);
                    p.setHealth(p.getMaxHealth());
                    p.getFoodData().setFoodLevel(20);
                    routeRespawn(p);
                    giveKit(p);
                    Visuals.quick(p, "§a§lRESPAWNED", "");
                    Visuals.sfxTo(server, p, "entity.experience_orb.pickup", 0.8F);
                } else {
                    respawning.put(e.getKey(), left);
                    if (left % 20 == 0) p.displayClientMessage(Component.literal("§eRespawning in §f" + (left / 20) + "§e..."), true);
                }
            }
        }
        if (victoryCheckPending) { victoryCheckPending = false; checkVictory(server); if (!matchRunning) return; }
        if (tickCounter % 8 == 0 && Settings.flag("particles")) ambientParticles(server);
        if (tickCounter % 200 == 0 && Settings.flag("food_refill")) {
            for (ServerPlayer p : Dim.players(server)) {
                UUID id = p.getUUID();
                if (playerTeams.containsKey(id) && !eliminated.contains(id) && !respawning.containsKey(id)) p.getFoodData().setFoodLevel(20);
            }
        }
        if (tickCounter % 10 == 0) actionBars(server);
    }

    /** Sudden death: every bed that still stands is destroyed. */
    private void destroyAllBeds(MinecraftServer server) {
        Set<String> inPlay = new TreeSet<>(playerTeams.values());
        for (Map.Entry<String, TeamBed> e : beds.entrySet()) {
            TeamBed b = e.getValue();
            if (!b.alive) continue;
            ServerLevel level = levelOf(server, b.dimension);
            if (level != null) {
                int flags = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE; // no shape update: no item drops
                level.setBlock(b.foot, Blocks.AIR.defaultBlockState(), flags);
                level.setBlock(b.head, Blocks.AIR.defaultBlockState(), flags);
            }
            b.alive = false;
            if (level != null && inPlay.contains(e.getKey())) Visuals.bedBurst(server, level, b.head, e.getKey());
        }
        saveBeds();
        Dim.broadcast(server, Component.literal("§c§lBED GONE §7All remaining beds were destroyed. Every death is now final!"), false);
        victoryCheckPending = true;
    }

    /** Hearts above every standing bed; generator particles come from the generator manager. */
    private void ambientParticles(MinecraftServer server) {
        for (TeamBed b : beds.values()) {
            if (!b.alive) continue;
            ServerLevel level = levelOf(server, b.dimension);
            if (level == null || !level.hasChunkAt(b.head)) continue;
            if (!(level.getBlockState(b.head).getBlock() instanceof BedBlock)) continue; // a destroyed bed stops sparkling
            level.sendParticles(ParticleTypes.HEART, b.head.getX() + 0.5, b.head.getY() + 0.9, b.head.getZ() + 0.5, 1, 0.4, 0.1, 0.4, 0.0);
        }
        BedWarsGeneratorManager.ambientParticles(server);
    }

    // ------------------------------------------------------------------ sidebar / team colours (once per second)

    private void refreshUi(MinecraftServer server) {
        Sidebar.syncTeams(server);
        if (!Settings.flag("scoreboard")) { Sidebar.hide(server); return; }
        Sidebar.show(server, Visuals.header(uiTicks), matchRunning ? matchLines() : lobbyLines(server));
    }

    private static String capitalised(String team) { return team.substring(0, 1).toUpperCase(Locale.ROOT) + team.substring(1); }

    private static String clock(long ticks) {
        long seconds = Math.max(0L, ticks) / 20L;
        return String.format(Locale.ROOT, "%02d:%02d", seconds / 60L, seconds % 60L);
    }

    private int teamKills(String team) {
        int kills = 0;
        for (Map.Entry<UUID, String> e : playerTeams.entrySet()) if (team.equals(e.getValue())) kills += StatsManager.matchKills(e.getKey());
        return kills;
    }

    private List<String> matchLines() {
        List<String> out = new ArrayList<>();
        out.add("§7Elapsed: §f" + clock(matchTicks));
        out.add(remainingLine());
        out.add(nextEventLine());
        out.add(" ");
        Set<String> inPlay = new HashSet<>(playerTeams.values());
        for (String t : TEAMS) {
            if (!inPlay.contains(t)) continue;
            int alive = 0;
            for (Map.Entry<UUID, String> e : playerTeams.entrySet()) if (t.equals(e.getValue()) && !eliminated.contains(e.getKey())) alive++;
            String status = bedAlive(t) ? "§a✔ §7" + alive : alive > 0 ? "§f" + alive : "§c✘";
            out.add(color(t) + "§l" + t.substring(0, 1).toUpperCase(Locale.ROOT) + " §r" + color(t) + capitalised(t) + "§7: " + status
                    + " §8| §7⚔§f" + teamKills(t) + " §8| §7T§f" + BedWarsGeneratorManager.tierOf(t));
        }
        out.add("  ");
        out.add("§7Emerald §f" + BedWarsGeneratorManager.emeraldSeconds() + "s §8| §7Diamond §f" + BedWarsGeneratorManager.diamondSeconds() + "s");
        out.add("§e/bw shop §7- open the shop");
        return out;
    }

    // ------------------------------------------------------------------ match timeline (22:00 by default)

    private record TimelineEvent(String id, int seconds, String name) { }

    /** Fixed milestones in seconds from the start. A milestone at or after the match length is skipped. */
    private static final List<TimelineEvent> TIMELINE = List.of(
            new TimelineEvent("upgrade1", 300, "Upgrade I"),
            new TimelineEvent("upgrade2", 600, "Upgrade II"),
            new TimelineEvent("warn1", 900, "Warning"),
            new TimelineEvent("warn2", 1080, "Final Countdown"),
            new TimelineEvent("warn3", 1200, "Final 2 Minutes"));

    public long matchTicks() { return matchTicks; }
    public int upgradeLevel() { return upgradeLevel; }
    public boolean isSuddenDeath() { return suddenDeath; }

    /**
     * Runs once per whole match second, and only from tickMatch, so the timer follows the match state: it starts at
     * begin(), advances only while a match runs, and is never reset by anything else. Every event is recorded in
     * 'fired' before it runs, so none can run twice.
     */
    private void tickTimeline(MinecraftServer server) {
        long sec = matchTicks / 20L;
        long duration = matchEndTicks / 20L;
        for (TimelineEvent e : TIMELINE) {
            if (e.seconds() >= duration) continue;
            if (sec >= e.seconds() && fired.add(e.id())) fireEvent(server, e, duration);
        }
        if (suddenDeath) {
            if (suddenEndTicks > 0 && matchTicks >= suddenEndTicks && fired.add("sudden_end")) endMatch(server, null, "sudden death time limit");
            return;
        }
        long left = duration - sec;
        if (left > 0 && left <= 10) Visuals.finalSecond(server, (int) left, endAction.equals("sudden_death") ? "until sudden death" : "until the match ends");
        if (sec >= duration && fired.add("expire")) expire(server);
    }

    private String consequence() {
        return switch (endAction) {
            case "draw" -> "The match ends in a draw when time runs out.";
            case "most_alive" -> "The team with the most beds and players wins when time runs out.";
            default -> "All beds are destroyed when time runs out.";
        };
    }

    private void fireEvent(MinecraftServer server, TimelineEvent e, long duration) {
        String left = clock((duration - e.seconds()) * 20L);
        switch (e.id()) {
            case "upgrade1" -> {
                upgradeLevel = 1;
                int em = BedWarsGeneratorManager.emeraldSeconds();
                Visuals.milestone(server, "§b§lGENERATORS UPGRADED", "§7Upgrade I: emeralds every §f" + em + "s",
                        "§b§lUPGRADE I §7Neutral emerald generators now spawn every §f" + em + " seconds§7!", "block.beacon.power_select", 1.2F);
            }
            case "upgrade2" -> {
                upgradeLevel = 2;
                int em = BedWarsGeneratorManager.emeraldSeconds();
                int di = BedWarsGeneratorManager.diamondSeconds();
                Visuals.milestone(server, "§b§lGENERATORS UPGRADED", "§7Upgrade II: diamonds every §f" + di + "s§7, emeralds every §f" + em + "s",
                        "§b§lUPGRADE II §7Diamonds now every §f" + di + "s§7, emeralds every §f" + em + "s§7!", "block.beacon.power_select", 1.5F);
            }
            case "warn1" -> Visuals.milestone(server, "§e§lWARNING", "§7" + left + " remaining",
                    "§e§lWARNING §f" + left + " §7remaining. " + consequence(), "block.note_block.bell", 1.0F);
            case "warn2" -> Visuals.milestone(server, "§6§lFINAL COUNTDOWN", "§7" + left + " remaining",
                    "§6§lFINAL COUNTDOWN §f" + left + " §7remaining. " + consequence(), "block.note_block.bell", 0.8F);
            case "warn3" -> Visuals.milestone(server, "§c§lFINAL 2 MINUTES", "§7" + left + " remaining",
                    "§c§lFINAL 2 MINUTES §7" + consequence(), "block.bell.use", 0.6F);
            default -> { }
        }
    }

    /** The match length has been reached: end it or start sudden death (match_end_action, read at match start). */
    private void expire(MinecraftServer server) {
        switch (endAction) {
            case "draw" -> endMatch(server, null, "time limit reached");
            case "most_alive" -> endMatch(server, leader(server), "time limit reached");
            default -> startSuddenDeath(server);
        }
    }

    /** The team with the most standing beds and players, or null when two teams are tied. */
    private String leader(MinecraftServer server) {
        String best = null;
        int bestScore = -1;
        boolean tie = false;
        for (String t : aliveTeams(server)) {
            int alive = 0;
            for (Map.Entry<UUID, String> e : playerTeams.entrySet()) if (t.equals(e.getValue()) && !eliminated.contains(e.getKey())) alive++;
            int score = (bedAlive(t) ? 1000 : 0) + alive;
            if (score > bestScore) { best = t; bestScore = score; tie = false; }
            else if (score == bestScore) tie = true;
        }
        return tie ? null : best;
    }

    private void startSuddenDeath(MinecraftServer server) {
        suddenDeath = true;
        int extra = Settings.integer("sudden_death_minutes");
        suddenEndTicks = extra > 0 ? matchTicks + extra * 1200L : 0L;
        destroyAllBeds(server);
        Visuals.milestone(server, "§4§lSUDDEN DEATH", "§7Time is up: every death is final!",
                "§4§lSUDDEN DEATH §7Time is up!" + (extra > 0 ? " The match ends in §f" + extra + " min§7 if nobody has won." : ""),
                "entity.wither.spawn", 1.0F);
    }

    private String remainingLine() {
        if (suddenDeath) return suddenEndTicks > 0 ? "§4§lSUDDEN DEATH §f" + clock(suddenEndTicks - matchTicks) : "§4§lSUDDEN DEATH";
        long left = Math.max(0L, matchEndTicks / 20L - matchTicks / 20L);
        String colour = left > 600 ? "§a" : left > 300 ? "§e" : left > 120 ? "§6" : (left <= 10 && left % 2 == 0) ? "§f" : "§c";
        return "§7Remaining: " + colour + "§l" + clock(left * 20L);
    }

    private String nextEventLine() {
        if (suddenDeath) return "§cEvery death is final!";
        long duration = matchEndTicks / 20L;
        for (TimelineEvent e : TIMELINE) {
            if (e.seconds() < duration && !fired.contains(e.id())) return "§7Next: §b" + e.name() + " §7in §f" + clock(e.seconds() * 20L - matchTicks);
        }
        return "§7Next: §c" + (endAction.equals("sudden_death") ? "Sudden Death" : "Match End") + " §7in §f" + clock(matchEndTicks - matchTicks);
    }

    /** Lines for the admin and shop GUIs. */
    public List<String> timelineSummary() {
        List<String> out = new ArrayList<>();
        if (matchRunning) {
            out.add("§7Elapsed: §f" + clock(matchTicks));
            out.add(remainingLine());
            out.add(nextEventLine());
        } else {
            out.add("§7Match length: §f" + clock(Math.max(60, Settings.integer("match_duration_seconds")) * 20L));
            out.add("§7When time is up: §f" + Settings.text("match_end_action"));
        }
        return out;
    }

    /** Live action bar: team, bed, generator tier and the player's own resources. Notifications take priority (Visuals). */
    private void actionBars(MinecraftServer server) {
        if (!Settings.flag("action_bar")) return;
        int teamsLeft = aliveTeams(server).size();
        for (ServerPlayer p : Dim.players(server)) {
            UUID id = p.getUUID();
            if (respawning.containsKey(id)) continue; // the respawn countdown owns the bar
            String t = playerTeams.get(id);
            String text;
            if (t == null || eliminated.contains(id)) {
                text = "§7Spectating §8| §7Teams left §f" + teamsLeft;
            } else {
                text = label(t) + " §8| §7Bed " + (bedAlive(t) ? "§a✔" : "§c✘") + " §8| §7Gen §fT" + BedWarsGeneratorManager.tierOf(t)
                        + " §8| §fFe §7" + BedWarsShop.count(p, Items.IRON_INGOT) + " §6Au §7" + BedWarsShop.count(p, Items.GOLD_INGOT)
                        + " §bDia §7" + BedWarsShop.count(p, Items.DIAMOND) + " §aEm §7" + BedWarsShop.count(p, Items.EMERALD);
            }
            Visuals.info(p, text);
        }
    }

    private List<String> lobbyLines(MinecraftServer server) {
        List<String> out = new ArrayList<>();
        out.add(countdownTicks >= 0 ? "§eStarting in §f" + ((countdownTicks + 19) / 20) + "s" : "§7Waiting for players...");
        out.add(" ");
        for (Map.Entry<String, List<String>> e : getTeamRoster(server).entrySet()) {
            out.add(color(e.getKey()) + capitalised(e.getKey()) + "§7: §f" + e.getValue().size());
        }
        out.add("  ");
        out.add("§7Match length: §f" + clock(Math.max(60, Settings.integer("match_duration_seconds")) * 20L));
        out.add("§e/bw menu §7- pick a team");
        return out;
    }

    // ------------------------------------------------------------------ reports

    public String status() {
        long aliveBeds = beds.values().stream().filter(b -> b.alive).count();
        return "match=" + (matchRunning ? "running" : "lobby") + ", assignedPlayers=" + playerTeams.size()
                + ", registeredBeds=" + beds.size() + " (alive " + aliveBeds + "), spawns=" + spawns.size()
                + ", eliminated=" + eliminated.size() + ", lobby=" + (lobby != null ? "set" : "not set");
    }

    public List<String> setupReport() {
        List<String> out = new ArrayList<>();
        out.add("§6§lSETUP CHECKLIST");
        out.add("Lobby: " + (lobby != null ? "§a✔" : "§c✘ §7(/bw lobby set)"));
        out.add("Protected regions: " + (BedWarsMod.PROTECTION.regions().isEmpty() ? "§c✘ §7(/bw region add <name> <from> <to>)" : "§a✔ " + BedWarsMod.PROTECTION.regions().size()));
        for (String t : TEAMS) {
            out.add(label(t) + " §7spawn " + (spawns.containsKey(t) ? "§a✔" : "§c✘") + " §7bed " + (beds.containsKey(t) ? "§a✔" : "§c✘")
                    + " §7generator " + (BedWarsGeneratorManager.hasTeamBase(t) ? "§a✔" : "§c✘"));
        }
        out.add("Neutral generators: §f" + BedWarsGeneratorManager.neutralCount() + " §7(diamond/emerald)");
        return out;
    }
}
