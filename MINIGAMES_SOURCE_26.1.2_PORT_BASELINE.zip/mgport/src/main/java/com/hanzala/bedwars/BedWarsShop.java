package com.hanzala.bedwars;

import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.enchantment.Enchantment;

import java.util.*;
import java.util.function.BiFunction;

/** Server-authoritative shop: chest GUI, villager NPC and commands all go through buy(). */
public final class BedWarsShop {
    private BedWarsShop() {}

    /** One shop item. Price, amount, currency and on/off come from ShopConfig, so admins can change them live. */
    public record Offer(String id, String name, Item icon, BiFunction<ServerPlayer, Integer, ItemStack> builder) {
        public int amount() { return ShopConfig.amount(id); }
        public Item currency() { return ShopConfig.currency(id); }
        public int price() { return ShopConfig.price(id); }
        public boolean enabled() { return ShopConfig.enabled(id); }
    }

    /** Items whose amount per purchase an admin may change (single tools, swords and potions are always 1). */
    private static final Set<String> STACKABLE = Set.of("wool", "planks", "terracotta", "end_stone", "glass", "obsidian",
            "ladder", "cobweb", "arrows", "tnt", "golden_apple", "ender_pearl");

    private static final Map<String, Offer> OFFERS = new LinkedHashMap<>();
    private static final Map<String, String> ALIASES = Map.of("speed_ii_45s", "speed", "jump_v_45s", "jump", "endstone", "end_stone");
    private static final Map<UUID, Integer> ARMOR = new HashMap<>();

    static {
        // Blocks (wool / terracotta / glass take the buyer's team colour)
        offer("wool", "Wool", Items.WHITE_WOOL, 16, Items.IRON_INGOT, 4, (p, n) -> coloured(p, "wool", n));
        offer("planks", "Oak Planks", Items.OAK_PLANKS, 16, Items.GOLD_INGOT, 8, (p, n) -> new ItemStack(Items.OAK_PLANKS, n));
        offer("terracotta", "Terracotta", Items.TERRACOTTA, 16, Items.GOLD_INGOT, 16, (p, n) -> coloured(p, "terracotta", n));
        offer("end_stone", "End Stone", Items.END_STONE, 12, Items.GOLD_INGOT, 20, (p, n) -> new ItemStack(Items.END_STONE, n));
        offer("glass", "Glass", Items.GLASS, 4, Items.GOLD_INGOT, 12, (p, n) -> coloured(p, "stained_glass", n));
        offer("obsidian", "Obsidian", Items.OBSIDIAN, 4, Items.EMERALD, 6, (p, n) -> new ItemStack(Items.OBSIDIAN, n));
        offer("ladder", "Ladder", Items.LADDER, 8, Items.GOLD_INGOT, 4, (p, n) -> new ItemStack(Items.LADDER, n));
        offer("cobweb", "Cobweb", Items.COBWEB, 2, Items.GOLD_INGOT, 6, (p, n) -> new ItemStack(Items.COBWEB, n));
        // Weapons
        offer("stone_sword", "Stone Sword", Items.STONE_SWORD, 1, Items.GOLD_INGOT, 5, (p, n) -> new ItemStack(Items.STONE_SWORD));
        offer("iron_sword", "Iron Sword", Items.IRON_SWORD, 1, Items.GOLD_INGOT, 12, (p, n) -> new ItemStack(Items.IRON_SWORD));
        offer("diamond_sword", "Diamond Sword", Items.DIAMOND_SWORD, 1, Items.EMERALD, 6, (p, n) -> new ItemStack(Items.DIAMOND_SWORD));
        offer("knockback_stick", "Knockback Stick", Items.STICK, 1, Items.GOLD_INGOT, 8, (p, n) -> {
            ItemStack s = enchanted(p, Items.STICK, 1, "knockback", 1);
            s.set(DataComponents.CUSTOM_NAME, plain("§fKnockback Stick"));
            return s;
        });
        offer("bow", "Bow", Items.BOW, 1, Items.GOLD_INGOT, 16, (p, n) -> new ItemStack(Items.BOW));
        offer("power_bow", "Bow (Power I)", Items.BOW, 1, Items.GOLD_INGOT, 36, (p, n) -> enchanted(p, Items.BOW, 1, "power", 1));
        offer("arrows", "Arrows", Items.ARROW, 8, Items.GOLD_INGOT, 4, (p, n) -> new ItemStack(Items.ARROW, n));
        // Tools
        offer("shears", "Shears", Items.SHEARS, 1, Items.GOLD_INGOT, 20, (p, n) -> new ItemStack(Items.SHEARS));
        offer("iron_pickaxe", "Iron Pickaxe (Eff I)", Items.IRON_PICKAXE, 1, Items.GOLD_INGOT, 8, (p, n) -> enchanted(p, Items.IRON_PICKAXE, 1, "efficiency", 1));
        offer("iron_axe", "Iron Axe (Eff I)", Items.IRON_AXE, 1, Items.GOLD_INGOT, 8, (p, n) -> enchanted(p, Items.IRON_AXE, 1, "efficiency", 1));
        offer("diamond_pickaxe", "Diamond Pickaxe (Eff II)", Items.DIAMOND_PICKAXE, 1, Items.EMERALD, 4, (p, n) -> enchanted(p, Items.DIAMOND_PICKAXE, 1, "efficiency", 2));
        offer("diamond_axe", "Diamond Axe (Eff II)", Items.DIAMOND_AXE, 1, Items.EMERALD, 4, (p, n) -> enchanted(p, Items.DIAMOND_AXE, 1, "efficiency", 2));
        // Utility
        offer("golden_apple", "Golden Apple", Items.GOLDEN_APPLE, 1, Items.GOLD_INGOT, 8, (p, n) -> new ItemStack(Items.GOLDEN_APPLE, n));
        offer("ender_pearl", "Ender Pearl", Items.ENDER_PEARL, 1, Items.EMERALD, 6, (p, n) -> new ItemStack(Items.ENDER_PEARL, n));
        offer("water_bucket", "Water Bucket", Items.WATER_BUCKET, 1, Items.GOLD_INGOT, 6, (p, n) -> new ItemStack(Items.WATER_BUCKET));
        offer("tnt", "TNT", Items.TNT, 4, Items.DIAMOND, 4, (p, n) -> new ItemStack(Items.TNT, n));
        offer("speed", "Speed II (0:45)", Items.POTION, 1, Items.EMERALD, 2, (p, n) -> potion("speed", 900, 1, "§bSpeed II Potion §7(0:45)"));
        offer("jump", "Jump Boost V (0:45)", Items.POTION, 1, Items.EMERALD, 2, (p, n) -> potion("jump_boost", 900, 4, "§aJump V Potion §7(0:45)"));
    }

    private static void offer(String id, String name, Item icon, int amount, Item currency, int price, BiFunction<ServerPlayer, Integer, ItemStack> b) {
        OFFERS.put(id, new Offer(id, name, icon, b));
        ShopConfig.register(id, name, icon, price, ShopConfig.id(currency), amount, STACKABLE.contains(id));
    }

    public static Collection<Offer> offers() { return OFFERS.values(); }
    public static Collection<String> offerIds() { return OFFERS.keySet(); }
    public static Offer offer(String id) { return OFFERS.get(id); }

    // ------------------------------------------------------------------ item builders

    private static Component plain(String s) { return Component.literal(s).withStyle(st -> st.withItalic(false)); }

    private static ItemStack coloured(ServerPlayer p, String suffix, int amount) {
        String team = BedWarsMod.GAME.teamOf(p);
        String colour = team == null ? "white" : team;
        Item item = BuiltInRegistries.ITEM.getValue(ResourceLocation.withDefaultNamespace(colour + "_" + suffix));
        if (item == Items.AIR) item = BuiltInRegistries.ITEM.getValue(ResourceLocation.withDefaultNamespace("white_" + suffix));
        return new ItemStack(item, amount);
    }

    private static ItemStack enchanted(ServerPlayer p, Item item, int amount, String enchantId, int level) {
        ItemStack stack = new ItemStack(item, amount);
        var lookup = p.level().registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        Holder<Enchantment> holder = lookup.getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.withDefaultNamespace(enchantId)));
        stack.enchant(holder, level);
        return stack;
    }

    private static ItemStack potion(String effectId, int ticks, int amplifier, String name) {
        Holder<MobEffect> effect = BuiltInRegistries.MOB_EFFECT.get(ResourceLocation.withDefaultNamespace(effectId)).orElseThrow();
        ItemStack stack = new ItemStack(Items.POTION);
        stack.set(DataComponents.POTION_CONTENTS, new PotionContents(Optional.empty(), Optional.empty(),
                List.of(new MobEffectInstance(effect, ticks, amplifier)), Optional.empty()));
        stack.set(DataComponents.CUSTOM_NAME, plain(name));
        return stack;
    }

    // ------------------------------------------------------------------ GUI

    public static void open(ServerPlayer player) {
        MenuProvider provider = new SimpleMenuProvider((id, inv, p) -> new ShopMenu(id, inv), Component.literal("BedWars Shop"));
        player.openMenu(provider);
    }

    public static void list(ServerPlayer player) {
        player.sendSystemMessage(Component.literal("§6§lBEDWARS SHOP §7— /bw shop opens the menu, or /bw shop buy <item>"));
        for (Offer o : OFFERS.values()) {
            if (!o.enabled()) continue;
            player.sendSystemMessage(Component.literal("§e" + o.id() + " §7x" + o.amount() + " §8- §f" + o.price() + " " + currencyName(o.currency())));
        }
        player.sendSystemMessage(Component.literal("§eArmour: §f/bw shop armor chain (" + costText("armor.chain") + ") | iron (" + costText("armor.iron") + ") | diamond (" + costText("armor.diamond") + ")"));
        player.sendSystemMessage(Component.literal("§eGenerator: §f/bw generator upgrade"));
    }

    // ------------------------------------------------------------------ buying

    public static boolean buy(ServerPlayer player, String rawId) {
        String id = rawId.toLowerCase(Locale.ROOT);
        id = ALIASES.getOrDefault(id, id);
        Offer offer = OFFERS.get(id);
        if (offer == null) { msg(player, "§cUnknown shop item. Use /bw shop to see the catalogue."); return false; }
        if (!offer.enabled()) { msg(player, "§cThis item is not for sale right now."); return false; }
        if (BedWarsMod.GAME.teamOf(player) == null) { msg(player, "§cJoin a team first (/bw menu)."); return false; }
        if (!take(player, offer.currency(), offer.price())) {
            msg(player, "§cNot enough " + currencyName(offer.currency()) + ". Cost: " + offer.price() + ".");
            return false;
        }
        ItemStack stack = offer.builder().apply(player, offer.amount());
        if (!player.getInventory().add(stack)) player.drop(stack, false);
        msg(player, "§aPurchased " + offer.name + ".");
        return true;
    }

    public static boolean buyArmor(ServerPlayer player, String tier) {
        int requested;
        String key = "armor." + tier.toLowerCase(Locale.ROOT);
        switch (tier.toLowerCase(Locale.ROOT)) {
            case "chain" -> requested = 1;
            case "iron" -> requested = 2;
            case "diamond" -> requested = 3;
            default -> { msg(player, "§cArmour tier must be chain, iron or diamond."); return false; }
        }
        int price = ShopConfig.price(key);
        Item currency = ShopConfig.currency(key);
        if (!ShopConfig.enabled(key)) { msg(player, "§cThis armour is not for sale right now."); return false; }
        if (BedWarsMod.GAME.teamOf(player) == null) { msg(player, "§cJoin a team first (/bw menu)."); return false; }
        if (requested <= ARMOR.getOrDefault(player.getUUID(), 0)) { msg(player, "§cYou already own this armour tier or better."); return false; }
        if (!take(player, currency, price)) { msg(player, "§cNot enough " + currencyName(currency) + ". Cost: " + price + "."); return false; }
        ARMOR.put(player.getUUID(), requested);
        equipArmor(player, requested);
        msg(player, "§aArmour upgraded to " + tier.toLowerCase(Locale.ROOT) + ". You keep it after dying.");
        return true;
    }

    public static void restoreArmor(ServerPlayer player) {
        int tier = ARMOR.getOrDefault(player.getUUID(), 0);
        if (tier > 0) equipArmor(player, tier);
    }

    public static void resetArmor() { ARMOR.clear(); }

    /** 0 = none, 1 = chain, 2 = iron, 3 = diamond. */
    public static int armorTier(ServerPlayer player) { return ARMOR.getOrDefault(player.getUUID(), 0); }

    private static void equipArmor(ServerPlayer p, int tier) {
        Item legs = tier == 1 ? Items.CHAINMAIL_LEGGINGS : tier == 2 ? Items.IRON_LEGGINGS : Items.DIAMOND_LEGGINGS;
        Item boots = tier == 1 ? Items.CHAINMAIL_BOOTS : tier == 2 ? Items.IRON_BOOTS : Items.DIAMOND_BOOTS;
        p.setItemSlot(EquipmentSlot.LEGS, new ItemStack(legs));
        p.setItemSlot(EquipmentSlot.FEET, new ItemStack(boots));
    }

    // ------------------------------------------------------------------ currency helpers

    static boolean take(ServerPlayer player, Item currency, int amount) {
        if (count(player, currency) < amount) return false;
        int remaining = amount;
        for (int slot = 0; slot < player.getInventory().getContainerSize() && remaining > 0; slot++) {
            ItemStack stack = player.getInventory().getItem(slot);
            if (!stack.isEmpty() && stack.is(currency)) {
                int n = Math.min(remaining, stack.getCount());
                stack.shrink(n);
                remaining -= n;
                if (stack.isEmpty()) player.getInventory().setItem(slot, ItemStack.EMPTY);
            }
        }
        return true;
    }

    static int count(ServerPlayer player, Item item) {
        int total = 0;
        for (int slot = 0; slot < player.getInventory().getContainerSize(); slot++) {
            ItemStack stack = player.getInventory().getItem(slot);
            if (!stack.isEmpty() && stack.is(item)) total += stack.getCount();
        }
        return total;
    }

    /** Several costs at once (e.g. generator Tier III); costs in the same currency are added together. */
    static boolean canAfford(ServerPlayer player, String... keys) {
        Map<Item, Integer> need = new HashMap<>();
        for (String k : keys) need.merge(ShopConfig.currency(k), ShopConfig.price(k), Integer::sum);
        for (Map.Entry<Item, Integer> e : need.entrySet()) if (count(player, e.getKey()) < e.getValue()) return false;
        return true;
    }

    /** Takes the costs checked by canAfford(). */
    static void charge(ServerPlayer player, String... keys) {
        Map<Item, Integer> need = new HashMap<>();
        for (String k : keys) need.merge(ShopConfig.currency(k), ShopConfig.price(k), Integer::sum);
        for (Map.Entry<Item, Integer> e : need.entrySet()) take(player, e.getKey(), e.getValue());
    }

    /** "16 Gold" for the price entry with this key. */
    static String costText(String key) { return ShopConfig.price(key) + " " + currencyName(ShopConfig.currency(key)); }

    static String currencyName(Item item) {
        if (item == Items.IRON_INGOT) return "Iron";
        if (item == Items.GOLD_INGOT) return "Gold";
        if (item == Items.DIAMOND) return "Diamond";
        return "Emerald";
    }

    private static void msg(ServerPlayer p, String s) { p.sendSystemMessage(Component.literal(s)); }
}
