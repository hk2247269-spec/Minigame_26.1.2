package com.hanzala.bedwars;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Base class for the BedWars chest GUIs (team picker and admin panels). Like the shop, these are vanilla
 * chest screens driven entirely by the server: players need no client mod, nothing can be taken out,
 * and every click is handled here.
 *
 * Subclasses implement build(): call reset(), then put(...) icons. Call build() once at the end of the
 * subclass constructor, and refresh() after a click changed something.
 */
public abstract class ServerGui extends ChestMenu {
    @FunctionalInterface
    protected interface Click {
        /** button: 0 = left click, 1 = right click. shift: shift-click. */
        void on(ServerPlayer player, int button, boolean shift);
    }

    private final Map<Integer, Click> clicks = new HashMap<>();
    private final int slotCount;
    protected final ServerPlayer viewer;

    protected ServerGui(int rows, int containerId, Inventory inventory) {
        super(typeFor(rows), containerId, inventory, new SimpleContainer(rows * 9), rows);
        this.slotCount = rows * 9;
        this.viewer = inventory.player instanceof ServerPlayer sp ? sp : null;
    }

    private static MenuType<?> typeFor(int rows) {
        return switch (rows) {
            case 1 -> MenuType.GENERIC_9x1;
            case 2 -> MenuType.GENERIC_9x2;
            case 3 -> MenuType.GENERIC_9x3;
            case 4 -> MenuType.GENERIC_9x4;
            case 5 -> MenuType.GENERIC_9x5;
            default -> MenuType.GENERIC_9x6;
        };
    }

    /** Draw every icon here: call reset() first, then put(...). */
    protected abstract void build();

    /** Rebuilds the screen after something changed and pushes it to the player. */
    protected final void refresh() {
        build();
        sendAllDataToRemote();
    }

    // ------------------------------------------------------------------ building blocks

    /** Clears every icon and fills the screen with grey glass. Call first in build(). */
    protected final void reset() {
        clicks.clear();
        Container c = getContainer();
        ItemStack filler = new ItemStack(Items.GRAY_STAINED_GLASS_PANE);
        filler.set(DataComponents.CUSTOM_NAME, Component.literal(" "));
        for (int i = 0; i < slotCount; i++) c.setItem(i, filler.copy());
    }

    protected final void put(int slot, ItemStack icon, Click click) {
        if (slot < 0 || slot >= slotCount) return;
        getContainer().setItem(slot, icon);
        if (click != null) clicks.put(slot, click);
    }

    protected final void put(int slot, ItemStack icon) { put(slot, icon, null); }

    /** Like put(), but the click only runs for operators (checked again at click time). */
    protected final void putAdmin(int slot, ItemStack icon, Click click) {
        put(slot, icon, (p, button, shift) -> {
            if (!isAdmin(p)) { p.closeContainer(); return; }
            click.on(p, button, shift);
        });
    }

    /** Short message above the hotbar (does not use the chat). */
    protected static void bar(ServerPlayer p, String text) { p.displayClientMessage(Component.literal(text), true); }

    protected static boolean isAdmin(ServerPlayer p) { return p.createCommandSourceStack().hasPermission(2); }

    protected static ItemStack icon(Item item, int amount, String name, List<String> lore) {
        ItemStack s = new ItemStack(item, Math.max(1, Math.min(amount, 64)));
        s.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(st -> st.withItalic(false)));
        List<Component> lines = new ArrayList<>();
        for (String l : lore) lines.add(Component.literal(l).withStyle(st -> st.withItalic(false)));
        s.set(DataComponents.LORE, new ItemLore(lines));
        return s;
    }

    protected static ItemStack icon(Item item, String name, String... lore) { return icon(item, 1, name, List.of(lore)); }

    protected static ItemStack icon(Item item, String name, List<String> lore) { return icon(item, 1, name, lore); }

    /** Adds the enchantment shimmer (used to mark the selected / active entry). */
    protected static ItemStack glow(ItemStack s) {
        s.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, Boolean.TRUE);
        return s;
    }

    /** Splits a long sentence into grey lore lines (item tooltips do not wrap by themselves). */
    protected static List<String> wrap(String text, int width) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            if (line.length() > 0 && line.length() + 1 + word.length() > width) {
                out.add("§7" + line);
                line.setLength(0);
            }
            if (line.length() > 0) line.append(' ');
            line.append(word);
        }
        if (line.length() > 0) out.add("§7" + line);
        return out;
    }

    /** Wool block in the team's colour. */
    protected static Item teamWool(String team) {
        return switch (team) {
            case "red" -> Items.RED_WOOL;
            case "blue" -> Items.BLUE_WOOL;
            case "green" -> Items.LIME_WOOL;
            case "yellow" -> Items.YELLOW_WOOL;
            case "pink" -> Items.PINK_WOOL;
            default -> Items.WHITE_WOOL;
        };
    }

    protected static String capitalised(String s) {
        return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    // ------------------------------------------------------------------ click handling

    @Override
    public void clicked(int slotId, int button, ClickType clickType, Player player) {
        if (slotId >= 0 && slotId < slotCount) {
            Click click = clicks.get(slotId);
            if (click != null && player instanceof ServerPlayer sp
                    && (clickType == ClickType.PICKUP || clickType == ClickType.QUICK_MOVE)) {
                click.on(sp, button, clickType == ClickType.QUICK_MOVE);
            }
            if (player.containerMenu == this) sendAllDataToRemote(); // undo anything the client predicted
            return;
        }
        if (clickType == ClickType.QUICK_MOVE || clickType == ClickType.PICKUP_ALL) { sendAllDataToRemote(); return; }
        super.clicked(slotId, button, clickType, player);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) { return ItemStack.EMPTY; }
}
