package com.hanzala.minigames;

import com.hanzala.bedwars.BedWarsGameManager;
import com.hanzala.bedwars.BedWarsMod;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Plugs the existing BedWars engine ({@link BedWarsMod#GAME}) into /mg. BedWars itself is not changed in behaviour: joining =
 * being put on the emptiest team, the existing countdown / match logic starts the game as soon as two teams have players,
 * and when a match ends everybody is back in the common lobby with a free slate (no team), so they can pick any game again.
 */
public final class BedWarsAdapter implements ExternalGame {
    private static BedWarsGameManager g() { return BedWarsMod.GAME; }

    @Override
    public MinigameType type() { return MinigameType.BEDWARS; }

    @Override
    public boolean isInGame(ServerPlayer p) { return g().teamOf(p) != null; }

    /** Teams that have both a bed and a spawn registered (only those can be played). */
    private static List<String> readyTeams() {
        List<String> out = new ArrayList<>();
        for (String t : BedWarsGameManager.TEAMS) if (g().hasBed(t) && g().hasSpawn(t)) out.add(t);
        return out;
    }

    private static String setupProblem() {
        if (readyTeams().size() < 2) return "BedWars is not set up yet (needs 2+ teams with a bed and a spawn: /bw).";
        return null;
    }

    /** The ready team with the fewest players (ties: first in the team list). */
    private static String emptiestTeam(MinecraftServer server) {
        Map<String, List<String>> roster = g().getTeamRoster(server);
        String best = null;
        int bestSize = Integer.MAX_VALUE;
        for (String t : readyTeams()) {
            int n = roster.getOrDefault(t, List.of()).size();
            if (n < bestSize) { best = t; bestSize = n; }
        }
        return best;
    }

    private static int participants(MinecraftServer server) {
        int n = 0;
        for (ServerPlayer p : server.getPlayerList().getPlayers()) if (g().teamOf(p) != null) n++;
        return n;
    }

    @Override
    public Mg.Status status(MinecraftServer server) {
        String problem = setupProblem();
        if (problem != null) return new Mg.Status("§8Not set up", 0, 0, "-", false, problem);
        int players = server == null ? 0 : participants(server);
        String label = g().isRunning() ? "§cRunning" : g().isCountingDown() ? "§eStarting soon" : "§aWaiting";
        String map = "Current map";
        if (g().isRunning()) return new Mg.Status(label, players, 0, map, false, "A match is already running.");
        return new Mg.Status(label, players, 0, map, true, null);
    }

    @Override
    public String join(ServerPlayer p) {
        MinecraftServer server = p.getServer();
        if (server == null) return "Server is not ready.";
        if (g().isRunning()) return "A BedWars match is already running.";
        if (g().teamOf(p) != null) return "You are already in BedWars.";
        String problem = setupProblem();
        if (problem != null) return problem;
        String team = emptiestTeam(server);
        if (team == null || !g().assignTeam(p, team)) return "Could not join BedWars right now.";
        p.sendSystemMessage(MgUtil.msg("You joined team " + BedWarsGameManager.label(team) + "§7. The match starts as soon as two teams have players."));
        tryAutoStart(server);
        return null;
    }

    /** Starts the existing BedWars countdown once two teams have players. Silently does nothing otherwise. */
    private static void tryAutoStart(MinecraftServer server) {
        if (g().isRunning() || g().isCountingDown()) return;
        if (g().getActiveTeams(server).size() < 2) return;
        g().start(server);
    }

    @Override
    public boolean leave(ServerPlayer p) {
        MinecraftServer server = p.getServer();
        if (!g().forceLeave(p)) return false;
        Lobby.send(p);
        Lobby.giveMenuItem(p);
        p.sendSystemMessage(MgUtil.msg("You left BedWars."));
        // a countdown that no longer has two teams is cancelled
        if (server != null && g().isCountingDown() && g().getActiveTeams(server).size() < 2) g().stop(server);
        return true;
    }

    @Override
    public String forceAll(MinecraftServer server, CommandSourceStack by) {
        List<ServerPlayer> everyone = new ArrayList<>(server.getPlayerList().getPlayers());
        if (everyone.size() < 2) return "At least 2 players must be online for BedWars (found " + everyone.size() + ").";
        String problem = setupProblem();
        if (problem != null) return problem;
        for (ServerPlayer p : everyone) {
            if (g().teamOf(p) != null) continue;
            String team = emptiestTeam(server);
            if (team != null) g().assignTeamByAdmin(p, team);
        }
        if (participants(server) < 2) { g().clearTeams(); return "Fewer than 2 players could be put on teams."; }
        List<String> problems = g().start(server);
        if (!problems.isEmpty()) {
            g().clearTeams();
            return "BedWars cannot start: " + String.join(" ", problems);
        }
        return null;
    }

    @Override
    public String forcePlayer(MinecraftServer server, ServerPlayer target) {
        if (g().isRunning()) return "A BedWars match is already running.";
        String problem = setupProblem();
        if (problem != null) return problem;
        String team = emptiestTeam(server);
        if (team == null || !g().assignTeamByAdmin(target, team)) return "Could not put " + target.getName().getString() + " on a team.";
        target.sendSystemMessage(MgUtil.msg("An admin put you on team " + BedWarsGameManager.label(team) + "§7."));
        return null;
    }

    @Override
    public void forceStop(MinecraftServer server) {
        if (server == null) return;
        if (g().isRunning() || g().isCountingDown()) g().stop(server);
        g().clearTeams(); // waiting players are released too
    }
}
