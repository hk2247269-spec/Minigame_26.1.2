package com.hanzala.minigames;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * The reset data of ONE arena: the ORIGINAL block state of every block a minigame changed. Call {@link #capture} BEFORE
 * changing a block; call {@link #restoreSome} (or {@link #restoreAll}) to put the original blocks back.
 *
 * It is written to config/minigames/journals/&lt;arena&gt;.json so that a crash cannot leave a hole in the map: on the next
 * server start Mg.recoverJournals() restores every journal that is still on disk. Only blocks inside the arena box are
 * ever captured or restored, so a reset can never touch the lobby, another arena or the rest of the world.
 *
 * Block entities (chests etc.) are not saved - minigame arenas are not supposed to contain any.
 */
public final class BlockJournal {
    private final Arena arena;
    private final Map<Long, BlockState> original = new LinkedHashMap<>();
    /** Positions captured since the last flush (only these are appended to the file: no full rewrite). */
    private final List<Long> unsaved = new ArrayList<>();
    private boolean dirty;

    public BlockJournal(Arena arena) { this.arena = arena; }

    private static Path file(Arena a) {
        Path d = MgSettings.dir().resolve("journals");
        try { Files.createDirectories(d); } catch (Exception e) { MgMod.LOG.error("journal dir", e); }
        return d.resolve(a.id.toLowerCase() + ".json");
    }

    public int size() { return original.size(); }

    public boolean isEmpty() { return original.isEmpty(); }

    /** Remember what is at {@code pos} (first call per position wins). Returns false when pos is outside the arena (then do NOT change the block). */
    public boolean capture(ServerLevel level, BlockPos pos) {
        if (!arena.contains(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5)) return false;
        if (original.putIfAbsent(pos.asLong(), level.getBlockState(pos)) == null) { unsaved.add(pos.asLong()); dirty = true; }
        return true;
    }

    /** Puts back up to {@code max} blocks. Returns true once everything is restored (journal file is deleted then). */
    public boolean restoreSome(ServerLevel level, int max) {
        int done = 0;
        Iterator<Map.Entry<Long, BlockState>> it = original.entrySet().iterator();
        while (it.hasNext() && done < max) {
            Map.Entry<Long, BlockState> e = it.next();
            BlockPos pos = BlockPos.of(e.getKey());
            if (arena.contains(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5)) {
                level.setBlock(pos, e.getValue(), 2); // flag 2: no neighbour updates, so nothing pops off or falls during the restore
            }
            it.remove();
            done++;
        }
        if (original.isEmpty()) {
            try { Files.deleteIfExists(file(arena)); } catch (Exception ex) { MgMod.LOG.error("journal delete", ex); }
            dirty = false;
            unsaved.clear();
            return true;
        }
        return false;
    }

    public void restoreAll(ServerLevel level) {
        while (!restoreSome(level, 5000)) { /* keep going */ }
    }

    // ------------------------------------------------------------------ persistence

    /**
     * Appends the blocks captured since the last call to the journal file (one JSON object per line). Only new entries are
     * written, so this stays cheap even for huge arenas. Cheap to call often.
     */
    public void flush() {
        if (unsaved.isEmpty()) { dirty = false; return; }
        try {
            List<String> lines = new ArrayList<>(unsaved.size());
            Gson gson = new Gson();
            for (Long key : unsaved) {
                BlockState st = original.get(key);
                if (st == null) continue; // already restored
                BlockPos p = BlockPos.of(key);
                JsonObject o = new JsonObject();
                o.addProperty("x", p.getX());
                o.addProperty("y", p.getY());
                o.addProperty("z", p.getZ());
                o.addProperty("b", BuiltInRegistries.BLOCK.getKey(st.getBlock()).toString());
                JsonObject props = new JsonObject();
                for (Property<?> prop : st.getProperties()) props.addProperty(prop.getName(), valueName(prop, st));
                if (props.size() > 0) o.add("p", props);
                lines.add(gson.toJson(o));
            }
            if (!lines.isEmpty()) {
                Files.write(file(arena), lines, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            }
            unsaved.clear();
            dirty = false;
        } catch (Exception ex) {
            MgMod.LOG.error("Could not write journal of arena " + arena.id, ex);
        }
    }

    /** Loads a journal left on disk by a crash (adds to what is in memory). Reads the line format and the old array format. */
    public void loadFromDisk() {
        Path f = file(arena);
        if (!Files.exists(f)) return;
        int bad = 0;
        try {
            String text = Files.readString(f).trim();
            List<JsonElement> entries = new ArrayList<>();
            if (text.startsWith("[")) {
                for (JsonElement el : JsonParser.parseString(text).getAsJsonArray()) entries.add(el);
            } else {
                for (String line : text.split("\\R")) {
                    if (line.isBlank()) continue;
                    try { entries.add(JsonParser.parseString(line)); } catch (Exception ex) { bad++; } // a half-written last line after a crash
                }
            }
            for (JsonElement el : entries) {
                try {
                    JsonObject o = el.getAsJsonObject();
                    Block block = BuiltInRegistries.BLOCK.getValue(ResourceLocation.parse(o.get("b").getAsString()));
                    BlockState st = block.defaultBlockState();
                    if (o.has("p")) {
                        for (Map.Entry<String, JsonElement> pe : o.getAsJsonObject("p").entrySet()) {
                            Property<?> prop = block.getStateDefinition().getProperty(pe.getKey());
                            if (prop != null) st = withValue(st, prop, pe.getValue().getAsString());
                        }
                    }
                    original.putIfAbsent(BlockPos.asLong(o.get("x").getAsInt(), o.get("y").getAsInt(), o.get("z").getAsInt()), st);
                } catch (Exception ex) { bad++; }
            }
        } catch (Exception e) {
            MgMod.LOG.error("Could not read journal of arena " + arena.id + " (file kept at " + f + ")", e);
        }
        if (bad > 0) MgMod.LOG.warn("Journal of arena {}: {} unreadable entries skipped.", arena.id, bad);
    }

    public static boolean existsOnDisk(Arena a) { return Files.exists(file(a)); }

    private static <T extends Comparable<T>> String valueName(Property<T> prop, BlockState st) { return prop.getName(st.getValue(prop)); }

    private static <T extends Comparable<T>> BlockState withValue(BlockState st, Property<T> prop, String name) {
        return prop.getValue(name).map(v -> st.setValue(prop, v)).orElse(st);
    }
}
