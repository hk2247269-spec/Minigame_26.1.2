package com.hanzala.minigames;

import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.Item;

import java.util.Set;

/** Small helpers shared by every minigame. */
public final class MgUtil {
    private MgUtil() { }

    public static Component msg(String text) { return Component.literal("§8[§bMinigames§8] §7" + text); }

    public static void title(ServerPlayer p, String title, String sub, int in, int stay, int out) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(in, stay, out));
        p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(sub)));
        p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(title)));
    }

    public static void bar(ServerPlayer p, String text) { p.displayClientMessage(Component.literal(text), true); }

    public static void snd(ServerPlayer p, SoundEvent e, float vol, float pitch) { p.playNotifySound(e, SoundSource.MASTER, vol, pitch); }

    /** Teleport inside the Overworld (every minigame lives there) and stop all momentum. */
    public static void tp(ServerPlayer p, Arena.Loc l) {
        if (l == null || p.getServer() == null) return;
        p.teleportTo(p.getServer().overworld(), l.x, l.y, l.z, Set.<Relative>of(), l.yaw, l.pitch, true);
        p.setDeltaMovement(Vec3.ZERO);
        p.resetFallDistance();
    }

    public static ItemStack named(Item item, String name) {
        ItemStack s = new ItemStack(item);
        s.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(st -> st.withItalic(false)));
        return s;
    }
}
