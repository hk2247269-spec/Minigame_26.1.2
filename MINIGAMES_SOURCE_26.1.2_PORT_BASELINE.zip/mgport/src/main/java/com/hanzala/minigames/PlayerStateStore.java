package com.hanzala.minigames;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.RegistryOps;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;

/**
 * Saves a player's location, inventory, game mode, health, hunger, XP and effects to disk when they enter a minigame and
 * gives everything back when they leave. The backup is a file, so a crash / restart in the middle of a match cannot lose items:
 * it is restored the next time the player joins the server (see MgMod). Never overwrites an existing backup.
 */
public final class PlayerStateStore {
    private PlayerStateStore() { }

    private static Path dir() {
        Path d = MgSettings.dir().resolve("backups");
        try { Files.createDirectories(d); } catch (Exception e) { MgMod.LOG.error("backup dir", e); }
        return d;
    }

    private static Path file(ServerPlayer p) { return dir().resolve(p.getUUID() + ".json"); }

    public static boolean exists(ServerPlayer p) { return Files.exists(file(p)); }

    /** Saves the state. Returns false when it could not be written (the caller must then NOT wipe the player's inventory). */
    public static boolean save(ServerPlayer p) {
        Path f = file(p);
        if (Files.exists(f)) return true; // an older real backup is still waiting: keep it
        try {
            JsonObject o = new JsonObject();
            o.addProperty("dim", p.level().dimension().location().toString());
            o.addProperty("x", p.getX());
            o.addProperty("y", p.getY());
            o.addProperty("z", p.getZ());
            o.addProperty("yaw", p.getYRot());
            o.addProperty("pitch", p.getXRot());
            o.addProperty("mode", p.gameMode.getGameModeForPlayer().getName());
            o.addProperty("health", p.getHealth());
            o.addProperty("food", p.getFoodData().getFoodLevel());
            o.addProperty("saturation", p.getFoodData().getSaturationLevel());
            o.addProperty("xp", p.experienceProgress);
            o.addProperty("level", p.experienceLevel);
            o.addProperty("totalXp", p.totalExperience);
            RegistryOps<JsonElement> ops = p.level().registryAccess().createSerializationContext(JsonOps.INSTANCE);
            JsonArray effects = new JsonArray();
            for (MobEffectInstance e : p.getActiveEffects()) effects.add(MobEffectInstance.CODEC.encodeStart(ops, e).getOrThrow());
            o.add("effects", effects);
            JsonArray arr = new JsonArray();
            Inventory inv = p.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) arr.add(ItemStack.OPTIONAL_CODEC.encodeStart(ops, inv.getItem(i)).getOrThrow());
            o.add("items", arr);
            Files.writeString(f, o.toString());
            return true;
        } catch (Exception e) {
            MgMod.LOG.error("Could not back up " + p.getName().getString(), e);
            return false;
        }
    }

    /** Clean slate for a minigame: empty inventory, no effects, adventure mode, full health and hunger. */
    public static void applyGameSettings(ServerPlayer p, GameType mode) {
        p.getInventory().clearContent();
        p.removeAllEffects();
        p.clearFire();
        p.setGameMode(mode);
        p.setHealth(p.getMaxHealth());
        p.getFoodData().setFoodLevel(20);
        p.getFoodData().setSaturation(5f);
        p.resetFallDistance();
        p.inventoryMenu.broadcastChanges();
    }

    /**
     * Gives the saved inventory / mode / health / hunger / XP / effects back and deletes the backup. Does NOT teleport unless
     * {@code teleportToOrigin} is set (used only when there is no common lobby to send the player to).
     */
    public static boolean restore(ServerPlayer p, MinecraftServer server, boolean teleportToOrigin) {
        Path f = file(p);
        if (!Files.exists(f)) return false;
        try {
            JsonObject o = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            RegistryOps<JsonElement> ops = p.level().registryAccess().createSerializationContext(JsonOps.INSTANCE);
            Inventory inv = p.getInventory();
            inv.clearContent();
            JsonArray arr = o.getAsJsonArray("items");
            for (int i = 0; i < arr.size() && i < inv.getContainerSize(); i++) {
                inv.setItem(i, ItemStack.OPTIONAL_CODEC.parse(ops, arr.get(i)).result().orElse(ItemStack.EMPTY));
            }
            p.removeAllEffects();
            p.clearFire();
            if (o.has("effects")) {
                for (JsonElement e : o.getAsJsonArray("effects")) MobEffectInstance.CODEC.parse(ops, e).result().ifPresent(p::addEffect);
            }
            p.setGameMode(GameType.byName(o.get("mode").getAsString(), GameType.SURVIVAL));
            if (o.has("health")) p.setHealth(Math.min(p.getMaxHealth(), Math.max(1f, o.get("health").getAsFloat())));
            if (o.has("food")) p.getFoodData().setFoodLevel(o.get("food").getAsInt());
            if (o.has("saturation")) p.getFoodData().setSaturation(o.get("saturation").getAsFloat());
            if (o.has("xp")) p.experienceProgress = o.get("xp").getAsFloat();
            if (o.has("level")) p.experienceLevel = o.get("level").getAsInt();
            if (o.has("totalXp")) p.totalExperience = o.get("totalXp").getAsInt();
            if (teleportToOrigin) {
                ResourceKey<Level> key = ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(o.get("dim").getAsString()));
                ServerLevel lvl = server.getLevel(key);
                if (lvl != null) {
                    p.teleportTo(lvl, o.get("x").getAsDouble(), o.get("y").getAsDouble(), o.get("z").getAsDouble(),
                            Set.<Relative>of(), o.get("yaw").getAsFloat(), o.get("pitch").getAsFloat(), true);
                }
            }
            p.resetFallDistance();
            p.inventoryMenu.broadcastChanges();
            Files.deleteIfExists(f);
            return true;
        } catch (Exception e) {
            // keep the file: nothing is lost, an admin can still recover it from config/minigames/backups
            MgMod.LOG.error("Could not restore backup of " + p.getName().getString(), e);
            return false;
        }
    }
}
