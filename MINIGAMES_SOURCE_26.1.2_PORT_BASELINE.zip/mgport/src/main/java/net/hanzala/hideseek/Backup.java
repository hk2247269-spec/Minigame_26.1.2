package net.hanzala.hideseek;

import com.google.gson.*;
import com.mojang.serialization.JsonOps;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.RegistryOps;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;

import java.nio.file.*;
import java.util.Set;

/**
 * Saves a player's inventory, game mode and position to disk when they join a match, and gives it back
 * when they leave. Because it lives on disk, a server crash in the middle of a match cannot lose items:
 * the backup is restored the next time the player joins the server.
 */
public final class Backup {
    private Backup() {}

    static Path dir;

    public static void init() {
        dir = Cfg.dir.resolve("backups");
        try { Files.createDirectories(dir); } catch (Exception e) { HideSeekMod.LOG.error("backup dir", e); }
    }

    static Path file(ServerPlayer p) {
        return dir.resolve(p.getUUID() + ".json");
    }

    public static boolean exists(ServerPlayer p) {
        return dir != null && Files.exists(file(p));
    }

    public static void save(ServerPlayer p) {
        if (dir == null) return;
        Path f = file(p);
        if (Files.exists(f)) return; // never overwrite an older (real) backup
        try {
            JsonObject o = new JsonObject();
            o.addProperty("dim", p.level().dimension().location().toString());
            o.addProperty("x", p.getX());
            o.addProperty("y", p.getY());
            o.addProperty("z", p.getZ());
            o.addProperty("yaw", p.getYRot());
            o.addProperty("pitch", p.getXRot());
            o.addProperty("mode", p.gameMode.getGameModeForPlayer().getName());
            o.addProperty("health", p.getHealth());
            o.addProperty("food", p.getFoodData().getFoodLevel());
            o.addProperty("saturation", p.getFoodData().getSaturationLevel());
            o.addProperty("xp", p.experienceProgress);
            o.addProperty("level", p.experienceLevel);
            o.addProperty("totalXp", p.totalExperience);
            RegistryOps<JsonElement> ops = p.level().registryAccess().createSerializationContext(JsonOps.INSTANCE);
            JsonArray effects = new JsonArray();
            for (MobEffectInstance effect : p.getActiveEffects()) effects.add(MobEffectInstance.CODEC.encodeStart(ops, effect).getOrThrow());
            o.add("effects", effects);
            JsonArray arr = new JsonArray();
            Inventory inv = p.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) {
                arr.add(ItemStack.OPTIONAL_CODEC.encodeStart(ops, inv.getItem(i)).getOrThrow());
            }
            o.add("items", arr);
            Files.writeString(f, o.toString());
        } catch (Exception e) {
            HideSeekMod.LOG.error("Could not back up inventory of " + p.getName().getString(), e);
        }
    }

    /** Restores the backup (if any) and deletes it. Returns true if something was restored. */
    public static boolean restore(ServerPlayer p, MinecraftServer server) {
        if (dir == null) return false;
        Path f = file(p);
        if (!Files.exists(f)) return false;
        try {
            JsonObject o = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            RegistryOps<JsonElement> ops = p.level().registryAccess().createSerializationContext(JsonOps.INSTANCE);
            Inventory inv = p.getInventory();
            inv.clearContent();
            JsonArray arr = o.getAsJsonArray("items");
            for (int i = 0; i < arr.size() && i < inv.getContainerSize(); i++) {
                ItemStack st = ItemStack.OPTIONAL_CODEC.parse(ops, arr.get(i)).result().orElse(ItemStack.EMPTY);
                inv.setItem(i, st);
            }
            p.removeAllEffects();
            if (o.has("effects")) { JsonArray effects = o.getAsJsonArray("effects"); for (JsonElement e : effects) MobEffectInstance.CODEC.parse(ops, e).result().ifPresent(p::addEffect); }
            p.setGameMode(GameType.byName(o.get("mode").getAsString(), GameType.SURVIVAL));
            if (o.has("health")) p.setHealth(Math.min(p.getMaxHealth(), Math.max(1f, o.get("health").getAsFloat())));
            if (o.has("food")) p.getFoodData().setFoodLevel(o.get("food").getAsInt());
            if (o.has("saturation")) p.getFoodData().setSaturation(o.get("saturation").getAsFloat());
            if (o.has("xp")) p.experienceProgress = o.get("xp").getAsFloat();
            if (o.has("level")) p.experienceLevel = o.get("level").getAsInt();
            if (o.has("totalXp")) p.totalExperience = o.get("totalXp").getAsInt();
            ResourceKey<Level> key = ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(o.get("dim").getAsString()));
            ServerLevel lvl = server.getLevel(key);
            if (lvl != null) {
                p.teleportTo(lvl, o.get("x").getAsDouble(), o.get("y").getAsDouble(), o.get("z").getAsDouble(),
                        Set.<Relative>of(), o.get("yaw").getAsFloat(), o.get("pitch").getAsFloat(), true);
            }
            p.inventoryMenu.broadcastChanges();
            Files.deleteIfExists(f);
            return true;
        } catch (Exception e) {
            HideSeekMod.LOG.error("Could not restore backup of " + p.getName().getString(), e);
            return false;
        }
    }
}
