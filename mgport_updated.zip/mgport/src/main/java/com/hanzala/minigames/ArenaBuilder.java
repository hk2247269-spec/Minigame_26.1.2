package com.hanzala.minigames;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Builds ready-made arenas for "/mg arena add &lt;lava|tnt&gt; [chunks] [layers]".
 *
 * The arena is built where the admin stands: its corner is the corner of the admin's chunk and it grows towards +X / +Z, aligned to
 * whole chunks. Everything inside the arena box is replaced (terrain too) - this is a real build, not a match change, so it is NOT
 * journaled. Pick a flat or empty spot. The build runs a few columns per tick so the server does not freeze, and the arena is only
 * registered and enabled when the build is finished.
 *
 * Floor Is Lava: bedrock floor, 8 bedrock towers (3x3) in a ring, a tall empty box above. Players start on the towers.
 * TNT Run: 4-5 layers of plain TNT blocks (they never explode, they just vanish), {@link #GAP} blocks of air between the layers. Players start on the top layer.
 */
public final class ArenaBuilder {
    private ArenaBuilder() { }

    /** Free air blocks between one TNT layer and the next one above it. */
    public static final int GAP = 5;
    /** Height of a layer: one block of TNT (no sand). */
    private static final int LAYER_THICKNESS = 1;
    private static final int TOWER_HEIGHT = 12;
    private static final int LAVA_BOX_HEIGHT = 56;
    private static final int TNT_HEADROOM = 6;
    private static final int COLUMNS_PER_TICK = 40;
    /** 2 = send to clients, 16 = no neighbour reactions (nothing pops off or falls while building). */
    private static final int FLAGS = 2 | 16;
    /** Order in which the 8 ring positions are handed out, so 2-4 players start far apart. */
    private static final int[] SPREAD = { 0, 4, 2, 6, 1, 5, 3, 7 };

    private interface Column { void build(ServerLevel level, int x, int z, BlockPos.MutableBlockPos m); }

    private static final class Job {
        final ServerLevel level;
        final Arena arena;
        final int minX, minZ, width, depth;
        final Column column;
        final Consumer<String> say;
        int next;

        Job(ServerLevel level, Arena arena, int minX, int minZ, int width, int depth, Column column, Consumer<String> say) {
            this.level = level; this.arena = arena; this.minX = minX; this.minZ = minZ;
            this.width = width; this.depth = depth; this.column = column; this.say = say;
        }
    }

    private static final List<Job> JOBS = new ArrayList<>();
    private static final BlockPos.MutableBlockPos SCRATCH = new BlockPos.MutableBlockPos();

    public static boolean busy() { return !JOBS.isEmpty(); }

    /** Chunk grid {chunksX, chunksZ} for a chunk count of 4-8 (rounded up to a full rectangle: 5 -> 6, 7 -> 8). */
    static int[] grid(int chunks) {
        int n = Math.max(4, Math.min(8, chunks));
        if (n == 4) return new int[] { 2, 2 };
        if (n <= 6) return new int[] { 2, 3 };
        return new int[] { 2, 4 };
    }

    /** Ring position k (0-7) on an ellipse inside the box, the player facing the centre. */
    private static Arena.Loc ring(int k, double cx, double cz, double rx, double rz, double y) {
        double ang = Math.PI * 2 * SPREAD[k % 8] / 8 + Math.PI / 8;
        Arena.Loc l = new Arena.Loc();
        l.x = Math.floor(cx + Math.cos(ang) * rx) + 0.5;
        l.z = Math.floor(cz + Math.sin(ang) * rz) + 0.5;
        l.y = y;
        l.yaw = (float) Math.toDegrees(Math.atan2(-(cx - l.x), cz - l.z));
        l.pitch = 20f;
        return l;
    }

    /**
     * Prepares and starts building an arena. Returns an error text, or null when the build was started (the admin gets a message
     * when it is done).
     */
    public static String start(ServerPlayer admin, MinigameType type, int chunks, int layers, Consumer<String> say) {
        if (type != MinigameType.FLOOR_LAVA && type != MinigameType.TNT_RUN) return "Only lava and tnt arenas can be built automatically.";
        if (busy()) return "Another arena is still being built. Wait until it says it is done.";
        MinecraftServer server = admin.level().getServer();
        if (server == null) return "No server.";

        Arena a = new Arena();
        a.type = type.id;
        a.enabled = false;
        a.dimension = MgUtil.dimId(admin);
        ServerLevel level = Mg.levelOf(server, a);
        if (level == null) return "This dimension is not loaded.";

        int[] g = grid(chunks);
        int width = g[0] * 16, depth = g[1] * 16;
        int minX = (admin.blockPosition().getX() >> 4) * 16;
        int minZ = (admin.blockPosition().getZ() >> 4) * 16;
        int adminY = admin.blockPosition().getY();

        String err = type == MinigameType.FLOOR_LAVA ? planLava(a, level, minX, minZ, width, depth, adminY)
                : planTnt(a, level, minX, minZ, width, depth, adminY, Math.max(4, Math.min(5, layers)));
        if (err != null) return err;

        // the same checks as /mg arena enable: overlap with other arenas, distance to the lobby, spawns inside the box ...
        a.id = freeId(type);
        a.name = type.display + " Arena" + (a.id.equals(type.id) ? "" : " " + a.id.substring(type.id.length()));
        a.updateBox();
        String problem = ArenaManager.enableProblem(a);
        if (problem != null) return "Cannot build here: " + problem;

        Column col = type == MinigameType.FLOOR_LAVA ? lavaColumn(a, minX, minZ, width, depth) : tntColumn(a, layers(a));
        JOBS.add(new Job(level, a, minX, minZ, width, depth, col, say));
        say.accept("Building " + a.displayName() + ": " + g[0] + "x" + g[1] + " chunks (" + width + "x" + depth + " blocks), Y " + a.minY() + " to " + a.maxY()
                + ". Everything inside that box is replaced. This takes a few seconds...");
        return null;
    }

    private static String freeId(MinigameType t) {
        if (ArenaManager.get(t.id) == null) return t.id;
        int n = 2;
        while (ArenaManager.get(t.id + n) != null) n++;
        return t.id + n;
    }

    // ================================================================== tick

    public static void tick() {
        if (JOBS.isEmpty()) return;
        Job j = JOBS.get(0);
        try {
            int total = j.width * j.depth;
            for (int c = 0; c < COLUMNS_PER_TICK && j.next < total; c++, j.next++) {
                j.column.build(j.level, j.minX + j.next % j.width, j.minZ + j.next / j.width, SCRATCH);
            }
            if (j.next >= total) {
                JOBS.remove(0);
                finish(j);
            }
        } catch (RuntimeException e) {
            JOBS.remove(0);
            MgMod.LOG.error("Arena build failed", e);
            j.say.accept("The build stopped because of an error (see the server log). Part of the area may be changed.");
        }
    }

    private static void finish(Job j) {
        Arena a = j.arena;
        // the area may have been claimed while we were building - check again before the arena goes live
        String problem = ArenaManager.enableProblem(a);
        if (problem != null) {
            j.say.accept("The arena was built but cannot be enabled: " + problem);
            return;
        }
        a.enabled = true;
        ArenaManager.put(a);
        j.say.accept("§aArena '" + a.id + "' is built and enabled (" + a.type + ", up to " + a.maxPlayers + " players). Players can join it from /mg.");
    }

    private static void set(ServerLevel level, BlockPos.MutableBlockPos m, int x, int y, int z, BlockState st) {
        m.set(x, y, z);
        if (level.getBlockState(m) != st) level.setBlock(m, st, FLAGS);
    }

    // ================================================================== Floor Is Lava

    private static int towerX(Arena a, int k) { return (int) Math.floor(a.spawns.get(k).x); }
    private static int towerZ(Arena a, int k) { return (int) Math.floor(a.spawns.get(k).z); }

    private static String planLava(Arena a, ServerLevel level, int minX, int minZ, int width, int depth, int adminY) {
        int floor = Math.min(adminY - 1, level.getMaxY() - LAVA_BOX_HEIGHT);
        if (floor < level.getMinY() + 1) return "This dimension is not tall enough for a Floor Is Lava arena.";
        int top = floor + LAVA_BOX_HEIGHT - 1;
        a.x1 = minX; a.z1 = minZ; a.y1 = floor;
        a.x2 = minX + width - 1; a.z2 = minZ + depth - 1; a.y2 = top;
        a.hasPos1 = a.hasPos2 = true;
        double cx = minX + width / 2.0, cz = minZ + depth / 2.0;
        for (int k = 0; k < 8; k++) a.spawns.add(ring(k, cx, cz, width / 2.0 - 6, depth / 2.0 - 6, floor + TOWER_HEIGHT + 1));
        Arena.Loc w = new Arena.Loc();
        w.x = cx; w.y = floor + 1; w.z = cz;
        a.waiting = w;
        Arena.Loc s = new Arena.Loc();
        s.x = cx; s.y = floor + TOWER_HEIGHT + 10; s.z = cz;
        a.spectator = s;
        a.minPlayers = 2;
        a.maxPlayers = 8;
        a.params.put("startY", (double) (floor + 1));
        a.params.put("riseSeconds", 5.0);
        a.params.put("warmup", 15.0);
        return null;
    }

    private static Column lavaColumn(Arena a, int minX, int minZ, int width, int depth) {
        final int floor = a.minY(), top = a.maxY();
        // tower height per column (0 = no tower), computed once
        final int[] towerTop = new int[width * depth];
        for (int k = 0; k < a.spawns.size(); k++) {
            int tx = towerX(a, k), tz = towerZ(a, k);
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    int ix = tx + dx - minX, iz = tz + dz - minZ;
                    if (ix >= 0 && ix < width && iz >= 0 && iz < depth) towerTop[iz * width + ix] = floor + TOWER_HEIGHT;
                }
            }
        }
        final BlockState bedrock = Blocks.BEDROCK.defaultBlockState();
        final BlockState air = Blocks.AIR.defaultBlockState();
        return (level, x, z, m) -> {
            int tt = towerTop[(z - minZ) * width + (x - minX)];
            set(level, m, x, floor, z, bedrock);
            for (int y = floor + 1; y <= top; y++) set(level, m, x, y, z, y <= tt ? bedrock : air);
        };
    }

    // ================================================================== TNT Run

    private static int layers(Arena a) { return (int) a.param("layers", 5); }

    private static String planTnt(Arena a, ServerLevel level, int minX, int minZ, int width, int depth, int adminY, int layers) {
        int step = GAP + LAYER_THICKNESS;
        int height = (layers - 1) * step + LAYER_THICKNESS + 2 + TNT_HEADROOM; // from base-2 up to the headroom
        int base = Math.min(adminY - 1, level.getMaxY() - height + 2);
        if (base - 2 < level.getMinY()) return "This dimension is not tall enough for a TNT Run arena.";
        int topSand = base + (layers - 1) * step; // y of the top TNT layer
        a.x1 = minX; a.z1 = minZ; a.y1 = base - 2;
        a.x2 = minX + width - 1; a.z2 = minZ + depth - 1; a.y2 = topSand + 1 + TNT_HEADROOM;
        a.hasPos1 = a.hasPos2 = true;
        double cx = minX + width / 2.0, cz = minZ + depth / 2.0;
        for (int k = 0; k < 8; k++) a.spawns.add(ring(k, cx, cz, width / 2.0 - 5, depth / 2.0 - 5, topSand + 1));
        Arena.Loc w = new Arena.Loc();
        w.x = cx; w.y = topSand + 1; w.z = cz;
        a.waiting = w;
        Arena.Loc s = new Arena.Loc();
        s.x = cx; s.y = topSand + 4; s.z = cz;
        a.spectator = s;
        a.minPlayers = 2;
        a.maxPlayers = 8;
        a.params.put("layers", (double) layers);
        a.params.put("delayMin", 20.0);   // 1.0 s
        a.params.put("delayMax", 40.0);   // 2.0 s
        a.params.put("killY", (double) base); // below the lowest layer = out (terrain below the box can not catch players)
        return null;
    }

    private static Column tntColumn(Arena a, int layers) {
        final int step = GAP + LAYER_THICKNESS;
        final int base = (int) a.param("killY", a.minY() + 2);
        final int bottom = a.minY(), top = a.maxY();
        final BlockState tnt = Blocks.TNT.defaultBlockState();
        final BlockState air = Blocks.AIR.defaultBlockState();
        return (level, x, z, m) -> {
            for (int y = bottom; y <= top; y++) {
                int rel = y - base;
                BlockState st = air;
                if (rel >= 0 && rel % step == 0 && rel / step < layers) st = tnt;
                set(level, m, x, y, z, st);
            }
        };
    }
}
