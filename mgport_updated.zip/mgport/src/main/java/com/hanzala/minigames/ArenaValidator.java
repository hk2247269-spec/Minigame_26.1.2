package com.hanzala.minigames;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Predicate;
import java.util.regex.Pattern;

/**
 * Checks an arena before it can be enabled. Pure logic (no Minecraft classes), so it can be tested without a server.
 * Every problem comes with a plain-language explanation of how to fix it.
 */
public final class ArenaValidator {
    private ArenaValidator() { }

    public enum Severity { ERROR, WARNING }

    /** @param message what is wrong   @param fix how to fix it (never null) */
    public record Issue(Severity severity, String message, String fix) {
        public boolean isError() { return severity == Severity.ERROR; }
        public String line() { return (isError() ? "§c✘ " : "§e! ") + message + " §7→ " + fix; }
    }

    /** The common lobby, for the "arena must not cover the lobby" rule. */
    public record LobbyPoint(String dimension, double x, double y, double z) { }

    private static final Pattern DIM_ID = Pattern.compile("([a-z0-9_.-]+:)?[a-z0-9_./-]+");

    /** Checks that need no knowledge of other arenas, the lobby or the server. */
    public static List<Issue> checkArena(Arena a) { return validate(a, List.of(), null, null); }

    /**
     * @param others          every known arena (the arena itself is skipped)
     * @param lobby           the common lobby or null when none is set
     * @param dimensionLoaded asks the server whether a dimension exists (null = skip this check)
     */
    public static List<Issue> validate(Arena a, Collection<Arena> others, LobbyPoint lobby, Predicate<String> dimensionLoaded) {
        List<Issue> out = new ArrayList<>();
        String type = a.type == null ? "" : a.type.toLowerCase();

        // ---- dimension
        if (!DIM_ID.matcher(a.dim()).matches()) {
            out.add(err("The dimension '" + a.dim() + "' is not a valid identifier",
                    "Open the setup wizard, choose 'Clear locations' and set the corners again while standing in the right dimension."));
        } else if (dimensionLoaded != null && !dimensionLoaded.test(a.dim())) {
            out.add(err("The dimension '" + a.dim() + "' is not loaded on this server",
                    "Make sure that dimension exists (for example the Nether must be enabled), or move the arena: 'Clear locations' and set it up again in a loaded dimension."));
        }

        // ---- boundaries
        if (!a.hasBox) {
            out.add(err("Boundaries are not set",
                    "Stand in one corner and click 'Set corner 1', then stand in the opposite corner (and at a different height) and click 'Set corner 2'."));
        } else {
            int h = a.maxY() - a.minY() + 1;
            long area = (long) (a.maxX() - a.minX() + 1) * (a.maxZ() - a.minZ() + 1);
            if (h < 3) out.add(warn("The arena is only " + h + " block(s) tall", "Make sure both corners cover everything players can reach, including the ceiling above them."));
            if (area > 250_000L) out.add(warn("The arena is very large (" + area + " columns)", "Smaller arenas reset faster and use less memory. Only blocks a match actually changes are ever restored."));
        }

        // ---- spawns
        if (a.spawns.isEmpty()) {
            out.add(err("No player spawn is set", "Stand where players should start and click 'Add spawn'. Add one per player if you like (extra players share spawns)."));
        } else if (a.hasBox) {
            int outside = 0;
            for (Arena.Loc s : a.spawns) if (!a.contains(s.x, s.y, s.z)) outside++;
            if (outside > 0) out.add(err(outside + " spawn(s) are outside the boundaries",
                    "Use 'Clear spawns' and add them again inside the box, or enlarge the box with 'Set corner 1/2'."));
            if (a.spawns.size() < Math.min(a.maxPlayers, 4))
                out.add(warn("Only " + a.spawns.size() + " spawn(s) for up to " + a.maxPlayers + " players", "Players share spawn points - add a few more spawns to spread players out."));
        }

        // ---- waiting / spectator
        if (a.waiting == null) {
            out.add(warn("No waiting location - players will wait on the first spawn", "Stand in your waiting room and click 'Set waiting spot' (optional)."));
        } else if (a.hasBox && !a.contains(a.waiting.x, a.waiting.y, a.waiting.z)) {
            // allowed: a waiting room next to the arena is a valid design. Only mention it so the admin knows it is deliberate.
            out.add(warn("The waiting spot is outside the boundaries", "That is fine for a separate waiting room. Nothing in it is ever reset."));
        }
        if (a.spectator == null) {
            out.add(warn("No spectator location - eliminated players watch from above the arena", "Stand where spectators should watch and click 'Set spectator spot' (optional)."));
        } else if (a.hasBox && !a.contains(a.spectator.x, a.spectator.y, a.spectator.z)) {
            out.add(warn("The spectator spot is outside the boundaries - spectators are pulled back to it every second",
                    "Set the spectator spot inside the box (for example above the play area)."));
        }

        // ---- player limits
        if (a.minPlayers < 2) out.add(err("Minimum players is below 2", "Set the minimum players to at least 2."));
        if (a.maxPlayers < a.minPlayers) out.add(err("Maximum players (" + a.maxPlayers + ") is below the minimum (" + a.minPlayers + ")", "Raise the maximum or lower the minimum."));

        // ---- game specific
        switch (type) {
            case "rg" -> {
                if (a.finish == null) out.add(err("The finish line is not set",
                        "Stand ON the finish line (the far end, where the statue should stand) and click 'Set finish line'."));
                else if (a.hasBox && !a.contains(a.finish.x, a.finish.y, a.finish.z)) out.add(err("The finish line is outside the boundaries", "Set the finish line inside the box, or enlarge the box."));
                else if (!a.spawns.isEmpty()) {
                    double cx = 0, cz = 0;
                    for (Arena.Loc s : a.spawns) { cx += s.x; cz += s.z; }
                    cx /= a.spawns.size(); cz /= a.spawns.size();
                    if (Math.hypot(a.finish.x - cx, a.finish.z - cz) < 5)
                        out.add(err("The finish line is less than 5 blocks from the spawns", "Move the finish line (or the spawns) so players have a real distance to run."));
                }
                if (a.param("greenMin", 3) > a.param("greenMax", 7)) out.add(warn("Green light: minimum is longer than maximum", "The maximum is used for both. Lower 'greenMin' or raise 'greenMax'."));
                if (a.param("redMin", 2) > a.param("redMax", 5)) out.add(warn("Red light: minimum is longer than maximum", "The maximum is used for both. Lower 'redMin' or raise 'redMax'."));
            }
            case "tnt" -> {
                if (a.params.containsKey("delay") ? a.param("delay", 12) < 11 : a.param("delayMin", 20) < 11)
                    out.add(warn("TNT delay is below 11 ticks", "11 ticks is the minimum - the game raises it automatically."));
                if (a.param("delayMin", 20) > a.param("delayMax", 40))
                    out.add(warn("TNT delay: the shortest time is longer than the longest", "The longest time is used for both. Lower 'delayMin' or raise 'delayMax'."));
            }
            case "lava" -> {
                if (a.hasBox) {
                    double sy = a.param("startY", a.minY());
                    if (sy < a.minY() || sy > a.maxY()) out.add(warn("The lava start height Y " + (int) sy + " is outside the box (Y " + a.minY() + " to " + a.maxY() + ")",
                            "It is clamped into the box automatically. Change 'startY' to a height inside the box."));
                }
                if (a.param("riseSeconds", 8) < 1) out.add(warn("Lava rise time is below 1 second", "The game uses 1 second. Raise 'riseSeconds'."));
            }
            default -> { }
        }

        // ---- conflicts with other arenas / the lobby (same dimension only)
        if (a.hasBox) {
            for (Arena o : others) {
                if (o != a && o.id != null && !o.id.equalsIgnoreCase(a.id) && a.overlaps(o))
                    out.add(err("The boundaries overlap arena '" + o.id + "' (same dimension)",
                            "Arenas must not share blocks, because a reset would touch the other arena. Move or shrink one of them."));
            }
            if (lobby != null && lobby.dimension() != null && lobby.dimension().equals(a.dim())) {
                if (a.contains(lobby.x(), lobby.y(), lobby.z())) {
                    out.add(err("The arena covers the common lobby", "Build the arena away from the lobby, or move the lobby (/bw lobby set)."));
                } else if (lobby.x() >= a.minX() - 3 && lobby.x() <= a.maxX() + 4 && lobby.z() >= a.minZ() - 3 && lobby.z() <= a.maxZ() + 4
                        && lobby.y() >= a.minY() - 3 && lobby.y() <= a.maxY() + 4) {
                    out.add(err("The arena is too close to the common lobby (less than 4 blocks)", "Keep a gap of at least 4 blocks between the lobby spawn and the arena box."));
                }
            }
        }
        return out;
    }

    public static boolean hasErrors(List<Issue> issues) {
        for (Issue i : issues) if (i.isError()) return true;
        return false;
    }

    private static Issue err(String m, String fix) { return new Issue(Severity.ERROR, m, fix); }

    private static Issue warn(String m, String fix) { return new Issue(Severity.WARNING, m, fix); }
}
