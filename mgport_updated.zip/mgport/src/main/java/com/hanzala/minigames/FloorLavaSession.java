package com.hanzala.minigames;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Floor Is Lava. The admin builds platforms / structures inside the arena box. After a warm-up, lava rises one layer at a time
 * from {@code startY}. Lava only replaces air / replaceable blocks and only inside the box. A player who touches lava, leaves the
 * box or falls out of it is eliminated (players are invulnerable, so elimination is the rule). Last player alive wins.
 *
 * Players start with nothing and get random loot (1-4 of one item every 4-7 s) and may place blocks inside the arena box to climb above the lava; they can only break
 * blocks they placed themselves. Every placed block is journaled BEFORE it is placed, so the reset removes it. When the lava has
 * reached the top, the highest player still alive wins. Bedrock towers + the whole map come from "/mg arena add lava".
 *
 * Arena numbers (/mg arena set &lt;id&gt; &lt;key&gt; &lt;value&gt;):
 * startY (first lava layer, default = bottom of the box), riseSeconds (seconds per +1 layer, default 8), warmup (seconds before
 * the first layer, default 20).
 *
 * Every block that lava replaces is recorded in a {@link BlockJournal} BEFORE it changes, so the arena is restored after every
 * match, after /mg stop and after a crash.
 */
public final class FloorLavaSession extends GameSession {
    private static final int BLOCKS_PER_TICK = 400;

    private final BlockJournal journal;
    private final BlockPos.MutableBlockPos scratch = new BlockPos.MutableBlockPos();

    /** Highest layer whose fill has been started (-1 sentinel handled by {@link #fillActive}). */
    /** Sessions whose lava is on the map. While any exists, lava the session did not place itself cannot spread (see LevelMixin). */
    private static final Set<FloorLavaSession> LIVE = new HashSet<>();
    /** True only while this class itself is placing / restoring blocks. */
    private static boolean placing;

    /**
     * Called by LevelMixin: true when a lava block change must be refused. Only lava that would appear inside (or within 2 blocks
     * of) the box of a running Floor Is Lava arena, in that arena's own dimension, is refused - natural lava anywhere else in the
     * world, and in other arenas, behaves normally.
     */
    public static boolean blocksFlow(net.minecraft.server.level.ServerLevel lvl, BlockPos pos) {
        if (placing || LIVE.isEmpty()) return false;
        for (FloorLavaSession s : LIVE) {
            if (s.level != lvl) continue;
            Arena a = s.arena;
            if (pos.getX() >= a.minX() - 2 && pos.getX() <= a.maxX() + 2
                    && pos.getY() >= a.minY() - 2 && pos.getY() <= a.maxY() + 2
                    && pos.getZ() >= a.minZ() - 2 && pos.getZ() <= a.maxZ() + 2) return true;
        }
        return false;
    }

    /** Positions players placed blocks at (only these may be broken). */
    private final Set<Long> placed = new HashSet<>();
    /** Ticks since the lava filled the last layer. */
    private int fullTicks;
    /** matchTicks at which the next random loot is handed out. */
    private int nextGiveTick;
    private int lavaY;
    private int nextRiseTick;
    private boolean fillActive;
    private int fillX, fillZ;

    public FloorLavaSession(MinecraftServer server, Arena arena) {
        super(server, arena, MinigameType.FLOOR_LAVA);
        this.journal = new BlockJournal(arena);
    }

    private int startY() { return (int) Math.max(arena.minY(), Math.min(arena.maxY(), arena.param("startY", arena.minY()))); }
    private int riseTicks() { return (int) Math.max(1, arena.param("riseSeconds", 8)) * 20; }
    private int warmupTicks() { return (int) Math.max(0, arena.param("warmup", 20)) * 20; }

    @Override
    protected void onPrepare() {
        lavaY = startY() - 1;
        fillActive = false;
        nextRiseTick = warmupTicks();
        fullTicks = 0;
        placed.clear();
        LIVE.add(this);
        nextGiveTick = 0;
    }

    /** Random loot: every 4-7 s each living player gets 1-4 of one random item (blocks mostly, sometimes a pearl or ladders). */
    private static final Item[] LOOT = {
            Items.COBBLESTONE, Items.COBBLESTONE, Items.COBBLESTONE, Items.OAK_PLANKS, Items.OAK_PLANKS, Items.STONE_BRICKS,
            Items.SANDSTONE, Items.DIRT, Items.LADDER, Items.ENDER_PEARL,
            Items.SNOWBALL, Items.SNOWBALL, Items.WIND_CHARGE, Items.WIND_CHARGE };

    private void giveLoot() {
        var rnd = java.util.concurrent.ThreadLocalRandom.current();
        for (ServerPlayer p : online(alive)) {
            Item it = LOOT[rnd.nextInt(LOOT.length)];
            int n = it == Items.ENDER_PEARL ? 1 : 1 + rnd.nextInt(4);
            p.getInventory().add(new ItemStack(it, n)); // a full inventory simply gets nothing
            p.inventoryMenu.broadcastChanges();
            MgUtil.snd(p, SoundEvents.EXPERIENCE_ORB_PICKUP, 0.4f, 1.2f);
        }
        nextGiveTick = matchTicks + (4 + rnd.nextInt(4)) * 20; // 4-7 s
    }

    @Override
    protected void onStart() {
        // warm-up: nothing rises until matchTicks reaches warmup. Players may place blocks from now on (survival mode).
        for (ServerPlayer p : online(alive)) p.setGameMode(GameType.SURVIVAL);
    }

    @Override
    public boolean allowUseBlock(ServerPlayer p, net.minecraft.world.level.Level world, BlockHitResult hit, InteractionHand hand) {
        if (state != State.ACTIVE || !alive.contains(p.getUUID()) || (Object) world != (Object) level) return false;
        ItemStack st = p.getItemInHand(hand);
        if (isThrowable(st)) return true;
        if (!(st.getItem() instanceof BlockItem)) return false;
        BlockPos clicked = hit.getBlockPos();
        BlockPos target = level.getBlockState(clicked).canBeReplaced() ? clicked : clicked.relative(hit.getDirection());
        if (!journal.capture(level, target)) return false; // outside the arena box: never allowed
        journal.flush(); // the original block is on disk before it changes
        placed.add(target.asLong());
        return true;
    }

    @Override
    public boolean allowBreak(ServerPlayer p, BlockPos pos) {
        return state == State.ACTIVE && alive.contains(p.getUUID()) && placed.contains(pos.asLong());
    }

    /** Items a player may use on a block / in the air: they push other players or move the thrower. */
    private static boolean isThrowable(ItemStack st) {
        return st.is(Items.ENDER_PEARL) || st.is(Items.SNOWBALL) || st.is(Items.WIND_CHARGE);
    }

    /**
     * Called by MgMod's damage filter. A snowball hit does 0 damage but pushes the target; players in a minigame normally take no
     * damage at all (which also cancels the push), so this one case is let through while a match is on. Wind charges push by
     * themselves and need no exception.
     */
    public boolean allowPush(ServerPlayer victim, net.minecraft.world.damagesource.DamageSource source, float amount) {
        return state == State.ACTIVE && alive.contains(victim.getUUID()) && amount <= 0.0f
                && source.getDirectEntity() != null && source.getDirectEntity().getType() == net.minecraft.world.entity.EntityType.SNOWBALL;
    }

    /** The highest player still alive (the one that "went to the top"). */
    private List<UUID> highestAlive() {
        UUID best = null;
        double bestY = -Double.MAX_VALUE;
        for (ServerPlayer p : online(alive)) {
            if (p.getY() > bestY) { bestY = p.getY(); best = p.getUUID(); }
        }
        return best == null ? new ArrayList<>(alive) : List.of(best);
    }

    @Override
    protected List<UUID> timeoutWinners() { return highestAlive(); }

    @Override
    protected void tickActive() {
        // 0) random loot every 4-7 s
        if (matchTicks >= nextGiveTick) giveLoot();
        // 1) rise
        if (!fillActive && matchTicks >= nextRiseTick && lavaY < arena.maxY()) {
            nextRiseTick = matchTicks + riseTicks();
            lavaY++;
            fillActive = true;
            fillX = arena.minX();
            fillZ = arena.minZ();
            for (ServerPlayer p : online(players)) {
                MgUtil.bar(p, "§c§lThe lava rises! §7Now at Y " + lavaY);
                MgUtil.snd(p, SoundEvents.LAVA_AMBIENT, 1f, 0.8f);
            }
        }
        if (fillActive) fillSome();

        // 2) players
        for (ServerPlayer p : online(alive)) { // copy: eliminate() edits the set
            if (!alive.contains(p.getUUID())) continue;
            double x = p.getX(), y = p.getY(), z = p.getZ();
            if (!arena.containsXZ(x, z) || y < arena.minY() - 5 || y >= arena.maxY() + 4) {
                eliminate(p, "left the arena");
                continue;
            }
            if (inLava(x, y + 0.05, z) || inLava(x, y + 0.5, z)) eliminate(p, "touched the lava");
        }

        if (matchTicks % 10 == 0) journal.flush();

        // 3) the lava has covered everything: after a short pause the player who got highest wins
        if (state == State.ACTIVE && !fillActive && lavaY >= arena.maxY() && ++fullTicks >= 200) {
            tell("§eThe lava reached the top! The highest player wins.");
            end(highestAlive());
        }
    }

    private boolean inLava(double x, double y, double z) {
        if (!arena.contains(x, y, z)) return false;
        scratch.set((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
        BlockState st = level.getBlockState(scratch);
        return st.is(Blocks.LAVA) || st.getFluidState().is(FluidTags.LAVA);
    }

    /** Fills the current layer in slices of BLOCKS_PER_TICK cells. */
    private void fillSome() {
        int budget = BLOCKS_PER_TICK;
        BlockState lava = Blocks.LAVA.defaultBlockState();
        placing = true;
        try {
        while (budget > 0 && fillActive) {
            budget--;
            scratch.set(fillX, lavaY, fillZ);
            BlockState st = level.getBlockState(scratch);
            if (!st.is(Blocks.LAVA) && (st.isAir() || st.canBeReplaced())) {
                BlockPos pos = scratch.immutable();
                if (journal.capture(level, pos)) level.setBlock(pos, lava, 2);
            }
            if (++fillZ > arena.maxZ()) {
                fillZ = arena.minZ();
                if (++fillX > arena.maxX()) fillActive = false;
            }
        }
        } finally { placing = false; }
        journal.flush(); // the original blocks are on disk right after they are replaced
    }

    @Override
    protected List<String> activeLines(ServerPlayer p) {
        int untilRise = warmupTicks() - matchTicks;
        if (untilRise > 0) return List.of("§7Lava starts in §f" + (untilRise + 19) / 20 + "s");
        int next = Math.max(0, nextRiseTick - matchTicks);
        return List.of("§7Lava height: §cY " + Math.max(lavaY, startY() - 1), "§7Next rise: §f" + (next + 19) / 20 + "s");
    }

    @Override
    protected void onMatchOver() {
        fillActive = false;
        placed.clear();
        journal.flush();
    }

    @Override
    protected boolean resetStep() {
        fillActive = false;
        placing = true; // the restore may put lava back where it was originally; that must not be refused
        try {
            boolean done = journal.restoreSome(level, MgSettings.I.resetBlocksPerTick);
            if (done) LIVE.remove(this);
            return done;
        } finally { placing = false; }
    }

    @Override
    public void flushToDisk() { journal.flush(); LIVE.remove(this); }
}
