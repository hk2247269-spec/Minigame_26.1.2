package com.hanzala.minigames;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;
import java.util.function.BiConsumer;

/**
 * /mg  - the one command. Players: /mg, /mg menu, /mg leave. Admins (permission level 2): force commands,
 * /mg arena ..., /mg status, /mg stop, /mg reload.
 */
public final class MgCommands {
    private MgCommands() { }

    private static final SuggestionProvider<CommandSourceStack> ARENA_IDS =
            (ctx, b) -> SharedSuggestionProvider.suggest(ArenaManager.all().stream().map(a -> a.id).toList(), b);
    private static final SuggestionProvider<CommandSourceStack> ARENA_TYPES =
            (ctx, b) -> SharedSuggestionProvider.suggest(List.of("tnt", "lava", "rg"), b);
    private static final SuggestionProvider<CommandSourceStack> BUILT_IN_TYPES =
            (ctx, b) -> SharedSuggestionProvider.suggest(List.of("lava", "tnt"), b);
    private static final SuggestionProvider<CommandSourceStack> PARAM_KEYS =
            (ctx, b) -> SharedSuggestionProvider.suggest(List.of("delayMin", "delayMax", "killY", "riseSeconds", "startY", "warmup", "greenMin", "greenMax", "redMin", "redMax", "redGrace", "timeLimit"), b);

    private static boolean admin(CommandSourceStack s) { return s.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_GAMEMASTER); }

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("mg")
                .executes(ctx -> menu(ctx.getSource()))
                .then(Commands.literal("menu").executes(ctx -> menu(ctx.getSource())))
                .then(Commands.literal("leave").executes(ctx -> leave(ctx.getSource())))
                .then(Commands.literal("setup").requires(MgCommands::admin).executes(ctx -> { MgSetupMenu.open(ctx.getSource().getPlayerOrException()); return 1; }))
                .then(Commands.literal("status").requires(MgCommands::admin).executes(ctx -> status(ctx.getSource())))
                .then(Commands.literal("stop").requires(MgCommands::admin).executes(ctx -> stop(ctx.getSource())))
                .then(Commands.literal("reload").requires(MgCommands::admin).executes(ctx -> reload(ctx.getSource())));

        for (MinigameType t : MinigameType.values()) {
            root.then(Commands.literal(t.id).requires(MgCommands::admin)
                    .then(Commands.literal("force")
                            .executes(ctx -> forceAll(ctx.getSource(), t))
                            .then(Commands.argument("player", EntityArgument.player())
                                    .executes(ctx -> forcePlayer(ctx, t)))));
        }
        root.then(arena());
        d.register(root);
    }

    // ------------------------------------------------------------------ player commands

    private static int menu(CommandSourceStack src) throws CommandSyntaxException {
        MgMenu.open(src.getPlayerOrException());
        return 1;
    }

    private static int leave(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        if (!Mg.leave(p)) { src.sendFailure(Component.literal("You are not in a minigame.")); return 0; }
        return 1;
    }

    // ------------------------------------------------------------------ admin: force / stop / status

    private static int forceAll(CommandSourceStack src, MinigameType t) {
        String err = Mg.forceAll(src.getServer(), t, src);
        if (err != null) { src.sendFailure(Component.literal(err)); return 0; }
        src.sendSuccess(() -> Component.literal("Forced " + t.display + " for everybody online."), true);
        return 1;
    }

    private static int forcePlayer(CommandContext<CommandSourceStack> ctx, MinigameType t) throws CommandSyntaxException {
        CommandSourceStack src = ctx.getSource();
        ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
        String err = Mg.forcePlayer(src.getServer(), t, target);
        if (err != null) { src.sendFailure(Component.literal(err)); return 0; }
        src.sendSuccess(() -> Component.literal("Moved " + target.getName().getString() + " to " + t.display + "."), true);
        return 1;
    }

    private static int stop(CommandSourceStack src) {
        Mg.stopAll("An admin stopped all minigames.");
        src.sendSuccess(() -> Component.literal("All minigames stopped; players are back in the lobby and arenas are reset."), true);
        return 1;
    }

    private static int reload(CommandSourceStack src) {
        Mg.reload();
        src.sendSuccess(() -> Component.literal("Minigames reloaded (settings.json + arenas.json). All running games were stopped."), true);
        return 1;
    }

    private static int status(CommandSourceStack src) {
        for (MinigameType t : MinigameType.values()) {
            Mg.Status st = Mg.status(t);
            src.sendSuccess(() -> Component.literal(t.color + t.display + " §7- " + st.label() + " §7- players " + st.players()
                    + " - arena " + st.arenaName()), false);
        }
        return 1;
    }

    // ------------------------------------------------------------------ admin: arena setup

    private static LiteralArgumentBuilder<CommandSourceStack> arena() {
        return Commands.literal("arena").requires(MgCommands::admin)
                // /mg arena add <lava|tnt> [chunks 4-8] [layers 4-5]: builds a complete arena where you stand (see ArenaBuilder)
                .then(Commands.literal("add")
                        .then(Commands.argument("type", StringArgumentType.word()).suggests(BUILT_IN_TYPES)
                                .executes(ctx -> addBuilt(ctx, 6, 5))
                                .then(Commands.argument("chunks", IntegerArgumentType.integer(4, 8))
                                        .executes(ctx -> addBuilt(ctx, IntegerArgumentType.getInteger(ctx, "chunks"), 5))
                                        .then(Commands.argument("layers", IntegerArgumentType.integer(4, 5))
                                                .executes(ctx -> addBuilt(ctx, IntegerArgumentType.getInteger(ctx, "chunks"), IntegerArgumentType.getInteger(ctx, "layers")))))))
                .then(Commands.literal("create")
                        .then(Commands.argument("type", StringArgumentType.word()).suggests(ARENA_TYPES)
                                .executes(ctx -> {
                                    MinigameType t = MinigameType.byId(StringArgumentType.getString(ctx, "type"));
                                    if (t == null || t.external) return fail(ctx, "Unknown game. Use tnt, lava or rg.");
                                    Arena a = ArenaManager.createDefault(t);
                                    if (a == null) return fail(ctx, "Could not create the arena.");
                                    return ok(ctx, "Arena '" + a.id + "' is ready to be set up. Easiest: /mg setup. Or: stand in a corner -> /mg arena pos1 " + a.id + ", opposite corner -> pos2, then spawn add, then /mg arena enable " + a.id + ".");
                                })
                                .then(Commands.argument("id", StringArgumentType.word()).executes(ctx -> {
                                    MinigameType t = MinigameType.byId(StringArgumentType.getString(ctx, "type"));
                                    if (t == null) return fail(ctx, "Unknown game. Use tnt, lava or rg.");
                                    String err = ArenaManager.create(t, StringArgumentType.getString(ctx, "id"));
                                    if (err != null) return fail(ctx, err);
                                    return ok(ctx, "Arena created (disabled until it is valid). Easiest: /mg setup. Or: stand in a corner -> /mg arena pos1 " + StringArgumentType.getString(ctx, "id") + ", other corner -> pos2, then /mg arena spawn add <id>, then /mg arena enable <id>.");
                                }))))
                .then(Commands.literal("remove").then(idArg().executes(ctx -> {
                    Arena a = ArenaManager.get(StringArgumentType.getString(ctx, "id"));
                    if (a == null) return fail(ctx, "Unknown arena. /mg arena list");
                    String err = ArenaEdit.delete(a);
                    if (err != null) return fail(ctx, err);
                    return ok(ctx, "Arena '" + a.id + "' removed (no blocks were touched).");
                })))
                .then(Commands.literal("list").executes(ctx -> {
                    List<Arena> all = ArenaManager.all();
                    if (all.isEmpty()) return ok(ctx, "No arenas yet. /mg arena create <tnt|lava|rg> <id>");
                    for (Arena a : all) {
                        String problem = ArenaManager.problem(a);
                        say(ctx.getSource(), "§f" + a.id + " §7(" + a.type + ", " + a.dim() + ") " + (problem == null ? "§aenabled and ready" : "§c" + problem));
                    }
                    return 1;
                }))
                .then(Commands.literal("info").then(idArg().executes(ctx -> edit(ctx, false, (a, src) -> {
                    String problem = ArenaManager.problem(a);
                    say(src, "§f" + a.id + " §7type=" + a.type + " dimension=" + a.dim() + " enabled=" + a.enabled + " players=" + a.minPlayers + "-" + a.maxPlayers + " spawns=" + a.spawns.size()
                            + (a.hasBox ? " box=" + a.minX() + "," + a.minY() + "," + a.minZ() + " -> " + a.maxX() + "," + a.maxY() + "," + a.maxZ() : " box=not set"));
                    say(src, "§7params=" + a.params + "  waiting=" + (a.waiting != null) + "  spectator=" + (a.spectator != null));
                    say(src, problem == null ? "§aReady to play." : "§c" + problem);
                }))))
                .then(Commands.literal("name").then(idArg().then(Commands.argument("text", StringArgumentType.greedyString())
                        .executes(ctx -> runArena(ctx, a -> ArenaEdit.rename(a, StringArgumentType.getString(ctx, "text")), "Display name set.")))))
                .then(Commands.literal("pos1").then(idArg().executes(ctx -> corner(ctx, true))))
                .then(Commands.literal("pos2").then(idArg().executes(ctx -> corner(ctx, false))))
                .then(Commands.literal("enable").then(idArg().executes(ctx -> runArena(ctx, ArenaEdit::enable, "Arena enabled - players can join it from /mg."))))
                .then(Commands.literal("disable").then(idArg().executes(ctx -> runArena(ctx, ArenaEdit::disable, "Arena disabled (nothing was deleted)."))))
                .then(Commands.literal("validate").then(idArg().executes(ctx -> edit(ctx, false, (a, src) -> ArenaEdit.report(src, a)))))
                .then(Commands.literal("clear").then(idArg().executes(ctx -> runArena(ctx, ArenaEdit::clearLocations,
                        "Corners and spots cleared and the arena disabled. Settings were kept; set the locations again (also possible in another dimension)."))))
                .then(Commands.literal("tp").then(idArg().executes(ctx -> run(ctx, (a, p) -> {
                    Arena.Loc t = a.waitingSpot();
                    net.minecraft.server.level.ServerLevel lvl = Mg.levelOf(p.level().getServer(), a);
                    if (t == null || lvl == null) return "Nothing to teleport to yet (no spawn set, or the dimension is not loaded).";
                    if (Mg.sessionOf(p) != null) return "Leave your current game first (/mg leave).";
                    MgUtil.tp(p, lvl, t);
                    return null;
                }, "Teleported."))))
                .then(Commands.literal("reset").then(idArg().executes(ctx -> runArena(ctx, Mg::restoreLeftovers,
                        "Arena restored from its reset journal."))))
                .then(Commands.literal("spawn")
                        .then(Commands.literal("add").then(idArg().executes(ctx -> run(ctx, ArenaEdit::addSpawn, "Spawn added. (/mg arena validate shows if it is inside the boundaries.)"))))
                        .then(Commands.literal("clear").then(idArg().executes(ctx -> runArena(ctx, ArenaEdit::clearSpawns, "All spawns removed.")))))
                .then(Commands.literal("waiting").then(idArg().executes(ctx -> run(ctx, ArenaEdit::setWaiting, "Waiting spot set (players wait here before the match)."))))
                .then(Commands.literal("finish").then(idArg().executes(ctx -> run(ctx, ArenaEdit::setFinish,
                        "Finish line set (Red Light Green Light: the statue stands here; players qualify when they pass this line)."))))
                .then(Commands.literal("spectator").then(idArg().executes(ctx -> run(ctx, ArenaEdit::setSpectator, "Spectator spot set."))))
                .then(Commands.literal("min").then(idArg().then(Commands.argument("n", IntegerArgumentType.integer(2, 100))
                        .executes(ctx -> edit(ctx, true, (a, src) -> {
                            a.minPlayers = IntegerArgumentType.getInteger(ctx, "n");
                            if (a.maxPlayers < a.minPlayers) a.maxPlayers = a.minPlayers;
                            say(src, "Minimum players: " + a.minPlayers);
                        })))))
                .then(Commands.literal("max").then(idArg().then(Commands.argument("n", IntegerArgumentType.integer(2, 100))
                        .executes(ctx -> edit(ctx, true, (a, src) -> {
                            a.maxPlayers = IntegerArgumentType.getInteger(ctx, "n");
                            if (a.minPlayers > a.maxPlayers) a.minPlayers = a.maxPlayers;
                            say(src, "Maximum players: " + a.maxPlayers);
                        })))))
                .then(Commands.literal("set").then(idArg().then(Commands.argument("key", StringArgumentType.word()).suggests(PARAM_KEYS)
                        .then(Commands.argument("value", DoubleArgumentType.doubleArg())
                                .executes(ctx -> edit(ctx, true, (a, src) -> {
                                    String k = StringArgumentType.getString(ctx, "key");
                                    double v = DoubleArgumentType.getDouble(ctx, "value");
                                    a.params.put(k, v);
                                    say(src, "Set " + k + " = " + v);
                                }))))));
    }

    private static int addBuilt(CommandContext<CommandSourceStack> ctx, int chunks, int layers) throws CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        String word = StringArgumentType.getString(ctx, "type").toLowerCase();
        MinigameType t = switch (word) {
            case "lava", "floor", "fl" -> MinigameType.FLOOR_LAVA;
            case "tnt" -> MinigameType.TNT_RUN;
            default -> null;
        };
        if (t == null) return fail(ctx, "Use /mg arena add lava or /mg arena add tnt. (Red Light Green Light has no ready-made arena: /mg arena create rg.)");
        String err = ArenaBuilder.start(p, t, chunks, layers, text -> say(ctx.getSource(), text));
        if (err != null) return fail(ctx, err);
        return 1;
    }

    private static RequiredArgumentBuilder<CommandSourceStack, String> idArg() {
        return Commands.argument("id", StringArgumentType.word()).suggests(ARENA_IDS);
    }

    private static int corner(CommandContext<CommandSourceStack> ctx, boolean first) {
        int r = run(ctx, (a, p) -> ArenaEdit.corner(a, p, first), "Corner " + (first ? "1" : "2") + " set to your position.");
        Arena a = ArenaManager.get(StringArgumentType.getString(ctx, "id"));
        if (r == 1 && a != null && a.hasBox) {
            say(ctx.getSource(), "§7Box complete.");
            for (Arena o : ArenaManager.all()) if (o != a && a.overlaps(o)) say(ctx.getSource(), "§cWarning: this box overlaps arena '" + o.id + "' - the arena cannot be enabled until that is fixed.");
        }
        return r;
    }

    /** Runs an {@link ArenaEdit} that needs no position (works from the console too). */
    private static int runArena(CommandContext<CommandSourceStack> ctx, java.util.function.Function<Arena, String> action, String okText) {
        Arena a = ArenaManager.get(StringArgumentType.getString(ctx, "id"));
        if (a == null) return fail(ctx, "Unknown arena. /mg arena list");
        String err = action.apply(a);
        if (err != null) return fail(ctx, err);
        say(ctx.getSource(), okText);
        return 1;
    }

    /** Runs a player-position edit from {@link ArenaEdit}: returns its error text or says {@code okText}. */
    private static int run(CommandContext<CommandSourceStack> ctx, java.util.function.BiFunction<Arena, ServerPlayer, String> action, String okText) {
        CommandSourceStack src = ctx.getSource();
        Arena a = ArenaManager.get(StringArgumentType.getString(ctx, "id"));
        if (a == null) return fail(ctx, "Unknown arena. /mg arena list");
        ServerPlayer p = src.getPlayer();
        if (p == null) return fail(ctx, "This command must be run by a player (it uses your position).");
        String err = action.apply(a, p);
        if (err != null) return fail(ctx, err);
        say(src, okText);
        return 1;
    }

    /** Runs an edit on an arena. Edits are refused while a game is using that arena. */
    private static int edit(CommandContext<CommandSourceStack> ctx, boolean changes, BiConsumer<Arena, CommandSourceStack> action) {
        CommandSourceStack src = ctx.getSource();
        Arena a = ArenaManager.get(StringArgumentType.getString(ctx, "id"));
        if (a == null) return fail(ctx, "Unknown arena. /mg arena list");
        if (changes && !Mg.canEdit(a)) return fail(ctx, "A game is using this arena right now. Stop it first (/mg stop).");
        try {
            action.accept(a, src);
        } catch (NullPointerException e) {
            return fail(ctx, "This command must be run by a player (it uses your position).");
        }
        if (changes) ArenaManager.save();
        return 1;
    }

    private static void say(CommandSourceStack src, String text) { src.sendSuccess(() -> Component.literal(text), false); }

    private static int ok(CommandContext<CommandSourceStack> ctx, String text) { say(ctx.getSource(), text); return 1; }

    private static int fail(CommandContext<CommandSourceStack> ctx, String text) { ctx.getSource().sendFailure(Component.literal(text)); return 0; }
}
