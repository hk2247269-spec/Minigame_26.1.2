package com.hanzala.minigames;

import com.hanzala.bedwars.BedWarsMod;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Entry point of the central Minigames system (/mg, the GUI, shared lifecycle, TNT Run, and later Floor Is Lava,
 * Red Light Green Light). BedWars and Hide &amp; Seek keep their own entry points and plug in through ExternalGame.
 */
public final class MgMod implements ModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("minigames");
    private static final Map<UUID, Integer> LAST_ITEM_USE = new HashMap<>();

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> MgCommands.register(dispatcher));

        Mg.registerExternal(new BedWarsAdapter());
        Mg.registerExternal(new HideSeekAdapter());
        RedGreenSession.registerCleanup();
        // A dropped menu compass / leave barrier is removed and handed back to the nearest player (no litter, nothing lost).
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (!(entity instanceof net.minecraft.world.entity.item.ItemEntity ie)) return;
            ItemStack st = ie.getItem();
            boolean menu = Lobby.isMenuItem(st), leave = Lobby.isLeaveItem(st);
            if (!menu && !leave) return;
            world.getServer().execute(() -> {
                Player near = world.getNearestPlayer(ie, 4.0);
                ie.discard();
                if (near instanceof ServerPlayer sp) {
                    if (leave && Mg.sessionOf(sp) != null) Lobby.giveLeaveItem(sp);
                    else if (menu && Mg.sessionOf(sp) == null) Lobby.giveMenuItem(sp);
                }
            });
        });
        ServerLifecycleEvents.SERVER_STARTED.register(s -> { Mg.init(s); RedGreenSession.purgeLoaded(s); });
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> Mg.shutdown());
        ServerTickEvents.END_SERVER_TICK.register(s -> { Mg.tick(); ArenaBuilder.tick(); });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer p = handler.getPlayer();
            server.execute(() -> onJoin(p));
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            LAST_ITEM_USE.remove(handler.getPlayer().getUUID());
            Mg.onDisconnect(handler.getPlayer());
        });

        // Minigame players take no damage; anything that would still kill them (void, /kill) is turned into an elimination.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayer p && Mg.sessionOf(p) != null) {
                if (Mg.sessionOf(p) instanceof FloorLavaSession fl && fl.allowPush(p, source, amount)) return true; // snowball: 0 damage, but it pushes
                return source.is(DamageTypeTags.BYPASSES_INVULNERABILITY);
            }
            return true;
        });
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) ->
                !(entity instanceof ServerPlayer p && Mg.onFatalDamage(p)));

        // Players inside a minigame never break blocks. Outsiders (lobby visitors) cannot change blocks inside an arena that is in
        // use, because the reset would not know about those changes. Operators are exempt.
        // (a game may let its players break blocks they placed themselves: GameSession.allowBreak)
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, be) -> {
            if (!(player instanceof ServerPlayer sp)) return true;
            GameSession gs = Mg.sessionOf(sp);
            if (gs != null) return gs.allowBreak(sp, pos);
            return !Mg.isLockedFor(sp, world, pos);
        });

        UseItemCallback.EVENT.register((player, world, hand) -> handleSpecialItem(player, world, hand) ? InteractionResult.SUCCESS : InteractionResult.PASS);
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (handleSpecialItem(player, world, hand)) return InteractionResult.SUCCESS;
            if (!world.isClientSide() && player instanceof ServerPlayer sp) {
                GameSession gs = Mg.sessionOf(sp);
                // players in a minigame cannot place / use blocks, except where the game allows it (Floor Is Lava: building blocks, ender pearls)
                if (gs != null) return gs.allowUseBlock(sp, world, hit, hand) ? InteractionResult.PASS : InteractionResult.FAIL;
                // outsiders: no placing / interacting at a block inside an arena that is in use (checks the clicked block and the block next to it)
                if (Mg.isLockedFor(sp, world, hit.getBlockPos()) || Mg.isLockedFor(sp, world, hit.getBlockPos().relative(hit.getDirection()))) return InteractionResult.FAIL;
            }
            return InteractionResult.PASS;
        });

        String ver = net.fabricmc.loader.api.FabricLoader.getInstance().getModContainer("bedwars_hideseek")
                .map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("?");
        LOG.info("Minigames {} loaded (/mg).", ver);
    }

    /** Right-click with the lobby compass (open /mg menu) or the in-game barrier (leave). Returns true when handled. */
    private static boolean handleSpecialItem(Player player, Level world, InteractionHand hand) {
        if (world.isClientSide() || !(player instanceof ServerPlayer sp)) return false;
        ItemStack st = sp.getItemInHand(hand);
        boolean menu = Lobby.isMenuItem(st);
        boolean leave = Lobby.isLeaveItem(st);
        if (!menu && !leave) return false;
        int now = sp.level().getServer().getTickCount();
        Integer last = LAST_ITEM_USE.put(sp.getUUID(), now);
        if (last != null && last == now) return true; // the same click arrives once per hand / callback
        if (leave) Mg.leave(sp);
        else MgMenu.open(sp);
        return true;
    }

    private static void onJoin(ServerPlayer p) {
        // A crash / restart during a match: give the saved inventory back and send the player to the common lobby.
        if (Mg.sessionOf(p) == null && PlayerStateStore.exists(p)) {
            if (PlayerStateStore.restore(p, p.level().getServer(), !Lobby.available())) {
                if (Lobby.available()) Lobby.send(p);
                p.sendSystemMessage(MgUtil.msg("Your inventory was restored after an interrupted match."));
            }
        }
        if (Mg.sessionOf(p) == null && !(BedWarsMod.GAME.isRunning() && BedWarsMod.GAME.teamOf(p) != null)) {
            Lobby.giveMenuItem(p);
        }
    }
}
