package com.hanzala.minigames;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * TNT Run. The admin builds the floor layers (sand/TNT, wool, anything) inside the arena box; whatever a player stands on
 * vanishes shortly after they touch it (the TNT block under it too). A player below the arena box (= fell through every layer)
 * or outside it is eliminated. Last player alive wins.
 *
 * Arena numbers (/mg arena set &lt;id&gt; &lt;key&gt; &lt;value&gt;):
 *   delayMin / delayMax = a touched block disappears after a random time between these two values in ticks (default 20-40 = 1-2 s, min 11).
 *   delay = old setting: when present, every block vanishes after exactly that many ticks.
 *   killY = a player below this Y is out (default: the arena's lowest Y). Generated arenas set it just below the lowest layer.
 *
 * Reset: every block removed is recorded in a {@link BlockJournal} BEFORE it is removed (and the journal is written to disk),
 * so the original floor is always restored - also after a crash.
 */
public final class TntRunSession extends GameSession {
    private static final class Pending {
        final BlockPos pos;
        final int dueTick;
        Pending(BlockPos pos, int dueTick) { this.pos = pos; this.dueTick = dueTick; }
    }

    private final BlockJournal journal;
    private final PriorityQueue<Pending> queue = new PriorityQueue<>((x, y) -> Integer.compare(x.dueTick, y.dueTick));
    private final Set<Long> queued = new HashSet<>();
    private final BlockPos.MutableBlockPos scratch = new BlockPos.MutableBlockPos();

    public TntRunSession(MinecraftServer server, Arena arena) {
        super(server, arena, MinigameType.TNT_RUN);
        this.journal = new BlockJournal(arena);
    }

    /** Ticks until a touched block vanishes: fixed when the old "delay" number is set, otherwise random between delayMin and delayMax. */
    private int delay() {
        if (arena.params.containsKey("delay")) return (int) Math.max(11, arena.param("delay", 12));
        int lo = (int) Math.max(11, arena.param("delayMin", 20));
        int hi = (int) Math.max(lo, arena.param("delayMax", 40));
        return lo + (hi > lo ? ThreadLocalRandom.current().nextInt(hi - lo + 1) : 0);
    }

    private double killY() { return arena.param("killY", arena.minY()); }

    @Override
    protected void onPrepare() {
        queue.clear();
        queued.clear();
    }

    @Override
    protected void onStart() {
        // nothing special: from now on blocks under the players' feet start to disappear
    }

    @Override
    protected void tickActive() {
        // 1) players: elimination + mark the blocks they stand on
        for (ServerPlayer p : online(alive)) { // iterate over a copy: eliminate() edits the set
            if (!alive.contains(p.getUUID())) continue;
            double x = p.getX(), y = p.getY(), z = p.getZ();
            if (y < killY() || !arena.containsXZ(x, z)) {
                eliminate(p, y < killY() ? "fell through every layer" : "left the arena");
                continue;
            }
            markUnder(p);
        }
        // 2) blocks whose time has come (the queue is ordered by due tick)
        while (!queue.isEmpty() && queue.peek().dueTick <= matchTicks) {
            Pending pd = queue.poll();
            queued.remove(pd.pos.asLong());
            removeBlock(pd.pos);
        }
        // 3) write the reset data to disk (only does something when it changed)
        if (matchTicks % 10 == 0) journal.flush();
    }

    /** Schedules the block(s) under the player's feet (all four corners of the hitbox are checked). */
    private void markUnder(ServerPlayer p) {
        double y = p.getY() - 0.2;
        int by = (int) Math.floor(y);
        double[] off = { -0.3, 0.3 };
        for (double ox : off) {
            for (double oz : off) {
                scratch.set((int) Math.floor(p.getX() + ox), by, (int) Math.floor(p.getZ() + oz));
                schedule(scratch);
            }
        }
        scratch.set((int) Math.floor(p.getX()), by, (int) Math.floor(p.getZ()));
        schedule(scratch);
    }

    private void schedule(BlockPos p) {
        long key = p.asLong();
        if (queued.contains(key)) return;
        BlockState st = level.getBlockState(p);
        if (st.isAir() || st.is(Blocks.BEDROCK) || st.is(Blocks.BARRIER)) return;
        BlockPos pos = p.immutable();
        if (!journal.capture(level, pos)) return; // outside the arena box: never touched
        // the block below (TNT in a classic floor) goes with it
        BlockPos below = pos.below();
        if (level.getBlockState(below).is(Blocks.TNT)) journal.capture(level, below);
        queued.add(key);
        queue.add(new Pending(pos, matchTicks + delay()));
        // the journal is flushed every 10 ticks; the delay is >= 11 ticks, so the original state is always on disk before the block is removed
    }

    private void removeBlock(BlockPos pos) {
        BlockState st = level.getBlockState(pos);
        if (st.isAir()) return;
        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 2);
        BlockPos below = pos.below();
        // only a TNT block that is journaled (= inside the arena box) is ever removed
        if (level.getBlockState(below).is(Blocks.TNT) && journal.capture(level, below)) level.setBlock(below, Blocks.AIR.defaultBlockState(), 2);
    }

    @Override
    protected void onMatchOver() {
        queue.clear();
        queued.clear();
        journal.flush();
    }

    @Override
    protected boolean resetStep() {
        queue.clear();
        queued.clear();
        return journal.restoreSome(level, MgSettings.I.resetBlocksPerTick);
    }

    @Override
    public void flushToDisk() { journal.flush(); }

    @Override
    protected List<String> activeLines(ServerPlayer p) { return List.of(); }
}
